// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

import (
	"github.com/mauricelam/genny/generic"
)

type any generic.Type

type onesOfany struct {
	Aten *kind
	Apep any
}

type twosOfany struct {
	Aten any
	Apep any
}

// ===========================================================================

type lookUpany  struct { look map[any]Index }

// Idx returns the index of item iff applicable.
func(a lookUpany) Idx(item any) (idx Index, found bool) {idx, found = a.look[item]; return }
func(a *lookUpany) put(item any, idx Index) { a.look[item] = idx }
func(a lookUpany) Len() int            {return len(a.look)}
func(a lookUpany) Length() Cardinality {return Cardinality(len(a.look))}

// Random returns a channel to range over.
func (a lookUpany) Random() <-chan any {
	items := make(chan any)

	go func(items chan<- any, a lookUpany) {
		defer close(items)
		for item := range a.look {
			items <- item
		}
	}(items, a)
	return items
}

// ===========================================================================

// pileany is implemented by *PileOfany
type pileany interface {
	Pair
	Kind
	Iterable
	// Pile: Length()
	append(items ...any) *PileOfany
	add(item any) *PileOfany
	At(Index) any
	Range() <-chan any
	lookerany
}

type lookerany interface {
  	Idx(item any) (idx Index, found bool) // returns the index of item iff applicable
	put(item any, idx Index) // may panic("Overflow")
	Len() int            // current Length
	Length() Cardinality // current Length
	Random() <-chan any
}

// dummy func avoids to see these upon use of go doc -u
func assertPileOfanyInterfaces() {
	var (
		_ Pair = onesOfany{}
		_ Kind = onesOfany{}
		_ Pile = onesOfany{}
		_ Iterable = onesOfany{}

		_ Pair = twosOfany{}
		_ Pile = twosOfany{}
		_ Iterable = twosOfany{}

		_ Pair = &PileOfany{}
		_ Pair = new(PileOfany)
		_ Kind = &PileOfany{}
		_ Kind = new(PileOfany)
		_ Pile = &PileOfany{}
		_ Pile = new(PileOfany)
		_ Iterable = &PileOfany{}
		_ Iterable = new(PileOfany)
		_ pileany = &PileOfany{}
		_ pileany = new(PileOfany)

		_ lookerany = &lookUpany{}
	)
}

// var _ Iterable = &PileOfany{}
// var _ Iterable = new(PileOfany)

// ===========================================================================

// PileOfany holds different items of some kind, accessible in order of arrival
// and by index as well as via reverse look-up: Idx(item) returns the index (if
// any). It may be seen as a finite ordered indexed immutable set.
//
// Intentionally there is no removal, neither are add nor append exported.
type PileOfany struct {
	Aten *kind
	Apep []any

	lookUpany
	duplicates lookUpany
}

// NewPileOfany returns a named Pile of items.
// There must be at least one item.
func NewPileOfany(name Name, items ...any) *PileOfany {
	soMany := len(items)
	if soMany < 1 {
		panic("newPileOfany needs one item at least.")
	}

	pile := &PileOfany{
		&kind{name, typeOf(items[0])},
		make([]any, 0, soMany),
		lookUpany{make(map[any]Index, soMany)},
		lookUpany{make(map[any]Index)},
	}
	pile = pile.append(items...)
	return pile
}

// ===========================================================================

// Both implements Pair
// by returning both parts of a.
func (a onesOfany) Both() (aten, apep interface{}) { return a.Aten, a.Apep }
// Both implements Pair
// by returning both parts of a.
func (a twosOfany) Both() (aten, apep interface{}) { return a.Aten, a.Apep }
// Both implements Pair
// by returning both parts of its Kind.
func (a PileOfany) Both() (aten, apep interface{}) { return a.Aten.Both() }

// Kind implements Kind
// by returning the Name and the Type of a.
func (a onesOfany) Kind() (Name, Type)             { return a.Aten.Aten, a.Aten.Apep}

// Kind implements Kind
// by returning the Kind of the Type of a.
func (a PileOfany) Kind() (Name, Type)             { return a.Aten.Kind() }

// ===========================================================================

// Length is zero for nil and is 1 otherwise
func (a onesOfany) Length() Cardinality            { return 1 }

// Length is zero for nil and is 1 otherwise
func (a twosOfany) Length() Cardinality            { return 1 }

// ===========================================================================

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a onesOfany) Tail() Tail                     { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a twosOfany) Tail() Tail                     { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by sucessively returning
// the items
func (a PileOfany) Tail() Tail                     { var idx int; return a.tail(idx) }

func (a PileOfany) head(idx int) Head              { return func() Pair { return onesOfany{a.Aten, a.Apep[idx]} } }

func (a PileOfany) tail(idx int) Tail {
	if idx < len(a.Apep) {
		return func() (Head, Tail) {
			head := a.head(idx)
			idx++
			tail := a.tail(idx)
			return head, tail
		}
	}
	return NilTail()
}

// ===========================================================================
// PileOfany specific

// At returns the item at Index idx - and panics iff idx < 1.
func (a PileOfany) At(idx Index) any               { return a.Apep[Idx(idx)] }

// append
func (a *PileOfany) append(items ...any) *PileOfany {
	for _, item := range items { a = a.add(item) }
	return a
}

func (a *PileOfany) add(item any) *PileOfany {
	if idx, duplicate := a.Idx(item); duplicate {
		a.put(item, idx)
		idx, _ := a.duplicates.Idx(item)
		idx++
		a.duplicates.put(item, idx )
	} else {
		a.Apep = append(a.Apep, item)
		a.put(item, Index(len(a.Apep)))
	}
	return a
}

// Range returns a channel to range over.
func (a PileOfany) Range() <-chan any {
	items := make(chan any)

	go func(items chan<- any, a PileOfany) {
		defer close(items)
		for _, item := range a.Apep {
			items <- item
		}
	}(items, a)
	return items
}

// Fmap returns another pile with f applied to each item.
func (a PileOfany) Fmap(f func(any) any) *PileOfany {
	cap := len(a.Apep)
	name := a.Aten.Aten
	sample := a.At(1)
	pile := &PileOfany{
		&kind{name, typeOf(sample)},
		make([]any, 0, cap),
		lookUpany{make(map[any]Index, cap)},
		lookUpany{make(map[any]Index)},
	}
	for _, item := range a.Apep {
		pile = pile.add(f(item))
	}
	return pile
}

// Fmapanys establishes []any as a Functor.
func Fmapanys(f func(any) any, anys ...any) []any {
	anyS := make([]any, len(anys))
	for _, i := range anys {
		anyS = append(anyS, f(i))
	}
	return anyS
}

// JoinanyS helps []any to become a Monad.
// Here it's just a list comprehension - aka Concat.
func JoinanyS(ss [][]any) []any {
    s := []any{}
    for i := range ss {
        s = append(s, ss[i]...)
    }
    return s
}

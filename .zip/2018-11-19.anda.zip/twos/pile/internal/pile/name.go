// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// Name as a unique identifier - unique among its Kind
type Name string

var kindOfName = &kind{Name(typeOf(Name(0)).Name()), typeOf(Name(""))}

// KindOfName returns the kind of a Name.
func KindOfName() Kind {return kindOfName}

// Both implements Pair
// by returning a twice.
func (a Name) Both() (aten, apep interface{})      { return a, a }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Name) Kind() (Name, Type)                  { return KindOfName().Kind()}

// Length implements Pile
// by constantly returning one.
func (a Name) Length() Cardinality                 { return 1 }

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// ===========================================================================

// Cardinality represents a cardinal number such as the #-of items in a Pile.
type Cardinality = cardinalNumber
type cardinalNumber int64

var kindOfCardinality = &kind{Name(typeOf(Cardinality(0)).Name()), typeOf(Cardinality(0))}

// KindOfCardinality returns the kind of a Cardinality.
func KindOfCardinality() Kind {return kindOfCardinality}

// Both implements Pair
// by returning a twice.
func (a Cardinality) Both()                        (aten, apep interface{}) { return a, a }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Cardinality) Kind() (Name, Type)           { return KindOfCardinality().Kind()}

// Length implements Pile
// by constantly returning one.
func (a Cardinality) Length() Cardinality          { return 1 }

// C allows to range over the first N cardinal numbers:
//    for c := range C(10) {
//        fmt.Println(i)
//    }
// ... will print 0 to 9, inclusive.
func C(N int) <-chan Cardinality {
	Cs := make(chan Cardinality)
	go func(Cs chan<- Cardinality, N int) {
		defer close(Cs)
		for c := 0; c < N; c++ {
			Cs <- Cardinality(c)
		}
	}(Cs, N)
	return Cs
}

// ===========================================================================

// Index represents an ordinal number and may be used
// to enumerate a collention or access some item.
// Intentionally, the first item has Index = 1.
// This is more intuitive for users.
// (Only programmers prefer offsets over ordinals).
type Index = ordinalNumber
type ordinalNumber int64

var kindOfIndex = &kind{Name(typeOf(Index(1)).Name()), typeOf(Index(1))}

// KindOfIndex returns the kind of an Index.
func KindOfIndex() Kind {return kindOfIndex}

// Both implements Pair
// by returning a twice.
func (a Index) Both() (aten, apep interface{})     { return a, a }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Index) Kind() (Name, Type)                 { return KindOfIndex().Kind()}

// Length implements Pile
// by constantly returning one.
func (a Index) Length() Cardinality                { return 1 }

// At returns the Index corresponding to i: i+1
func At(i int) Index {
	return Index(i+1)
}

// Idx returns the slice-index corresponding to i: i-1
func Idx(i Index) int {
	return int(i-1)
}

// I allows to range over the first N ordinal numbers:
//    for i := range iter.I(10) {
//        fmt.Println(i)
//    }
// ... will print 1 to 10, inclusive.
func I(N int) <-chan Index {
	Is := make(chan Index)
	go func(Is chan<- Index, N int) {
		defer close(Is)
		for i := 1; i < N+1; i++ {
			Is <- Index(i)
		}
	}(Is, N)
	return Is
}

// ===========================================================================
// stolen from "github.com/bradfitz/iter"

// N returns a slice of n 0-sized elements, suitable for ranging over:
//    for i := range iter.N(10) {
//        fmt.Println(i)
//    }
// ... will print 0 to 9, inclusive.
//
// It does not cause any allocations.
func N(n int) []struct{} {
	return make([]struct{}, n)
}

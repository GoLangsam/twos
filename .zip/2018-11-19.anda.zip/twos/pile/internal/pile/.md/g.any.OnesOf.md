package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type onesOfany struct {
	Aten *kind
	Apep any
}

func (a onesOfany) Both() (aten, apep interface{})
func (a onesOfany) Kind() (Name, Type)
func (a onesOfany) Length() Cardinality
func (a onesOfany) Tail() Tail

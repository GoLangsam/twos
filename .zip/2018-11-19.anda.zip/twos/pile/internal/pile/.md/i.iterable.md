package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Iterable interface {
	Tail() Tail
}
    Iterable represents a tailor-made collection, a thread for a tailor.


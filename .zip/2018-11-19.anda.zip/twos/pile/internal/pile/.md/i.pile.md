package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Pile interface {
	Length() Cardinality
}
    Pile holds Length items.


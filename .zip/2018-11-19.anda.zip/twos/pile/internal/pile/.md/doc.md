package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

func C(N int) <-chan Cardinality
func I(N int) <-chan Index
func Idx(i Index) int
func N(n int) []struct{}
func Fmapanys(f func(any) any, anys ...any) []any
func JoinanyS(ss [][]any) []any
type Cardinality = cardinalNumber
type Head func() Pair
type Index = ordinalNumber
    func At(i int) Index
type Iterable interface{ ... }
type Kind interface{ ... }
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Name string
type Pair interface{ ... }
type Pile interface{ ... }
type PileOfany struct{ ... }
    func NewPileOfany(name Name, items ...any) *PileOfany
type Tail func() (Head, Tail)
    func NilTail() Tail
type Type = reflect.Type

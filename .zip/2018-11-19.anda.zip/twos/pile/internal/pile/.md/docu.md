package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

var kindOfCardinality = &kind{ ... }
var kindOfIndex = &kind{ ... }
var kindOfName = &kind{ ... }
var nilTail = func() (Head, Tail) { ... }
func C(N int) <-chan Cardinality
func I(N int) <-chan Index
func Idx(i Index) int
func N(n int) []struct{}
func assertPileOfanyInterfaces()
type Cardinality = cardinalNumber
type Head func() Pair
type Index = ordinalNumber
    func At(i int) Index
type Iterable interface{ ... }
type Kind interface{ ... }
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Name string
type Pair interface{ ... }
type Pile interface{ ... }
type PileOfany struct{ ... }
    func NewPileOfany(name Name, items ...any) *PileOfany
type Tail func() (Head, Tail)
    func NilTail() Tail
type Type = reflect.Type
    func typeOf(a interface{}) Type
type any generic.Type
    func Fmapanys(f func(any) any, anys ...any) []any
    func JoinanyS(ss [][]any) []any
type cardinalNumber int64
type kind struct{ ... }
    func newKind(name Name, sample interface{}) *kind
    func newType(name Name, typ Type) *kind
type lookUpany struct{ ... }
type lookerany interface{ ... }
type onesOfany struct{ ... }
type ordinalNumber int64
type pileany interface{ ... }
type twosOfany struct{ ... }

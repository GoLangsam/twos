package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type lookUpany struct{ look map[any]Index }

func (a lookUpany) Idx(item any) (idx Index, found bool)
func (a lookUpany) Len() int
func (a lookUpany) Length() Cardinality
func (a lookUpany) Random() <-chan any
func (a *lookUpany) put(item any, idx Index)

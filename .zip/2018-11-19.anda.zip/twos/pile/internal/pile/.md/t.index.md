package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Index = ordinalNumber
    Index represents an ordinal number and may be used to enumerate a collention
    or access some item. Intentionally, the first item has Index = 1. This is
    more intuitive for users. (Only programmers prefer offsets over ordinals).


func At(i int) Index
func (a Index) Both() (aten, apep interface{})
func (a Index) Kind() (Name, Type)
func (a Index) Length() Cardinality

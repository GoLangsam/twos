package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Name string
    Name as a unique identifier - unique among its Kind


func (a Name) Both() (aten, apep interface{})
func (a Name) Kind() (Name, Type)
func (a Name) Length() Cardinality

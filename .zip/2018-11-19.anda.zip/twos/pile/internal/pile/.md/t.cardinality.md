package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Cardinality = cardinalNumber
    Cardinality represents a cardinal number such as the #-of items in a Pile.


func (a Cardinality) Both() (aten, apep interface{})
func (a Cardinality) Kind() (Name, Type)
func (a Cardinality) Length() Cardinality

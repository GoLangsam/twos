package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Pair interface {
	Both() (aten, apep interface{}) // both sides - whatever each type is
}
    Pair has two sides: Aten & Apep. It may be atomic, or composed, nested.


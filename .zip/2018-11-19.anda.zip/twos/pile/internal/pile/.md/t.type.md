package pile // import "github.com/GoLangsam/anda/twos/pile/internal/pile"

type Type = reflect.Type
    Type is the reflect.Type


func typeOf(a interface{}) Type

var nilTail = func() (Head, Tail) { ... }
func C(N int) <-chan Cardinality
func I(N int) <-chan Index
func Idx(i Index) int
func N(n int) []struct{}
func assertPileOfanyInterfaces()
type Head func() Pair
    func At(i int) Index
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
    func NewPileOfany(name Name, items ...any) *PileOfany
type Tail func() (Head, Tail)
    func NilTail() Tail
    func typeOf(a interface{}) Type
    func Fmapanys(f func(any) any, anys ...any) []any
    func JoinanyS(ss [][]any) []any
    func newKind(name Name, sample interface{}) *kind
    func newType(name Name, typ Type) *kind

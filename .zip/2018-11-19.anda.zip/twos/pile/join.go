// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// join returns a pair of pairs - a nested pair.
func join(a, b Pair) Pair {
	return &twosOfPair{a, b}
}

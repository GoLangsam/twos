package pile // import "github.com/GoLangsam/anda/twos/pile"

func BothSameType(a Pair) bool
func BothTypes(a Pair) (Type, Type)
func C(N int) <-chan Cardinality
func Flat(a Pair) (values []interface{})
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) []interface{}
func FmapInts(f func(int) int, ints ...int) []int
func FmapStrings(f func(string) string, strings ...string) []string
func FmapTimeWeekdays(f func(time.Weekday) time.Weekday, timeWeekdays ...time.Weekday) []time.Weekday
func HaveSametree(p1, p2 Pair) (same bool)
func I(N int) <-chan Index
func Idx(i Index) int
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinIntS(ss [][]int) []int
func JoinInterfaceS(ss [][]interface{}) []interface{}
func JoinStringS(ss [][]string) []string
func JoinTimeWeekdayS(ss [][]time.Weekday) []time.Weekday
func N(n int) []struct{}
type Cardinality = cardinalNumber
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
    func JoinCardinalityS(ss [][]Cardinality) []Cardinality
type Head func() Pair
type Index = ordinalNumber
    func At(i int) Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) []Index
    func JoinIndexS(ss [][]Index) []Index
type Iterable interface{ ... }
type Kind interface{ ... }
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
    func JoinKindS(ss [][]Kind) []Kind
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Name string
    func FmapNames(f func(Name) Name, Names ...Name) []Name
    func JoinNameS(ss [][]Name) []Name
type Pair interface{ ... }
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
    func JoinPairS(ss [][]Pair) []Pair
    func TypePair(a Pair) Pair
type Pile interface{ ... }
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
    func JoinPileS(ss [][]Pile) []Pile
type PileOfCardinality struct{ ... }
    func NewPileOfCardinality(name Name, items ...Cardinality) *PileOfCardinality
type PileOfIndex struct{ ... }
    func NewPileOfIndex(name Name, items ...Index) *PileOfIndex
type PileOfInt struct{ ... }
    func NewPileOfInt(name Name, items ...int) *PileOfInt
type PileOfInterface struct{ ... }
    func NewPileOfInterface(name Name, items ...interface{}) *PileOfInterface
type PileOfKind struct{ ... }
    func NewPileOfKind(name Name, items ...Kind) *PileOfKind
type PileOfName struct{ ... }
    func NewPileOfName(name Name, items ...Name) *PileOfName
type PileOfPair struct{ ... }
    func NewPileOfPair(name Name, items ...Pair) *PileOfPair
type PileOfPile struct{ ... }
    func NewPileOfPile(name Name, items ...Pile) *PileOfPile
type PileOfString struct{ ... }
    func NewPileOfString(name Name, items ...string) *PileOfString
type PileOfTimeWeekday struct{ ... }
    func NewPileOfTimeWeekday(name Name, items ...time.Weekday) *PileOfTimeWeekday
type PileOfType struct{ ... }
    func NewPileOfType(name Name, items ...Type) *PileOfType
type Tail func() (Head, Tail)
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(a, b Iterable) Tail
    func NilTail() Tail
    func Prod(a, b Iterable) Tail
type Type = reflect.Type
    func FmapTypes(f func(Type) Type, Types ...Type) []Type
    func JoinTypeS(ss [][]Type) []Type

package pile // import "github.com/GoLangsam/anda/twos/pile"

type Pair interface {
	Both() (aten, apep interface{}) // both sides - whatever each type is
}
    Pair has two sides: Aten & Apep. It may be atomic, or composed, nested.


var _ Pair = &node{}
func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
func JoinPairS(ss [][]Pair) []Pair
func TypePair(a Pair) Pair
func join(a, b Pair) Pair

package pile // import "github.com/GoLangsam/anda/twos/pile"

const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = "{%v}"
const twosFmt = "{%+v|%+v}"
var kindOfCardinality = &kind{ ... }
var kindOfIndex = &kind{ ... }
var kindOfName = &kind{ ... }
var nilTail = func() (Head, Tail) { ... }
func BothSameType(a Pair) bool
func BothTypes(a Pair) (Type, Type)
func C(N int) <-chan Cardinality
func Flat(a Pair) (values []interface{})
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) []interface{}
func FmapInts(f func(int) int, ints ...int) []int
func FmapStrings(f func(string) string, strings ...string) []string
func FmapTimeWeekdays(f func(time.Weekday) time.Weekday, timeWeekdays ...time.Weekday) []time.Weekday
func HaveSametree(p1, p2 Pair) (same bool)
func I(N int) <-chan Index
func Idx(i Index) int
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinIntS(ss [][]int) []int
func JoinInterfaceS(ss [][]interface{}) []interface{}
func JoinStringS(ss [][]string) []string
func JoinTimeWeekdayS(ss [][]time.Weekday) []time.Weekday
func N(n int) []struct{}
func assertNodeInterfaces()
func assertPileOfCardinalityInterfaces()
func assertPileOfIndexInterfaces()
func assertPileOfIntInterfaces()
func assertPileOfInterfaceInterfaces()
func assertPileOfKindInterfaces()
func assertPileOfNameInterfaces()
func assertPileOfPairInterfaces()
func assertPileOfPileInterfaces()
func assertPileOfStringInterfaces()
func assertPileOfTimeWeekdayInterfaces()
func assertPileOfTypeInterfaces()
func bothApply(a Pair, y, n func(a interface{}))
func flat(a interface{}) []interface{}
func isAnAtom(a interface{}) (isAnAtom bool)
func mult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func multIter(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func prod(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func reduceAny(a Pair, f func(Pair) interface{}, init []interface{}) []interface{}
type Cardinality = cardinalNumber
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
    func JoinCardinalityS(ss [][]Cardinality) []Cardinality
type Head func() Pair
    func multHead(aHead, bHead Head) Head
type Index = ordinalNumber
    func At(i int) Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) []Index
    func JoinIndexS(ss [][]Index) []Index
type Iterable interface{ ... }
type Kind interface{ ... }
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
    func JoinKindS(ss [][]Kind) []Kind
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Name string
    func FmapNames(f func(Name) Name, Names ...Name) []Name
    func JoinNameS(ss [][]Name) []Name
type Pair interface{ ... }
    var _ Pair = &node{}
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
    func JoinPairS(ss [][]Pair) []Pair
    func TypePair(a Pair) Pair
    func join(a, b Pair) Pair
type Pile interface{ ... }
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
    func JoinPileS(ss [][]Pile) []Pile
type PileOfCardinality struct{ ... }
    func NewPileOfCardinality(name Name, items ...Cardinality) *PileOfCardinality
type PileOfIndex struct{ ... }
    func NewPileOfIndex(name Name, items ...Index) *PileOfIndex
type PileOfInt struct{ ... }
    func NewPileOfInt(name Name, items ...int) *PileOfInt
type PileOfInterface struct{ ... }
    func NewPileOfInterface(name Name, items ...interface{}) *PileOfInterface
type PileOfKind struct{ ... }
    func NewPileOfKind(name Name, items ...Kind) *PileOfKind
type PileOfName struct{ ... }
    func NewPileOfName(name Name, items ...Name) *PileOfName
type PileOfPair struct{ ... }
    func NewPileOfPair(name Name, items ...Pair) *PileOfPair
type PileOfPile struct{ ... }
    func NewPileOfPile(name Name, items ...Pile) *PileOfPile
type PileOfString struct{ ... }
    func NewPileOfString(name Name, items ...string) *PileOfString
type PileOfTimeWeekday struct{ ... }
    func NewPileOfTimeWeekday(name Name, items ...time.Weekday) *PileOfTimeWeekday
type PileOfType struct{ ... }
    func NewPileOfType(name Name, items ...Type) *PileOfType
type Tail func() (Head, Tail)
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(a, b Iterable) Tail
    func NilTail() Tail
    func Prod(a, b Iterable) Tail
    func multMult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
    func multTail(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
    func tailRecurse(a ...Pair) (tail Tail)
type Type = reflect.Type
    func FmapTypes(f func(Type) Type, Types ...Type) []Type
    func JoinTypeS(ss [][]Type) []Type
    func typeOf(a interface{}) Type
type cardinalNumber int64
type kind struct{ ... }
    func newKind(name Name, sample interface{}) *kind
    func newType(name Name, typ Type) *kind
type lookUpCardinality struct{ ... }
type lookUpIndex struct{ ... }
type lookUpInt struct{ ... }
type lookUpInterface struct{ ... }
type lookUpKind struct{ ... }
type lookUpName struct{ ... }
type lookUpPair struct{ ... }
type lookUpPile struct{ ... }
type lookUpString struct{ ... }
type lookUpTimeWeekday struct{ ... }
type lookUpType struct{ ... }
type lookerCardinality interface{ ... }
type lookerIndex interface{ ... }
type lookerInt interface{ ... }
type lookerInterface interface{ ... }
type lookerKind interface{ ... }
type lookerName interface{ ... }
type lookerPair interface{ ... }
type lookerPile interface{ ... }
type lookerString interface{ ... }
type lookerTimeWeekday interface{ ... }
type lookerType interface{ ... }
type node struct{ ... }
    func tree(a Pair) (root *node)
type onesOfCardinality struct{ ... }
type onesOfIndex struct{ ... }
type onesOfInt struct{ ... }
type onesOfInterface struct{ ... }
type onesOfKind struct{ ... }
type onesOfName struct{ ... }
type onesOfPair struct{ ... }
type onesOfPile struct{ ... }
type onesOfString struct{ ... }
type onesOfTimeWeekday struct{ ... }
type onesOfType struct{ ... }
type ordinalNumber int64
type pileCardinality interface{ ... }
type pileIndex interface{ ... }
type pileInt interface{ ... }
type pileInterface interface{ ... }
type pileKind interface{ ... }
type pileName interface{ ... }
type pilePair interface{ ... }
type pilePile interface{ ... }
type pileString interface{ ... }
type pileTimeWeekday interface{ ... }
type pileType interface{ ... }
type twosOfCardinality struct{ ... }
type twosOfIndex struct{ ... }
type twosOfInt struct{ ... }
type twosOfInterface struct{ ... }
type twosOfKind struct{ ... }
type twosOfName struct{ ... }
type twosOfPair struct{ ... }
type twosOfPile struct{ ... }
type twosOfString struct{ ... }
type twosOfTimeWeekday struct{ ... }
type twosOfType struct{ ... }

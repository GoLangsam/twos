// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// BothTypes returns both types.
func BothTypes(a Pair) (Type, Type) {
	aten, apep := a.Both()
	return typeOf(aten), typeOf(apep)
}

// BothSameType reports iff the TypeOf both sides are of the same type
func BothSameType(a Pair) bool {
	aten, apep := a.Both()
	return typeOf(aten) == typeOf(apep)
}

// TypePair returns both types as a Pair
func TypePair(a Pair) Pair {
	aten, apep := a.Both()
	return &twosOfType{
		Aten: typeOf(aten),
		Apep: typeOf(apep),
	}
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

import (
	"time"
)

// let's see if we can fool genny
func testInt() (Name, []int) {
	name := Name(typeOf(int(0)).Name())
	data := []int{ 4, 7, 1, 1, 5, 6} // Note: One duplicate!
	return name, data
}

func testIndex() (Name, []Index) {
	name := Name(typeOf(Index(417756)).Name())
	data := []Index{ 4, 7, 1, 1, 5, 6} // Note: One duplicate!
	return name, data
}

func testCardinality() (Name, []Cardinality) {
	name := Name(typeOf(Cardinality(417756)).Name())
	data := []Cardinality{ 4, 7, 1, 1, 5, 6} // Note: One duplicate!
	return name, data
}

func testString() (Name, []string) {
	name := Name(typeOf(string("test")).Name())
	data := []string{ "4", "7", "1", "1", "5", "6"} // Note: One duplicate!
	return name, data
}

func testName() (Name, []Name) {
	name := Name(typeOf(Name("test")).Name())
	data := []Name{ "4", "7", "1", "1", "5", "6"} // Note: One duplicate!
	return name, data
}

func testTimeWeekday() (Name, []time.Weekday) {
	name := Name(typeOf(time.Sunday).Name())
	data := []time.Weekday{
		time.Wednesday,
		time.Saturday,
		time.Monday,
		time.Monday,
		time.Thursday,
		time.Friday,
	} // Note: One duplicate!
	return name, data
}

func testInterface() (Name, []interface{}) {
	name := Name("interface{}")
	data := []interface{}{ int(4), Cardinality(7), time.Monday, time.Monday, "Thursday", Name("Friday") }
	return name, data
}

func testType() (Name, []Type) {
	name := Name("Type")
	data := []Type{typeOf(int(4)), typeOf(Cardinality(7)), typeOf(time.Monday) , typeOf(time.Monday), typeOf("Thursday"), typeOf(Name("Friday")) }
	// Note: One duplicate!
	return name, data
}

func testKind() (Name, []Kind) {
	name := Name("Kind")
	kind := newKind("time.Monday", time.Monday)
	data := []Kind{newKind("int", int(4)), newKind("Cardinality", Cardinality(7)), kind, kind, newKind("Thursday", "Thursday"), newKind(Name("Friday"), Name("Friday")) } //
	// Note: One duplicate!
	return name, data
}

func testPile() (Name, []Pile) {
	name := Name("Pile")
	pile := NewPileOfTimeWeekday("time.Monday", time.Monday)
	data := []Pile{NewPileOfInt("int", int(4)), NewPileOfCardinality("Cardinality", Cardinality(7)), pile, pile, NewPileOfString("Thursday", "Thursday"), NewPileOfName(Name("Friday"), Name("Friday")) } //
	// Note: One duplicate!
	return name, data
}

func testPair() (Name, []Pair) {
	name := Name("Pair")
	head1, _ := NewPileOfInt("int", int(4)).Tail()()
	head2, _ := NewPileOfCardinality("Cardinality", Cardinality(7)).Tail()()
	head3, _ := NewPileOfTimeWeekday("time.Monday", time.Monday).Tail()()
	head4, _ := NewPileOfTimeWeekday("time.Monday", time.Monday).Tail()()
	head5, _ := NewPileOfString("Thursday", "Thursday").Tail()()
	head6, _ := NewPileOfName(Name("Friday"), Name("Friday")).Tail()()
	_ = head4 // Cheap Cheat: use head3 twice to get ==
	data := []Pair{head1(),head2() ,head3() ,head3() ,head5() ,head6() } //
	// Note: One duplicate!
	return name, data
}


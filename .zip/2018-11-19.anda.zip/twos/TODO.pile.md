# TODO pile

## Cleanup
- Testdata for Iterable; genny,go

- see also ## Observations

- Node.Tail must walk the tree!

## Extend
- internal: add type Happiness & Boost => 13 types - 13*13 = 169 Combinations. genny can do, but: How shall I do the type-switches?

- Make Tree correct: Node(interface{}

- DeKind - desugar removing all *kind-details

- PileOfany: provide access to duplicates


---
## Future maybe

- include PipeOf - from pipe.m for all? types? One package? One per type?
- FAQ: Indexs, not Indices; Cardinalitys, not Cardinalities
- allow for small and growing lookers

---
## Discarded ideas

- rename FmapIndexs		=> FmapIndices
- rename FmapCardinalitys	=> FmapCardinalities
=> No! it's generated! 
=> TODO:FAQ

- move twos/pile	=  twos/internal/pile ??? Better not: Nobody could use it!

---
## Observations:
- Types: Cardinality, Index, Name, Type
	- all: Both/Kind/Length					TODO: except Type (=reflect.Type)
	- all: some kind of range: C, I, N			TODO: NameS(prefix, anz) use IDs from tees, TypeS ? makes no sense!

- Thunk: Head, Tail
	- all: Both/Kind/Length/Tail	Tail:Range		----:Tail.Range ? No! Length() == 1

- Inter: Kind, Pair, Pile, Interable
	- all: KindOf*()					TODO:KindOfType()

	-kind: Both/Kind/Length/Tail

	-ones: Both/Kind/Length/Tail				no Range + Fmap + more
	-twos: Both/----/Length/Tail				no Range + Fmap + more

	-pair: Both/Kind/Length/Tail/Range + Fmap + more

	-look: ----/----/Length/----/----- + Fmap + more	TODO:Range? Test, if external pack may range Duplicates
	-pile: Both/Kind/Length/Tail/Range + look*** + Fmap ...	TODO:Join: same+same, JoinPile: same+any


---
## Package level functions:

### TODO: Which of these may go up into twos?

    func BothSameType(a Pair) bool
    func BothTypes(a Pair) (Type, Type)
    func TypePair(a Pair) Pair

    func Flat(a Pair) (values []interface{})

    func HaveSametree(p1, p2 Pair) (same bool)

    func IsAtom(a Pair) (IsAtom bool)
    func IsAtomApep(a Pair) (isAtomApep bool)
    func IsAtomAten(a Pair) (IsAtomAten bool)
    func IsNested(a Pair) (IsNested bool)
    func IsPairOfPairs(a Pair) (IsPairOfPairs bool)

    func join(a, b Pair) Pair	see Mult & Prod		=> rename PairOf(a, b)

    func Fmap(f func(Pair) Pair, tail Tail) Tail

    func Iter(a ...Pair) (tail Tail)

    func Mult(a, b Iterable) Tail
    func Prod(a, b Iterable) Tail

---
### keep?: would look odd, if no re-alias for Cardinality, Index, Name. But: need re-alias anyway!
    func C(N int) <-chan Cardinality
    func I(N int) <-chan Index
    func At(i int) Index
    func Idx(i Index) int
    func N(n int) []struct{}

### keep: internal need:
    func NilTail() Tail


### keep: generated:
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
    func FmapIndexs(f func(Index) Index, Indexs ...Index) []Index
    func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) []interface{}
    func FmapInts(f func(int) int, ints ...int) []int
    func FmapIterable(f func(Iterable) Iterable, Iterables ...Iterable) []Iterable
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
    func FmapNames(f func(Name) Name, Names ...Name) []Name
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
    func FmapStrings(f func(string) string, strings ...string) []string
    func FmapTimeWeekdays(f func(time.Weekday) time.Weekday, timeWeekdays ...time.Weekday) []time.Weekday
    func FmapTypes(f func(Type) Type, Types ...Type) []Type

    func Join----S(ss [][]----) []----


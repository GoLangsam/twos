// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

// Attributes - Equivalence relations

// Compatible discriminates another pairs by Kind
type Compatible interface {
	SameKind(a Pair) bool
}

// Equatable
type Equatable interface {
	SameAs(a Pair) bool
}

// Order

// Comparable
type Comparable interface {
	Compatible
	Less(a Pair) int // panics if not compatible
}

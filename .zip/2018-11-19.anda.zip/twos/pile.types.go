// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/pile"
)

// Pair has two sides: Aten & Apep and may be atomic, or composed
type Pair = pile.Pair

type PairPile = pile.PileOfPair
type Naturals = pile.PileOfInt
type Symbols = pile.PileOfString
type WeekDays = pile.PileOfTimeWeekday
type TypedPile = pile.PileOfInterface

// Type is the reflect.Type
type Type = pile.Type

// TODO: Name
// TODO: Index Cardinality,
// TODO: Kind Iterable
// TODO: Head Tail
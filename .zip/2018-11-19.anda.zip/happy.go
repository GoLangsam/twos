// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package anda

// TODO:
/*
type Happiness char
type Lottery struct { // Permits to create some Boost-Formula, a Booster, going into int32
	weigth map[Happiness]int8
}

*/
type Happiness int8
const indifferent Happiness = 0

type Boost int64
type Booster func(a, b Happiness) Boost

const (
	BEST Happiness = -(iota - 2)
	GOOD
	FINE
	UGLY
	SKIP // KILL ?
)

// ### Happinesses
type happinesses func(a, b Happiness) Happiness
// Four such Happiness-Combinators are supplied:
// {Symmetric{Max,Min}, Biased{HappyAton, HappyApep}}
// Anda provides them all, aka a.Happinesses.Anda().Aton and other permutations
// For convenience specific accessors are providied.

func happyMin(a, b Happiness) Happiness {
	if a < b {
		return a
	}
	return b
}

func happyMax(a, b Happiness) Happiness {
	if a < b {
		return b
	}
	return a
}

// Idempotent
//   | * + . - X
// ==+==========
// * | *
// + |   +
// . |     .
// - |       -
// X |         X

// happyMax
//   | * + . - X
// ==+==========
// * | * * * * *
// + | * + + + +
// . | * + . . .
// - | * + . - -
// X | * + . - X

// happyMin
//   | * + . - X
// ==+==========
// * | * + . - X
// + | + + . - X
// . | . . . - X
// - | - - - - X
// X | X X X X X

// happyMaxMidMax - use the middle, and the better one if in doubt
//   | * + . - X
// ==+==========
// * | * * + + .
// + | * + + . .
// . | + + . . -
// - | + . . - -
// X | . . - - X

// happyMaxMidMin - use the middle, and the lesser one if in doubt
//   | * + . - X
// ==+==========
// * | * + + . .
// + | + + . . -
// . | + . . . .
// - | . . - - X
// X | . - - X X

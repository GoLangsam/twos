package twos

import (
	"reflect"

	"github.com/GoLangsam/anda/twos/pile"
)

// Pair has two sides: Aten & Apep and may be atomic, or composed
type Pair = pile.Pair

type PairPile = pile.PileOfPair
type Naturals = pile.PileOfInt
type Symbols = pile.PileOfString
type WeekDays = pile.PileOfTimeWeekday
type TypedPile = pile.PileOfInterface

// Type is the reflect.Type
type Type = reflect.Type

// BothTypes returns the two types
func BothTypes(a Pair) (aten, apep reflect.Type) {
	aAten, aApep := a.Both()
	return reflect.TypeOf(aAten), reflect.TypeOf(aApep)
}

// BothSameType reports iff the TypeOf both sides are of the same type
func BothSameType(a Pair) bool {
	aten, apep := a.Both()
	return reflect.TypeOf(aten) == reflect.TypeOf(apep)
}

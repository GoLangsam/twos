package pile

import "fmt"

const pairFmt = "{%+v|%+v}"

// String implements fmt.Stringer
func (a *kind) String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }

// String implements fmt.Stringer
func (a Head) String() string { aten, apep := a.Both(); return fmt.Sprintf(pairFmt, aten, apep) }

// String implements fmt.Stringer
func (a Tail) String() string { aten, apep := a.Both(); return fmt.Sprintf(pairFmt, aten, apep) }

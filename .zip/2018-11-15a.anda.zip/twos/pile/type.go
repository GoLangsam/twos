package pile

// TypePair returns both types as a Pair
func TypePair(a Pair) Pair {
	aten, apep := a.Both()
	return twosReflectTypeReflectType{
		Aten: typeOf(aten),
		Apep: typeOf(apep),
	}
}

package pile

// Pair has two sides: Aten & Apep and may be atomic, or composed
type Pair interface {
	Both() (aten, apep interface{}) // both sides - whatever each type is
}

// Join TODO: Exported for testing only
func Join(a, b Pair) Pair {
	return &twosPairPair{a, b}
}

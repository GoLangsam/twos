package pile

// Name as a unique identifier - unique among its Kind
type Name string

// Kind represents a Kind/Value pair
type Kind interface {
	Kind() Kind
}

// kind represents a named type and implements Pair
type kind struct {
	Aten Name
	Apep Type
}

// newKind returns a Kind given a name and a sample of the type
func newKind(name Name, sample interface{}) Kind { return &kind{name, typeOf(sample)} }

// newType returns a Kind given a name and a Type
func newType(name Name, typ Type) Kind { return &kind{name, typ} }

func (a kind) Kind() Kind { return a }

func (a kind) Len() int { return 1 }

// Both implements Pair
func (a kind) Both() (aten, apep interface{}) { return a.Aten, a.Apep }

// Tail implements Iterable
func (a kind) Tail() func() (Head, Tail) {
	return func() (Head, Tail) { return AsHead(a), NilTail() }
}

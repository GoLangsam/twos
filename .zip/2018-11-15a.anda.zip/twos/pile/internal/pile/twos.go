package pile

import (
	"github.com/GoLangsam/anda/twos/pile"
)

type Pair = pile.Pair
type Iterable = pile.Iterable

type Head = pile.Head
type Tail = pile.Tail

func AsHead(a Pair) Head { return func() Pair { return a } }
func NilTail() Tail      { return func() (Head, Tail) { return nil, nil } }

// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This file uses geanny to pull the type specific generic code

//go:generate genny	-in pile.go	-out ../../pile_any.go		-pkg pile gen "any=interface{}"
//go:generate genny	-in pile.go	-out ../../pile_int.go		-pkg pile gen "any=int"
//go:generate genny	-in pile.go	-out ../../pile_str.go		-pkg pile gen "any=string"
//go:generate genny	-in pile.go	-out ../../pile_weekday.go	-pkg pile gen "any=time.Weekday"
//go:generate genny	-in pile.go	-out ../../pile_type.go		-pkg pile gen "any=reflect.Type"
//go:generate genny	-in pile.go	-out ../../pile_pair.go		-pkg pile gen "any=Pair"

package pile

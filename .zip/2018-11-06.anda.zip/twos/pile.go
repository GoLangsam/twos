package twos

type pairPile struct {
	name Name
	kind *Kind

	data []Pair
	look map[Pair]int8
}

func NewPairPile(name Name, kind *Kind) *pairPile {
	p := pairPile{
		name: name,
		kind: kind,
	}
	p.data = []Pair{}
	p.look = make(map[Pair]int8)
	return &p
}

func (a *pairPile)Len() int { return len(a.data) }
func (a *pairPile)At(idx int) Pair { return a.data[idx] }
func (a *pairPile)Idx(p Pair) (int, bool) { idx, ok := a.look[p]; return int(idx), ok }

func (a *pairPile)Add(p Pair) (duplicate bool) {

	if idx, duplicate := a.look[p]; duplicate {
		a.data[idx] = p
	} else {
		a.data = append(a.data, p)
		a.look[p] = int8(len(a.data))
	}
	return
}

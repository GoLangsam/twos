package twos

import (
	"fmt"
)

// Pair has two sides: Aton & Apep and may be atomic, or composed
type Pair interface{
//	Atom() (isAtom bool)            // determines iff neither side is composed
	Both() (aton, apep interface{}) // both sides - whatever each type is
//	String() string                 // implement fmt.Stringer
}

type Head func() Pair
type Tail func() (Head, Tail) //
func AsHead(a Pair) Head {	return func() Pair {		return a} }
func NilTail() Tail { 		return func() (Head, Tail) {	return nil, nil } }

func (a Tail)    Range() <-chan Pair {
	pairs := make(chan Pair)

	go func(pairs chan<- Pair, tail Tail) {
		defer close(pairs)
		for head, tail := tail(); head != nil; head, tail = tail() {
			pairs <- head()
		}
	}(pairs, a)
	return pairs
}

var _ Pair = &StrStr{}
var _ Pair = &strTwo{}
var _ Pair = &twoStr{}
var _ Pair = &twoTwo{}
var _ Pair = &Kind{}
var _ Pair = &Node{}
var _ Pair = Head(func() Pair {return nil})
var _ Pair = NilTail()

type StrStr struct { Aton string;	Apep string }
type strTwo struct { Aton string;	Apep Pair }
type twoStr struct { Aton Pair;		Apep string }
type twoTwo struct { Aton Pair;		Apep Pair }

func (a *StrStr) Atom() bool { return true }
func (a *strTwo) Atom() bool { return false }
func (a *twoStr) Atom() bool { return false }
func (a *twoTwo) Atom() bool { return false }
func (a *Kind)   Atom() bool { return true }
func (a *Node)	 Atom() bool { return a.Prev == nil && a.Next == nil }
func (a Head)	 Atom() bool { return false }
func (a Tail)	 Atom() bool { return true }

func (a *StrStr) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *strTwo) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *twoStr) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *twoTwo) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *Kind)   Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *Node)   Both() (aton, apep interface{}) { return a.Prev.Pair, a.Next.Pair }
func (a Head)    Both() (aton, apep interface{}) { return a().Both() }
func (a Tail)    Both() (aton, apep interface{}) { return a() }

const pairFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

func (a *StrStr) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *strTwo) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *twoStr) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *twoTwo) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *Kind)   String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *Node)   String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }
func (a Head)    String() string { aton, apep := a.Both(); return fmt.Sprintf(pairFmt, aton, apep) }
func (a Tail)    String() string { aton, apep := a.Both(); return fmt.Sprintf(pairFmt, aton, apep) }

func (a *StrStr) Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *strTwo) Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *twoStr) Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *twoTwo) Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *Kind)   Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *Node)   Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } } // TODO: must walk the tree
func (a Head)    Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a Tail)    Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }

/*
package twos is all about pairs. And pairs of pairs. And pairs of pairs of pairs. And pairs of pairs of pairs of pairs...

Plenty of pairs. Piles of pairs. And piles of piles of pairs. And piles of piles of piles of pairs...

You know about that nice old lady, who -when asked what the universe rests upon- said:
"Turtles! Turtles all the way down", do You not? Well, relax: there are no turtles in here.

## Pair
Any Pair has two sides, usually called `Aton` & `Apep`.

`Both(a Pair)` returns them -untyped- as `aton, apep interface{}`.

Different implementations of Pair contain (and return) different types.

( Technically, the two underlying types may be understood as the signature of the pair,
  a pair of `reflect.Type`. )

Certain combinations are predefined - be it for ease of use, be it for useful discriminations.

## Discrminate

### unary boolean - Attribute
type PairAttribute = func (Pair) bool

Predefined	- discriminates iff:
- IsNested	- the Pair is nested on one side at least.
 - IsAtomApep	-
 - IsAtomAton	-
- IsSymmetric	- the Pair has the same `reflect.Type` on .Both() sides
- IsUnit	- .Both() sides are equal

### binary boolean - Relation
type PairRelation = func (a, b Pair) bool

Predefined:
- SameSame - two Pairs of same type TODO
- AreEqual - SameSame && Aton == Apep

---
## noteworthy Pairs - combinations

### `TwoTwo` - a Pair of Pairs, Two Pairs, a Twos
An important combination is the pair of pairs, which allows to nest pairs to arbitrary depth.

`IsNested(a Pair)` discriminates iff the Pair is nested on one side at least.

Note: boolean convenience functions IsNested, IsAtomAton, IsAtomApep facilitate further discriminations.

### Tail - a Pair-Sequence
A Tail represents a sequence of Pair.

A Tail is a function which returns a Head and (another) Tail, where a Head is a function which returns a Pair.

Sooner or later, some Tail shall return nil for both functions, for Head and for Tail.
Note: A Tail must never return one nil only (and some non-nil function).

A Tail allows to iterate thru such collection.
Let tail be a Tail:
```go
	for head, tail := tail(); head != nil; head, tail = tail() {
		// do sth with head, e.g. obtain it's pair
		myPair := head()
		_ = myPair // do sth with myPair
	}
```

Note: Most predefined pairs implement Iterable: a method `Iter()` which returns a Tail.

Tail has a method `.Range() <-chan Pair` for easier iteration.
Let tail be a Tail:
```go
	for pair := range tail.Range() {
		// do sth with pair
		_ = pair
	}
```

Range is variadic - it accepts any number of PairAttribute - unary functions `func(Pair) bool`
Used this way, Range acts as an and-filter: a Pair must satisfy each and every PairAttribute.

*/
package twos

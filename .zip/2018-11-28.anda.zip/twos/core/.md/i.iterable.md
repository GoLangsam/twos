package core // import "github.com/GoLangsam/anda/twos/core"

type Iterable interface {
	Tail() Tail
}
    Iterable represents a tailor-made collection, a thread for a tailor.


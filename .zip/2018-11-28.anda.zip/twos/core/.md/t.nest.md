package core // import "github.com/GoLangsam/anda/twos/core"

type nest struct {
	Aten Pair
	Apep Pair
}
    nest represents a nested pair, a pair of pairs.


func join(a, b Pair) *nest
func (a nest) Both() (aten, apep interface{})
func (a nest) Contains(item interface{}) (contains bool)
func (a nest) Length() Cardinality
func (a nest) Tail() Tail

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// kind implements a named type
type kind struct {
	Name
	Type
}

const nilName = Name("<noName>")

type nilPair struct{}
func (a nilPair) Kind() (Name, Type) { return kind{nilName, TypeOf(nilPair{})}.Kind() }
func (a nilPair) Both() (aten, apep interface{}) { return kind{nilName, TypeOf(nilPair{})}, nil }
func (a nilPair) Length() Cardinality { return 0 }
func (a nilPair) Tail() Tail { return NilTail() }

// I wish this could be constant
var nilKind kind = kind{nilName, TypeOf(kind{})}
var nilHead Head = func() Pair { return nilPair{} }
var nilTail Tail = func() (Head, Tail) { return nil, func() (Head, Tail) {return nil, nil} }

var theKindOfName = kind{Name(TypeOf(Name(0)).Name()), TypeOf(Name(""))}
var theKindOfIndex = kind{Name(TypeOf(Index(1)).Name()), TypeOf(Index(1))}
var theKindOfCardinality = kind{Name(TypeOf(Cardinality(0)).Name()), TypeOf(Cardinality(0))}
var theKindOfKind = kind{Name(TypeOf(kind{}).Name()), TypeOf(kind{})}
var theKindOfNest = kind{Name(TypeOf(nest{}).Name()), TypeOf(nest{})}

/* kindOfKind returns the kind of a kind.				*/ func kindOfKind()		kind { return theKindOfKind }
/* kindOfName returns the kind of a Name.				*/ func kindOfName()		kind { return theKindOfName }
/* kindOfIndex returns the kind of an Index.				*/ func kindOfIndex()		kind { return theKindOfIndex }
/* kindOfCardinality returns the kind of a Cardinality.			*/ func kindOfCardinality()	kind { return theKindOfCardinality }
/* kindOfNest returns the kind of a nest.				*/ func kindOfNest()		kind { return theKindOfNest }
/* kindOfHead returns the kind of a Head.				*/ func kindOfHead(a Head)	kind {if a == nil {return kind{nilName, TypeOf(nilHead)}   }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfTail returns the kind of a Tail.				*/ func kindOfTail(a Tail)	kind {if a == nil {return kind{nilName, TypeOf(nilTail)}   }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfPair returns the kind of a Pair.				*/ func kindOfPair(a Pair)	kind {if a == nil {return kind{nilName, TypeOf(nilPair{})} }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }

/* Kind implements Kind by returning the Name and the Type of a.		*/ func (a kind)        Kind() (Name, Type) { return a.Name, a.Type }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Name)        Kind() (Name, Type) { return kindOfName().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Index)       Kind() (Name, Type) { return kindOfIndex().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Cardinality) Kind() (Name, Type) { return kindOfCardinality().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a nest)        Kind() (Name, Type) { return kindOfNest().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Head)        Kind() (Name, Type) { return kindOfHead(a).Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Tail)        Kind() (Name, Type) { return kindOfTail(a).Kind() }

// ===========================================================================

/* Both implements Pair by returning the Name and the Type.		*/ func (a kind)        Both() (aten, apep interface{}) { return a.Name, a.Type }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Name)        Both() (aten, apep interface{}) { return kindOfName(),        a }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Index)       Both() (aten, apep interface{}) { return kindOfIndex(),       a }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Cardinality) Both() (aten, apep interface{}) { return kindOfCardinality(), a }
/* Both implements Pair by returning both parts of a.                   */ func (a nest)        Both() (aten, apep interface{}) { return a.Aten, a.Apep }
/* Both implements Pair by returning Both() of the evaluated Head.	*/ func (a Head)        Both() (aten, apep interface{}) {
	if a == nil {return kindOfHead(a), nilHead}
	if a() == nil {return nilPair{}.Both()};	return a().Both() }
/* Both implements Pair by returning the Head and Tail a evaluates to.	*/ func (a Tail)        Both() (aten, apep interface{}) {
	if a == nil {return kindOfTail(a), nil};	return a() }

// ===========================================================================

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a kind) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Name) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Index) Tail() Tail                         { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Cardinality) Tail() Tail                   { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head for the first Pair and
// a tail for the second Pair.
func (a nest) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a.Aten }, func() (Head, Tail) { return func() Pair { return a.Apep }, NilTail() } } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Head) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// itself - idempotent, so to say.
func (a Tail) Tail() Tail                          { return a }

// ===========================================================================

func LengthOfPair(a Pair ) (length Cardinality) {
	if n, ok := a.(nest); ok { return n.Length() }
	if p, ok := a.(Pile); ok { return p.Length() }
	return
}

/* Length implements Pile by returning 1 */ func (a kind)        Length() Cardinality { return 1 }
/* Length implements Pile by returning 1 */ func (a Name)        Length() Cardinality { return 1 }
/* Length implements Pile by returning 1 */ func (a Index)       Length() Cardinality { return 1 }
/* Length implements Pile by returning 1 */ func (a Cardinality) Length() Cardinality { return 1 }

// Length implements Pile
// by returning
// the sum of the length of the two pairs.
func (a nest) Length() Cardinality { return LengthOfPair(a.Aten) + LengthOfPair(a.Apep) }

// Length implements Pile
// by returning
// the length of the pair a evaluates to
// or zero for nil
func (a Head) Length() Cardinality {
	if a == nil { return 0 }
	if a() == nil { return 0 }
	return LengthOfPair(a())
}

// Length implements Pile
// by incrementing upon traversing a.
//  Note: Complexity is O(n) due to complete traversal.
func (a Tail) Length() Cardinality {
	var i Cardinality
	for head, tail := a(); head != nil; head, tail = tail() {
		i++
	}
	return i
}

// LengthRecursive is a recursive implementation to determine the Length
// by returning zero for nil and 1 plus the recursive length of the tail a evaluates to.
//  Note: Complexity is O(n) due to recursion.
func (a Tail) LengthRecursive() Cardinality {
	head, tail := a()
	if head == nil {
		return 0
	}
	return 1 + tail.LengthRecursive()
}

// ===========================================================================

// Contains TODO

// ===========================================================================

func (a kind)        Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }
func (a Name)        Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }
func (a Index)       Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }
func (a Cardinality) Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }
func (a nest)        Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }
func (a Head)        Of(index Index) Head { if index == 1 {return func() Pair {return a}}; return nilHead }

func (a Tail)        Of(index Index) Head {
	var current Index
	for head, tail := a(); head != nil; head, tail = tail() {
		current++
		if index == current {return func() Pair {return head}}
	}
	return nilHead
}

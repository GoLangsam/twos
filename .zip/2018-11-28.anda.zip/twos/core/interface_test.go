// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

func ExampleKind_interface() {

	var _ Kind = Name("Test")
	var _ Kind = Index(4711)
	var _ Kind = Cardinality(4711)

	var _ Kind = nilPair{}
	var _, _ Kind = nest{}, &nest{}
	var _, _, _ Kind = kind{}, &kind{}, nilKind

	var _ Kind = NilTail()
	var _, _ Kind = NilTail()()

}

func ExamplePair_interface() {

	var _ Pair = Name("Test")
	var _ Pair = Index(4711)
	var _ Pair = Cardinality(4711)

	var _ Pair = nilPair{}
	var _, _ Pair = nest{}, &nest{}
	var _, _, _ Pair = kind{}, &kind{}, nilKind

	var _ Pair = NilTail()
	var _, _ Pair = NilTail()()


}

func ExamplePile_interface() {

	var _ Pile = Name("Test")
	var _ Pile = Index(4711)
	var _ Pile = Cardinality(4711)

	var _ Pile = nilPair{}
	var _, _ Pile = nest{}, &nest{}
	var _, _, _ Pile = kind{}, &kind{}, nilKind

	var _ Pile = NilTail()
	var _, _ Pile = NilTail()()

}

func ExampleIterable_interface() {

	var _ Iterable = Name("Test")
	var _ Iterable = Index(4711)
	var _ Iterable = Cardinality(4711)

	var _ Iterable = nilPair{}
	var _, _ Iterable = nest{}, &nest{}
	var _, _, _ Iterable = kind{}, &kind{}, nilKind

	var _ Iterable = NilTail()
	var _, _ Iterable = NilTail()()

}

func ExampleContainer_interface() {

	/*
	var _ Container = Name("Test")
	var _ Container = Index(4711)
	var _ Container = Cardinality(4711)

	var _ Container = NilTail()
	var _, _ Container = NilTail()()
	*/

	var _, _ Container = nest{}, &nest{}

}


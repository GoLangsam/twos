package pile // import "github.com/GoLangsam/anda/twos/pile"

type Name string
    Name as a unique identifier - unique among its Kind


func FmapNames(f func(Name) Name, Names ...Name) []Name
func JoinNameS(ss [][]Name) []Name
func (a Name) Both() (aten, apep interface{})
func (a Name) Kind() (Name, Type)
func (a Name) Length() Cardinality
func (a Name) String() string

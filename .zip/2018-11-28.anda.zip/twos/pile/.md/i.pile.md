package pile // import "github.com/GoLangsam/anda/twos/pile"

type Pile interface {
	Length() Cardinality
}
    Pile holds Length items.


func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
func JoinPileS(ss [][]Pile) []Pile

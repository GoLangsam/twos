// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

import (
	"fmt"
)

const onesFmt = " {%v} "
const twosFmt = "{ %+v | %+v }"
const nodeFmt = "{%+v<%+v>%+v}"

/* String implements fmt.Stringer */ func (a *node)             String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

/* String implements fmt.Stringer */ func (a onesOfCardinality)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfInterface)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfIterable)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfIndex)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfKind)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfName)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfPair)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfPile)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
/* String implements fmt.Stringer */ func (a onesOfType)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }

/* String implements fmt.Stringer */ func (a twosOfCardinality)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfInterface)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfIterable)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfIndex)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfKind)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfName)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfPair)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfPile)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
/* String implements fmt.Stringer */ func (a twosOfType)	String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }

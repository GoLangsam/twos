package core // import "github.com/GoLangsam/anda/twos/internal"

type onesOfanyType struct {
	Kind
	Apep anyType
}

func (a onesOfanyType) Both() (aten, apep interface{})
func (a onesOfanyType) Length() Cardinality
func (a onesOfanyType) Tail() Tail

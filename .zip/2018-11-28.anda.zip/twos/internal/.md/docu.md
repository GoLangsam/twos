package core // import "github.com/GoLangsam/anda/twos/internal"

Package core provides generic implementations such as

    - bool.go for boolean operations (And, Or, Not) on attribute functions
    - fmap.go for Fmap... and Join... for slices and read-only channels
    - pile.go for PileOf...

as well as

    - pile_test.go for basic tests of PileOf... functionalities

This package is not imported anwhere. See genny.go elsewhere for it's usage.

Note: anyType_test.go provides some test data - any client package must
provide similar data, appropiate for the target type, if pile_test.go is
generated into such package.

var isanyTypeFalse = func(a anyType) bool { ... }
var isanyTypeTrue = func(a anyType) bool { ... }
func FmapanyTypeRoC(f func(anyType) anyType, RoCs ...<-chan anyType) <-chan anyType
func assertPileOfanyTypeInterfaces()
func boolanyType()
func fmapanyType()
func pileanyType()
type Cardinality = core.Cardinality
type Head = core.Head
type Index = core.Index
type Kind = core.Kind
    func NewKind(name Name, sample interface{}) Kind
    func NewType(name Name, typ Type) Kind
type Name = core.Name
type Pair = core.Pair
type PileOfanyType struct{ ... }
    func NewPileOfanyType(name Name, items ...anyType) *PileOfanyType
type Tail = core.Tail
    func NilTail() Tail
type Type = core.Type
type anyType generic.Type
    func FmapanyTypes(f func(anyType) anyType, anyTypes ...anyType) (anyTypeS []anyType)
    func JoinanyTypeS(anyTypeSS [][]anyType) (anyTypeS []anyType)
type anyTypeIs func(anyType) bool
type lookUpanyType struct{ ... }
type lookeranyType interface{ ... }
type onesOfanyType struct{ ... }
type pileOfanyType interface{ ... }
type twosOfanyType struct{ ... }

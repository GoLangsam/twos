// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/pile"
	"github.com/GoLangsam/anda/plus"
)

type PairPile = pile.PileOfPair
type Naturals = plus.PileOfInt
type Symbols = plus.PileOfString
type WeekDays = plus.PileOfTimeWeekday
type TypedPile = pile.PileOfInterface

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

import (
	"fmt"
)


const onesFmt = "{%v}"
const twosFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

// String implements fmt.Stringer

func (a *node)                  String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

// String implements fmt.Stringer

func (a onesOfCardinality)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfInterface)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfKind)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfName)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfPair)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfPile)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfType)		String() string { return fmt.Sprintf(onesFmt, a.Apep.Name()) }

func (a twosOfCardinality)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfInterface)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfKind)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfName)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfPair)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfPile)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfType)		String() string { return fmt.Sprintf(onesFmt, a.Apep.Name()) }


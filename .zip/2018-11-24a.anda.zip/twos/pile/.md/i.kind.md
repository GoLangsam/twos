package pile // import "github.com/GoLangsam/anda/twos/pile"

type Kind interface {
	Kind() (Name, Type)
}
    Kind represents a named type


func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
func JoinKindS(ss [][]Kind) []Kind
func KindOfCardinality() Kind
func KindOfIndex() Kind
func KindOfName() Kind
type kind struct {
	Aten Name
	Apep Type
}
    kind implements a named type


func newKind(name Name, sample interface{}) *kind
func newType(name Name, typ Type) *kind
func (a kind) Both() (aten, apep interface{})
func (a kind) Kind() (Name, Type)
func (a kind) Length() Cardinality
func (a *kind) String() string
func (a kind) Tail() Tail

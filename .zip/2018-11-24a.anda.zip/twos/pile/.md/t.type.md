package pile // import "github.com/GoLangsam/anda/twos/pile"

type Type = reflect.Type
    Type is the reflect.Type


func FmapTypes(f func(Type) Type, Types ...Type) []Type
func JoinTypeS(ss [][]Type) []Type
func typeOf(a interface{}) Type

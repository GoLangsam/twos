package pile // import "github.com/GoLangsam/anda/twos/pile"

type Cardinality = cardinalNumber
    Cardinality represents a cardinal number such as the #-of items in a Pile.


func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
func JoinCardinalityS(ss [][]Cardinality) []Cardinality
func (a Cardinality) Both() (aten, apep interface{})
func (a Cardinality) Kind() (Name, Type)
func (a Cardinality) Length() Cardinality

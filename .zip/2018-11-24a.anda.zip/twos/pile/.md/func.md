func Flat(a Pair) (values []interface{})
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) []interface{}
func HaveSametree(p1, p2 Pair) (same bool)
func Idx(i Index) int
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPair(a interface{}) (isPair bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinInterfaceS(ss [][]interface{}) []interface{}
func assertNodeInterfaces()
func assertPileOfCardinalityInterfaces()
func assertPileOfIndexInterfaces()
func assertPileOfInterfaceInterfaces()
func assertPileOfIterableInterfaces()
func assertPileOfKindInterfaces()
func assertPileOfNameInterfaces()
func assertPileOfPairInterfaces()
func assertPileOfPileInterfaces()
func assertPileOfTypeInterfaces()
func bothApply(a Pair, y, n func(a interface{}))
func flat(a interface{}) []interface{}
func isAnAtom(a interface{}) (isAnAtom bool)
func mult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func multIter(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func prod(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail)
func reduceAny(a Pair, f func(Pair) interface{}, init []interface{}) []interface{}
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
    func JoinCardinalityS(ss [][]Cardinality) []Cardinality
    func multHead(aHead, bHead Head) Head
    func At(i int) Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) []Index
    func JoinIndexS(ss [][]Index) []Index
    func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) []Iterable
    func JoinIterableS(ss [][]Iterable) []Iterable
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
    func JoinKindS(ss [][]Kind) []Kind
    func NewKind(name Name, sample interface{}) Kind
    func NewName(name Name, k Kind) Kind
    func NewType(name Name, typ Type) Kind
    func FmapNames(f func(Name) Name, Names ...Name) []Name
    func JoinNameS(ss [][]Name) []Name
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
    func JoinPairS(ss [][]Pair) []Pair
    func join(a, b Pair) Pair
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
    func JoinPileS(ss [][]Pile) []Pile
    func NewPileOfCardinality(name Name, items ...Cardinality) *PileOfCardinality
    func NewPileOfIndex(name Name, items ...Index) *PileOfIndex
    func NewPileOfInterface(name Name, items ...interface{}) *PileOfInterface
    func NewPileOfIterable(name Name, items ...Iterable) *PileOfIterable
    func NewPileOfKind(name Name, items ...Kind) *PileOfKind
    func NewPileOfName(name Name, items ...Name) *PileOfName
    func NewPileOfPair(name Name, items ...Pair) *PileOfPair
    func NewPileOfPile(name Name, items ...Pile) *PileOfPile
    func NewPileOfType(name Name, items ...Type) *PileOfType
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(a, b Iterable) Tail
    func NilTail() Tail
    func Prod(a, b Iterable) Tail
    func multMult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
    func multTail(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
    func tailRecurse(a ...Pair) (tail Tail)
    func FmapTypes(f func(Type) Type, Types ...Type) []Type
    func JoinTypeS(ss [][]Type) []Type
    func TypeOf(a interface{}) Type
    func tree(a Pair) (root *node)

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// func fmap(f func(A) B, M<A>) M<B>

// Fmap implements Functor F<Pair>
func Fmap(f func(Pair) Pair, tail Tail) Tail {
	head, tail := tail()
	if head == nil || tail == nil {
		return NilTail()
	}
	return func() (Head, Tail) {
		return func() Pair { return f(head()) }, Fmap(f, tail)
	}
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// kind implements a named type
type kind struct {
	Name
	Type
}

const nilName = Name("<noName>")

type nilPair struct{}
func (a nilPair) Kind() *kind { return &kind{nilName, TypeOf(nilPair{})} }
func (a nilPair) Both() (aten, apep interface{}) { return nilPair{}.Kind(), nil }

// I wish this could be constant
var nilKind = &kind{nilName, TypeOf(&kind{})}
var nilHead Head = func() Pair { return nilPair{} }
var nilTail Tail = func() (Head, Tail) { return nil, func() (Head, Tail) {return nil, nil} }

var theKindOfName = &kind{Name(TypeOf(Name(0)).Name()), TypeOf(Name(""))}
var theKindOfIndex = &kind{Name(TypeOf(Index(1)).Name()), TypeOf(Index(1))}
var theKindOfCardinality = &kind{Name(TypeOf(Cardinality(0)).Name()), TypeOf(Cardinality(0))}

/* kindOfName returns the kind of a Name.				*/ func kindOfName()		*kind { return theKindOfName }
/* kindOfIndex returns the kind of an Index.				*/ func kindOfIndex()		*kind { return theKindOfIndex }
/* kindOfCardinality returns the kind of a Cardinality.			*/ func kindOfCardinality()	*kind { return theKindOfCardinality }
/* kindOfHead returns the kind of a Head.				*/ func kindOfHead(a Head)	*kind {if a == nil {return &kind{nilName, TypeOf(nilHead)}   }; return &kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfTail returns the kind of a Tail.				*/ func kindOfTail(a Tail)	*kind {if a == nil {return &kind{nilName, TypeOf(nilTail)}   }; return &kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfPair returns the kind of a Pair.				*/ func kindOfPair(a Pair)	*kind {if a == nil {return &kind{nilName, TypeOf(nilPair{})} }; return &kind{Name(TypeOf(a).Name()), TypeOf(a)} }

/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Cardinality) Kind() (Name, Type) { return kindOfCardinality().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Index) Kind() (Name, Type) { return kindOfIndex().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Name)  Kind() (Name, Type) { return kindOfName().Kind() }
/* Kind implements Kind which is easy here as a is a kind.			*/ func (a *kind) Kind() (Name, Type) { if a == nil {return nilKind.Kind()}; return a.Name, a.Type }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Head)  Kind() (Name, Type) { return kindOfHead(a).Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Tail)  Kind() (Name, Type) { return kindOfTail(a).Kind() }

// ===========================================================================

/* Both implements Pair by returning Name and Type.			*/ func (a *kind) Both() (name, typ interface{}) {
	if a == nil {return nilKind.Kind()};			return a.Name, a.Type }
/* Both implements Pair by returning Both() of the evalutaed Head	*/ func (a Head) Both() (aten, apep interface{}) {
	if a == nil {return kindOfHead(a), nilHead}
	if a() == nil {return nilPair{}.Kind(), nilPair{}};	return a().Both() }
/* Both implements Pair by returning the head and tail a evaluates to.	*/ func (a Tail) Both() (aten, apep interface{}) {
	if a == nil {return kindOfTail(a), nil};		return a() }

// ===========================================================================

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// Length implements Pile
// by returning zero for nil and 1 otherwise
func (a Head) Length() Cardinality {
	if a == nil { return 0 }
	if a() == nil { return 0 }
	return 1
}

// ===========================================================================

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == a ) and
// as tail the unique NilTail().
func (a Head) Tail() Tail { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// ===========================================================================

// FmapHeads establishes []Head as a Functor.
func FmapHeads(f func(Head) Head, Heads ...Head) []Head {
	HeadS := make([]Head, len(Heads))
	for _, i := range Heads {
		HeadS = append(HeadS, f(i))
	}
	return HeadS
}

// JoinHeadS helps []Head to become a Monad.
// Here it's just a list comprehension - aka Concat.
func JoinHeadS(ss [][]Head) []Head {
    s := []Head{}
    for i := range ss {
        s = append(s, ss[i]...)
    }
    return s
}

// ===========================================================================

// Fmap establishes Head as a Functor.
func (a Head) Fmap(f func(Head) Head) Head {
	return func() Pair {
		if a == nil { return nil }
		return f(a)
	}
}

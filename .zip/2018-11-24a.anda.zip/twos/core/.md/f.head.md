package core // import "github.com/GoLangsam/anda/twos/core"

type Head func() Pair
    Head is a thunk which evaluates to a Pair.


var nilHead Head = func() Pair { ... }
func FmapHeads(f func(Head) Head, Heads ...Head) []Head
func JoinHeadS(ss [][]Head) []Head
func (a Head) Both() (aten, apep interface{})
func (a Head) Fmap(f func(Head) Head) Head
func (a Head) Kind() (Name, Type)
func (a Head) Length() Cardinality
func (a Head) String() string
func (a Head) Tail() Tail

package core // import "github.com/GoLangsam/anda/twos/core"

type Pile interface {
	Length() Cardinality
}
    Pile holds Length items.


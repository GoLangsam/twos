// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This file uses geanny to pull the type specific generic code

//go:generate genny	-in ..\pile.gen\gen_pile.go	-out pile_int.go		-pkg plus gen "any=int"
//go:generate genny	-in ..\pile.gen\gen_pile.go	-out pile_str.go		-pkg plus gen "any=string"
//go:generate genny	-in ..\pile.gen\gen_pile.go	-out pile_weekday.go		-pkg plus gen "any=time.Weekday"

//go:generate genny	-in ..\pile.gen\gen_test.go	-out pile_int_test.go		-pkg plus gen "any=int"
//go:generate genny	-in ..\pile.gen\gen_test.go	-out pile_str_test.go		-pkg plus gen "any=string"
//go:generate genny	-in ..\pile.gen\gen_test.go	-out pile_weekday_test.go	-pkg plus gen "any=time.Weekday"

package plus

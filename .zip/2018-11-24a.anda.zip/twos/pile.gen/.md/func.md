func Idx(i Index) int
func assertPileOfanyInterfaces()
    func At(i int) Index
    func NewKind(name Name, sample interface{}) Kind
    func NewName(name Name, k Kind) Kind
    func NewType(name Name, typ Type) Kind
    func NewPileOfany(name Name, items ...any) *PileOfany
    func NilTail() Tail
    func TypeOf(a interface{}) Type
    func Fmapanys(f func(any) any, anys ...any) []any
    func JoinanyS(ss [][]any) []any

package pile

// Tail is a thunk
// which evaluates to
// a Head and to another Tail.
type Tail func() (Head, Tail)

// Both implements Pair
// by returning the head and tail a evaluates to.
func (a Tail) Both() (aten, apep interface{})      { return a() }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Tail) Kind() (Name, Type)                  { return Name(typeOf(a).Name()), typeOf(a)}

// Length implements Pile
// by incrementing upon traversing a.
//  Note: Complexity is O(n) due to complete traversal.
func (a Tail) Length() Cardinality {
	var i Cardinality
	for head, tail := a(); head != nil; head, tail = tail() {
		i++
	}
	return i
}

// LengthRecursive is a recursive implementation to determine the Length
// by returning zero for nil and 1 plus the recursive length of the tail a evaluates to.
//  Note: Complexity is O(n) due to recursion.
func (a Tail) LengthRecursive() Cardinality {
	head, tail := a()
	if head == nil { return 0 }
	println("head", head())
	return 1 + tail.LengthRecursive()
}

// Tail implements Iterable
// by returning
// the tail a itself - idempotent, so to say.
func (a Tail) Tail() Tail                          { return a }
//nc (a Tail) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// I wish this could be constant
var nilTail = func() (Head, Tail)                  { return nil, nil }

// NilTail is a helper, it returns the Tail which evaluates to nil, nil.
//  Note: this Tail is unique. So its the tail, not a tail.
func NilTail() Tail                                { return nilTail }

// Range returns a channel to range over.
func (a Tail) Range() <-chan Pair {
	pairs := make(chan Pair)

	go func(pairs chan<- Pair, tail Tail) {
		defer close(pairs)
		for head, tail := tail(); head != nil; head, tail = tail() {
			pairs <- head()
		}
	}(pairs, a)
	return pairs
}

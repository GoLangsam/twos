package pile

import (
	"time"
)

// let's see if we can fool genny
func testany() (Name, []any) {
	name := Name("any")
	data := []any{ int(4), Cardinality(7), time.Monday, time.Monday, "Thursday", Name("Friday") }
	return name, data
}

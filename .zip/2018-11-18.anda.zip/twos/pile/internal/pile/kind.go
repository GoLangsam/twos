package pile

// kind implements a named type
type kind struct {
	Aten Name
	Apep Type
}

// Both implements Pair
// by returning Name and Type.
func (a kind) Both() (aten, apep interface{})      { return a.Aten, a.Apep }

// Kind implements Kind
// which is easy here as a is a kind.
func (a kind) Kind() (Name, Type)                  { return a.Aten, a.Apep }

// Length implements Pile
// by constantly returning one.
func (a kind) Length() Cardinality                 { return 1 }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == a ) and
// as tail the unique NilTail().
func (a kind) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// newKind returns a fresh Kind
// given a name and a sample of the type
func newKind(name Name, sample interface{}) *kind  { return &kind{name, typeOf(sample)} }

// newType returns a fresh Kind
// given a name and a Type
func newType(name Name, typ Type) *kind            { return &kind{name, typ} }

package pile

// Cardinality represents the number of items in a Pile
type Cardinality int64

// Both implements Pair
// by returning a twice.
func (a Cardinality) Both() (aten, apep interface{}) { return a, a }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Cardinality) Kind() (Name, Type)           { return Name(typeOf(Cardinality(0)).Name()), typeOf(Cardinality(0))}

// Length implements Pile
// by constantly returning one.
func (a Cardinality) Length() Cardinality          { return 1 }

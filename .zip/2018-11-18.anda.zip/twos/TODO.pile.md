# TODO pile

- Fmap

- Make Tree correct: Node(interface{}

- DeKind - desugar removing all *kind-details

- Pile-Index: Ordinal (Starting at 1)?

- PileOfany: provide access to duplicates

## Future maybe

- allow for small and growing lookers

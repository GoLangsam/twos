package twos

import (
	"fmt"

	"github.com/GoLangsam/anda/twos/pile"
)

type (
	StrStr struct {
		Aten string
		Apep string
	}
)

var (
	_ Pair = &StrStr{}
	_ Pair = &node{}
)

func IsEven(i int) bool { return i&1 == 0 }

func (a *StrStr) Length() pile.Cardinality         { return 1 }

//nc (a *node)		Len() int { return 1 }

/*
func (a *StrStr)	Atom() bool { return true }
func (a *node)		Atom() bool { return a.Prev == nil && a.Next == nil }
func (a Head)		Atom() bool { return false }
func (a Tail)		Atom() bool { return true }
*/

func (a *StrStr) Both() (aten, apep interface{})   { return a.Aten, a.Apep }
func (a *node) Both() (aten, apep interface{})     { return a.Prev.Pair, a.Next.Pair }

const pairFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

func (a *StrStr) String() string                   { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *node) String() string                     { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

func (a *StrStr) Tail() pile.Tail                  { return func() (pile.Head, pile.Tail) { return func() Pair { return a }, pile.NilTail() } }
func (a *node) Tail() pile.Tail                    { return func() (pile.Head, pile.Tail) { return func() Pair { return a }, pile.NilTail() } } // TODO: must walk the tree

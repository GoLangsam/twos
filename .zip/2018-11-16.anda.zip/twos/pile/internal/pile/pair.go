package pile

// Kind represents a named type
type Kind interface {
	Kind() (Name, Type)
}

// Pair has two sides: Aten & Apep and may be atomic, or composed
type Pair interface {
	Both() (aten, apep interface{}) // both sides - whatever each type is
}

// Iterable represents a tailor-made collection, a thread for a tailor.
type Iterable interface {
	Tail() Tail
}

// Pile holds Length items.
type Pile interface {
	Length() Cardinality
}

// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This file uses geanny to pull the type specific generic code

//go:generate genny	-in gen.pile.go	-out ../../pile_any.go		-pkg pile gen "any=interface{}"
//go:generate genny	-in gen.pile.go	-out ../../pile_int.go		-pkg pile gen "any=int"
//go:generate genny	-in gen.pile.go	-out ../../pile_str.go		-pkg pile gen "any=string"
//go:generate genny	-in gen.pile.go	-out ../../pile_weekday.go	-pkg pile gen "any=time.Weekday"
//go:generate genny	-in gen.pile.go	-out ../../pile_size.go		-pkg pile gen "any=Cardinality"
//go:generate genny	-in gen.pile.go	-out ../../pile_name.go		-pkg pile gen "any=Name"
//go:generate genny	-in gen.pile.go	-out ../../pile_type.go		-pkg pile gen "any=Type"
//go:generate genny	-in gen.pile.go	-out ../../pile_kind.go		-pkg pile gen "any=Kind"
//go:generate genny	-in gen.pile.go	-out ../../pile_pair.go		-pkg pile gen "any=Pair"
//go:generate genny	-in gen.pile.go	-out ../../pile_pile.go		-pkg pile gen "any=Pile"

package pile

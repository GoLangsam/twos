const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = " {%v} "
const twosFmt = "{ %+v | %+v }"

package pile // import "github.com/GoLangsam/anda/twos/pile"

type onesOfPile struct {
	ID
	Apep Pile
}

func (a onesOfPile) Both() (aten, apep interface{})
func (a onesOfPile) Length() Cardinality
func (a onesOfPile) Of(index Index) Head
func (a onesOfPile) String() string
func (a onesOfPile) Tail() Tail

package pile // import "github.com/GoLangsam/anda/twos/pile"

const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = " {%v} "
const twosFmt = "{ %+v | %+v }"
var isCardinalityFalse = func(a Cardinality) bool { ... }
var isCardinalityTrue = func(a Cardinality) bool { ... }
var isIDFalse = func(a ID) bool { ... }
var isIDTrue = func(a ID) bool { ... }
var isIndexFalse = func(a Index) bool { ... }
var isIndexTrue = func(a Index) bool { ... }
var isInterfaceFalse = func(a interface{}) bool { ... }
var isInterfaceTrue = func(a interface{}) bool { ... }
var isIterableFalse = func(a Iterable) bool { ... }
var isIterableTrue = func(a Iterable) bool { ... }
var isPairFalse = func(a Pair) bool { ... }
var isPairTrue = func(a Pair) bool { ... }
var isPileFalse = func(a Pile) bool { ... }
var isPileTrue = func(a Pile) bool { ... }
var isTypeFalse = func(a Type) bool { ... }
var isTypeTrue = func(a Type) bool { ... }
func Flat(a Pair) (values []interface{})
func FmapCardinalityRoC(f func(Cardinality) Cardinality, RoCs ...<-chan Cardinality) <-chan Cardinality
func FmapIDRoC(f func(ID) ID, RoCs ...<-chan ID) <-chan ID
func FmapIndexRoC(f func(Index) Index, RoCs ...<-chan Index) <-chan Index
func FmapInterfaceRoC(f func(interface{}) interface{}, RoCs ...<-chan interface{}) <-chan interface{}
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) (interfaceS []interface{})
func FmapIterableRoC(f func(Iterable) Iterable, RoCs ...<-chan Iterable) <-chan Iterable
func FmapPairRoC(f func(Pair) Pair, RoCs ...<-chan Pair) <-chan Pair
func FmapPileRoC(f func(Pile) Pile, RoCs ...<-chan Pile) <-chan Pile
func FmapTypeRoC(f func(Type) Type, RoCs ...<-chan Type) <-chan Type
func HaveSametree(p1, p2 Pair) (same bool)
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPair(a interface{}) (isPair bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinInterfaceS(interfaceSS [][]interface{}) (interfaceS []interface{})
func assertNodeInterfaces()
func assertPileOfCardinalityInterfaces()
func assertPileOfIDInterfaces()
func assertPileOfIndexInterfaces()
func assertPileOfInterfaceInterfaces()
func assertPileOfIterableInterfaces()
func assertPileOfPairInterfaces()
func assertPileOfPileInterfaces()
func assertPileOfTypeInterfaces()
func boolCardinality()
func boolID()
func boolIndex()
func boolInterface()
func boolIterable()
func boolPair()
func boolPile()
func boolType()
func bothApply(a Pair, y, n func(a interface{}))
func flat(a interface{}) []interface{}
func fmapCardinality()
func fmapID()
func fmapIndex()
func fmapInterface()
func fmapIterable()
func fmapPair()
func fmapPile()
func fmapType()
func isAnAtom(a interface{}) (isAnAtom bool)
func pileCardinality()
func pileID()
func pileIndex()
func pileInterface()
func pileIterable()
func pilePair()
func pilePile()
func pileType()
func reduceAny(a Pair, f func(Pair) interface{}, init []interface{}) []interface{}
type Cardinality = core.Cardinality
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) (CardinalityS []Cardinality)
    func JoinCardinalityS(CardinalitySS [][]Cardinality) (CardinalityS []Cardinality)
type CardinalityIs func(Cardinality) bool
type CardinalityS []Cardinality
type Head = core.Head
type ID = core.ID
    func FmapIDs(f func(ID) ID, IDs ...ID) (IDS []ID)
    func JoinIDS(IDSS [][]ID) (IDS []ID)
type IDIs func(ID) bool
type IDS []ID
type Index = core.Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) (IndexS []Index)
    func JoinIndexS(IndexSS [][]Index) (IndexS []Index)
type IndexIs func(Index) bool
type IndexS []Index
type Iterable = core.Iterable
    func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) (IterableS []Iterable)
    func JoinIterableS(IterableSS [][]Iterable) (IterableS []Iterable)
type IterableIs func(Iterable) bool
type IterableS []Iterable
type LookerCardinality interface{ ... }
type LookerID interface{ ... }
type LookerIndex interface{ ... }
type LookerInterface interface{ ... }
type LookerIterable interface{ ... }
type LookerPair interface{ ... }
type LookerPile interface{ ... }
type LookerType interface{ ... }
type Named = core.Named
type Pair = core.Pair
    var _ Pair = &node{}
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) (PairS []Pair)
    func JoinPairS(PairSS [][]Pair) (PairS []Pair)
type PairIs func(Pair) bool
type PairS []Pair
type Pile = core.Pile
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) (PileS []Pile)
    func JoinPileS(PileSS [][]Pile) (PileS []Pile)
type PileIs func(Pile) bool
type PileOfCardinality struct{ ... }
    func NewPileOfCardinality(name ID, items ...Cardinality) *PileOfCardinality
type PileOfID struct{ ... }
    func NewPileOfID(name ID, items ...ID) *PileOfID
type PileOfIndex struct{ ... }
    func NewPileOfIndex(name ID, items ...Index) *PileOfIndex
type PileOfInterface struct{ ... }
    func NewPileOfInterface(name ID, items ...interface{}) *PileOfInterface
type PileOfIterable struct{ ... }
    func NewPileOfIterable(name ID, items ...Iterable) *PileOfIterable
type PileOfPair struct{ ... }
    func NewPileOfPair(name ID, items ...Pair) *PileOfPair
type PileOfPile struct{ ... }
    func NewPileOfPile(name ID, items ...Pile) *PileOfPile
type PileOfType struct{ ... }
    func NewPileOfType(name ID, items ...Type) *PileOfType
type PileS []Pile
type PilerOfCardinality interface{ ... }
type PilerOfID interface{ ... }
type PilerOfIndex interface{ ... }
type PilerOfInterface interface{ ... }
type PilerOfIterable interface{ ... }
type PilerOfPair interface{ ... }
type PilerOfPile interface{ ... }
type PilerOfType interface{ ... }
type Tail = core.Tail
    func NilTail() Tail
type Type = core.Type
    func FmapTypes(f func(Type) Type, Types ...Type) (TypeS []Type)
    func JoinTypeS(TypeSS [][]Type) (TypeS []Type)
    func TypeOf(a interface{}) Type
type TypeIs func(Type) bool
type TypeS []Type
type interfaceIs func(interface{}) bool
type interfaceS []interface{}
type lookUpCardinality struct{ ... }
type lookUpID struct{ ... }
type lookUpIndex struct{ ... }
type lookUpInterface struct{ ... }
type lookUpIterable struct{ ... }
type lookUpPair struct{ ... }
type lookUpPile struct{ ... }
type lookUpType struct{ ... }
type node struct{ ... }
    func tree(a Pair) (root *node)
type onesOfCardinality struct{ ... }
type onesOfID struct{ ... }
type onesOfIndex struct{ ... }
type onesOfInterface struct{ ... }
type onesOfIterable struct{ ... }
type onesOfPair struct{ ... }
type onesOfPile struct{ ... }
type onesOfType struct{ ... }
type pairOfCardinality interface{ ... }
type pairOfID interface{ ... }
type pairOfIndex interface{ ... }
type pairOfInterface interface{ ... }
type pairOfIterable interface{ ... }
type pairOfPair interface{ ... }
type pairOfPile interface{ ... }
type pairOfType interface{ ... }
type twosOfCardinality struct{ ... }
type twosOfID struct{ ... }
type twosOfIndex struct{ ... }
type twosOfInterface struct{ ... }
type twosOfIterable struct{ ... }
type twosOfPair struct{ ... }
type twosOfPile struct{ ... }
type twosOfType struct{ ... }

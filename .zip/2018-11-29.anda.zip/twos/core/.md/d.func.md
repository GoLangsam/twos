func IDs(prefix string, anz int) []string
func IsInNone(containers ...Container) func(Pair) bool
func IsInSome(containers ...Container) func(Pair) bool
func IsKind() func(Pair) bool
func IsNested() func(Pair) bool
func N(n int) []struct{}
func Names(prefix string, N int) <-chan ID
func StringOfOnes(a interface{}) string
func StringOfPair(a Pair) string
func StringOfTwos(a, b interface{}) string
func KindOfPair(a Pair) kind
func Join(a, b Pair) *nest
    func C(N int) Cardinalities
    func LengthOfPair(a Pair) (length Cardinality)
type Head func() Pair
    func At(i int) Index
    func I(N int) Indices
type Tail func() (Head, Tail)
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(factors ...Iterable) (tail Tail)
    func NilTail() Tail
    func Only(iter Iterable, pairIs func(Pair) bool) Tail
    func Prod(a, b Iterable) (tail Tail)
    func Skip(iter Iterable, pairIs func(Pair) bool) Tail
    func TypeOf(a interface{}) Type

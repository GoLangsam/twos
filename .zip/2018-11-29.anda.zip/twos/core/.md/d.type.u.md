type Cardinalities <-chan Cardinality
type Cardinality = cardinalNumber
type Container interface{ ... }
type Head func() Pair
type ID = name
type Index = ordinalNumber
type Indexed interface{ ... }
type Indices <-chan Index
type Iterable interface{ ... }
type Named interface{ ... }
type Pair interface{ ... }
type Pairs <-chan Pair
type Pile interface{ ... }
type Tail func() (Head, Tail)
type Type = reflect.Type
type cardinalNumber int64
type kind struct{ ... }
type name string
type nest struct{ ... }
type nilPair struct{}
type ordinalNumber int64
type stringer interface{ ... }

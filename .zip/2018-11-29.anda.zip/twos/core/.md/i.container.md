package core // import "github.com/GoLangsam/anda/twos/core"

type Container interface {
	Contains(item interface{}) bool
}
    Container can tell for any item whether it contains this item or not.


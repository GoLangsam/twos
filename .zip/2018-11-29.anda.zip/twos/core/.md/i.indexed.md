package core // import "github.com/GoLangsam/anda/twos/core"

type Indexed interface {
	Of(Index) Head
}
    Indexed allows to retrieve a Head Of any item by Index.


type Container interface{ ... }
type Indexed interface{ ... }
type Iterable interface{ ... }
type Named interface{ ... }
type Pair interface{ ... }
type Pile interface{ ... }
type stringer interface{ ... }

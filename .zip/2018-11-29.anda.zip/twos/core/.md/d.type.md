type Cardinalities <-chan Cardinality
type Cardinality = cardinalNumber
type Container interface{ ... }
type Head func() Pair
type ID = name
type Index = ordinalNumber
type Indexed interface{ ... }
type Indices <-chan Index
type Iterable interface{ ... }
type Named interface{ ... }
type Pair interface{ ... }
type Pairs <-chan Pair
type Pile interface{ ... }
type Tail func() (Head, Tail)
type Type = reflect.Type

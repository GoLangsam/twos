package core // import "github.com/GoLangsam/anda/twos/core"

func IDs(prefix string, anz int) []string
func IsInNone(containers ...Container) func(Pair) bool
func IsInSome(containers ...Container) func(Pair) bool
func IsKind() func(Pair) bool
func IsNested() func(Pair) bool
func N(n int) []struct{}
func Names(prefix string, N int) <-chan ID
func StringOfOnes(a interface{}) string
func StringOfPair(a Pair) string
func StringOfTwos(a, b interface{}) string
func KindOfPair(a Pair) kind
func Join(a, b Pair) *nest
type Cardinalities <-chan Cardinality
    func C(N int) Cardinalities
type Cardinality = cardinalNumber
    func LengthOfPair(a Pair) (length Cardinality)
type Container interface{ ... }
type Head func() Pair
type ID = name
type Index = ordinalNumber
    func At(i int) Index
type Indexed interface{ ... }
type Indices <-chan Index
    func I(N int) Indices
type Iterable interface{ ... }
type Named interface{ ... }
type Pair interface{ ... }
type Pairs <-chan Pair
type Pile interface{ ... }
type Tail func() (Head, Tail)
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(factors ...Iterable) (tail Tail)
    func NilTail() Tail
    func Only(iter Iterable, pairIs func(Pair) bool) Tail
    func Prod(a, b Iterable) (tail Tail)
    func Skip(iter Iterable, pairIs func(Pair) bool) Tail
type Type = reflect.Type
    func TypeOf(a interface{}) Type

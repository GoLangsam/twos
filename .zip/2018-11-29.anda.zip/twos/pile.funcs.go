// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/pile"
)

func IsPairOfPairs(a Pair) (isPairOfPairs bool) {
	return pile.IsPairOfPairs(a)
}

func IsNested(a Pair) (isNested bool) {
	return pile.IsNested(a)
}

func IsAtom(a Pair) (isAtom bool) {
	return pile.IsAtom(a)
}

func IsAtomAten(a Pair) (isAtomAten bool) {
	return pile.IsAtomAten(a)
}

func IsAtomApep(a Pair) (isAtomApep bool) {
	return pile.IsAtomApep(a)
}

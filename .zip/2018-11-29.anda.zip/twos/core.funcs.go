// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/core"
)

// Join returns a pair of pairs - a nested pair.
func Join(a, b Pair) Pair {
	return core.Join(a, b)
}

func Iter(a ...Pair) (tail Tail) {
	return core.Iter(a...)
}

// ---

func N(n int) []struct{} {
	return core.N(n)
}

// TODO: C I

// ---


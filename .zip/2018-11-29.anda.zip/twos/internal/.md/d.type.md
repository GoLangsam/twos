provide similar data, appropiate for the target type, if pile_test.go is
type Cardinality = core.Cardinality
type Head = core.Head
type ID = core.ID
type Index = core.Index
type LookeranyType interface{ ... }
type Pair = core.Pair
type PileOfanyType struct{ ... }
type PilerOfanyType interface{ ... }
type Tail = core.Tail
type Type = core.Type

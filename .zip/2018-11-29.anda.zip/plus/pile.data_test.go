// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package plus

import (
	"time"
)

// let's see if we can fool genny
func testInt() (ID, []int) {
	name := ID(TypeOf(int(0)).Name())
	data := []int{ 4, 7, 1, 1, 5, 6} // Note: One duplicate!
	return name, data
}

func testString() (ID, []string) {
	name := ID(TypeOf(string("test")).Name())
	data := []string{ "4", "7", "1", "1", "5", "6"} // Note: One duplicate!
	return name, data
}

func testTimeWeekday() (ID, []time.Weekday) {
	name := ID(TypeOf(time.Sunday).Name())
	data := []time.Weekday{
		time.Wednesday,
		time.Saturday,
		time.Monday,
		time.Monday,
		time.Thursday,
		time.Friday,
	} // Note: One duplicate!
	return name, data
}

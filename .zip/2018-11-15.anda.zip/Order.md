## Less

	Irreflexive:	Less(a, a) == false
	A-Symmetric:	Less(a, b) => !Less(b, a)
	Transitive:	Less(a, b) && Less(b, c) => Less(a, c)

## Semiorder



## Partial Order (Poset)

	LE(a, b) <==> Less(a, b) || a == b


## Preference

Human Perference: indifference is not transitive!

Wikipedia:
- Preference-based Planning (language)
- Stable marriage problem (Gale-Shapley) - rounds / iterations


## PSS Partial Solutions Set

How to deal with Tokens which occur in many preferences?

ZigZag: Max Happiness / Min Sadness / Max Happines / ...

pref := BEST
mess := BEST

- HEAD: Find some solutions SOL(pref).
  - The less #-UGLY the better.

- If there are solutions:
  - Extend each Solution SOL = SOL + (++pref); goto NEXT
  - else: pref += GOOD; goto HEAD

- NEXT: Iterate PSS (concurrent?!):
  - For all UGLY: restore all Tokens he considers(mess);
  - ++mess
  - goto HEAD





  - The Larger the better
  - The Lesser the better

- Merge:

---
## Happiness

### Terminology
Metta (Pali)
Eudaimonia (Greek) - Etymologically, it consists of the words "eu" ("good") and "daimon" ("spirit").
- https://en.wikipedia.org/wiki/Eudaimonia
- https://en.wikipedia.org/wiki/Eudaemon_(mythology)
  The eudaemon, eudaimon, or eudemon in Greek mythology was a type of daemon or genius (deity), which in turn was a kind of spirit.
  A eudaemon was regarded as a good spirit or angel, and the evil cacodaemon was its opposing spirit.
Simcha (Hebrew)
Bhutan: Gross National Happyness

---

### Happiness in our Model

Happiness is a means to assign a preference, thus giving rise to a new Happy Pair.

We may define "Happiness es" as:
 - * Best
 - + Good
 - . Fine // easy default - middle way in Buddhist view - free of attachments
 - - Ugly // no like, no easy
 - X Skip // No Way! You may never see such as the owner shall filter these away

Just: The mapping to int8 values is far from obvious! (See below)

Idea: Is the distance *+ less/equal or more than the distance +. ??? 

 | * | + | . | - | X |
 |===|===|===|===|===|
 | 2 | 1 | 0 | . | . |
 | 4 | 2 | 0 | . | . |
 | 5 | 2 | 0 | . | . |
 | 5 | 3 | 0 | . | . |


### Compare Happiness-ess - Compare Pairs of Happiness:

We have
- 5*5 = 25 Pairs, thereof
- 20 with differing members (a != b), thereof
- 10 with differing members (a > b).

Thus there are 10 * 9 = 90 different pairs with (a1 > b1) & (a2 > b2)
Remove those where a1 == a2 or b1 == b2 - how many are there?

#### Which lessening is less bad than the other?
- (Best,Good) <-> (Good,Fine)	*+ versus +.
- (Best,Good) <-> (Fine,Ugly)	*+ versus .-
- (Best,Good) <-> (Ugly,Skip)	*+ versus -X

- Depending on the answers, we may need to ask more questions!
- (Best,Good) <-> (Good,Ugly) iff (Fine,Ugly) is same or less bad than (Best,Good)

- (Best,Fine) <-> (Good,Ugly)
- (Best,Fine) <-> (Fine,Skip)

- (Best,Ugly) <-> (Good,Skip)


#### Which improve is better than the other?
- ...


  (N-1)-1 + (N-2)-1 + (N-3)-1 = N-2 + N-3 + N-4 + N-5
  (N-1)-1 + (N-2)-1 + (N-3)-1 = N-N+3 + N-N+2 + N-N+1 + N-N

6 questions, 3 answers each: left, same, right.
How many possibilities? 3*3*3*3*3*3 = 9*9*9 = 9*81 = 810-81 = 729

Start with one-spaced values around 0 (=Fine)
If d(a,b) < d(b,c)
   If b < 0 ??????

### Compare Happiness-Transitions for two, a and b:
Which one is preferred?
- a(Best,Good) <-> b(Fine,Good)
- a(Best,Fine) <-> b(Fine,Good)
- ...


### Compare Solutions
It might be




package twos

// Prod is a straightforward implementation of the Cartesian product
func Prod(a, b Iterable) Tail {
	if a == nil || b == nil {return NilTail()}

	aHead, aTail := a.Tail()()
	bHead, bTail := b.Tail()()

	return func () (Head, Tail) {
		return	func () Pair		{return Join(aHead(), bHead())},
			func () (Head, Tail)	{return mult(a, b, aHead, bHead, aTail, bTail) }
	}
}

func prod(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail) {
	head := func () Pair {return Join(aHead(), bHead())}
	tail := func () (Head, Tail) {
		bHead, bTail = bTail()
		if bHead == nil {
			aHead, aTail = aTail()
			if aHead == nil {return NilTail()()}
			bHead, bTail = b.Tail()() // reset b
		}

		return	func () Pair		{return Join(aHead(), bHead())},
			func () (Head, Tail)	{return prod(a, b, aHead, bHead, aTail, bTail) }
		}
	return head, tail
}

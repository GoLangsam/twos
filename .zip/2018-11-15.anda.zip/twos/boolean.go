package twos

type BooleanUnary func(a Pair) bool

func(a BooleanUnary) And(attribs... func(a Pair) bool) BooleanUnary {
	return And(append([]func(a Pair) bool{a}, attribs...)...)
}

func(a BooleanUnary) Or(attribs... func(a Pair) bool) BooleanUnary {
	return Or(append([]func(a Pair) bool{a}, attribs...)...)
}

func(a BooleanUnary) Not() BooleanUnary {
	return Not(a)
}

var isTrue  = func(a Pair) bool { return true }
var isFalse = func(a Pair) bool { return false }

// And evaluates to true, iff all attribs do so.
// Thus: And()() == true, as And() == isTrue.
func And(attribs ...func(a Pair) bool) BooleanUnary {

	if len(attribs) < 1 { return isTrue }

	return func(a Pair) bool {
		for _, attr := range attribs { if !attr(a) { return false } }
		return true
	}
}

// Or evaluates to true, iff at least one of the attribs does so.
// Thus: Or()() == false, as Or() == isFalse.
func Or(attribs ...func(a Pair) bool) BooleanUnary {

	if len(attribs) < 1 { return isFalse }

	return func(a Pair) bool {
		for _, attr := range attribs { if attr(a) { return true } }
		return false
	}
}

// Not evaluates to true, iff attrib evaluates to false or is nil.
// Thus: Not(nil)() == true, as Not(nil) == isTrue.
func Not(attrib func(a Pair) bool) BooleanUnary {

	if attrib == nil { return isTrue }

	return func(a Pair) bool {
		return !attrib(a)
	}
}

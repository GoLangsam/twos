package twos

// Attributes - Equivalence relations

// Compatible discriminates another pairs by Kind
type Compatible interface {
	SameKind(a Pair) bool
}

// Equatable
type Equatable interface {
	SameAs(a Pair) bool
}

// Order

// Comparable
type Comparable interface {
	Compatible
	Less(a Pair) int // panics if not compatible
}

// KindOf represents a Kind/Value pair
type KindOf interface {
	Kind() *Kind
}

// Collection

// Iterable
type Iterable interface {
	Tail() Tail
}

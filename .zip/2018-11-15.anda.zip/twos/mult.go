package twos

// Prod is a DRY implementation of the Cartesian product
func Mult(a, b Iterable) Tail {
	if a == nil || b == nil { return NilTail() }

	aHead, aTail := a.Tail()()
	bHead, bTail := b.Tail()()

	return func() (Head, Tail) {
		return multIter(a, b, aHead, bHead, aTail, bTail)
	}
}

func mult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail) {
	return multHead(aHead, bHead),
	       multTail(a, b, aHead, bHead, aTail, bTail)
}

func multMult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail {
	return func() (Head, Tail) {return mult(a, b, aHead, bHead, aTail, bTail)}
}

func multHead(aHead, bHead Head) Head {
	return func() Pair { return Join(aHead(), bHead()) }
}

func multTail(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail {
	return func() (Head, Tail) {
		bHead, bTail = bTail()
		if bHead == nil {
			aHead, aTail = aTail()
			if aHead == nil { return NilTail()() }
			bHead, bTail = b.Tail()() // reset b
		}
		return multIter(a, b, aHead, bHead, aTail, bTail)
	}
}

func multIter(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail) {
	return multHead(aHead, bHead),
	       multMult(a, b, aHead, bHead, aTail, bTail)//func() (Head, Tail) { return mult(a, b, aHead, bHead, aTail, bTail) }
}

package twos

var _ Pair = &node{}

type node struct {
	Pair Pair
	Prev *node
	Next *node
}

// tree returns the root to a binary tree representing the structure of some (eventually nested) Pair
func tree(a Pair) (root *node) {
	root = &node{a, nil, nil}

	if a == nil {return }

	aten, apep := a.Both()

	if !IsAtomAten(a) { root.Prev = tree(aten.(Pair)) }
	if !IsAtomApep(a) { root.Next = tree(apep.(Pair)) }

	return root
}

// isLeaf - a node is a leaf iff both Prev and Next are nil.
func (a *node) isLeaf() bool { return a.Prev == nil && a.Next == nil }

// walk traverses a tree depth-first,
// sending each Pair on a channel.
func (n *node) walk( ch chan<- Pair) {
	if n == nil { return }
	n.Prev.walk(ch)
	ch <- n.Pair
	n.Next.walk(ch)
}

// walker launches walk in a new goroutine,
// and returns a read-only channel of values.
func (n *node) walker() <-chan Pair {
	ch := make(chan Pair)
	go func(ch chan<- Pair) {
		n.walk(ch)
		close(ch)
	}(ch)
	return ch
}

// HaveSametree reads the Pairs from two walkers,
// which run simultaneously, in lockstep
// and returns true
// iff the trees of p1 and p2 have the same contents.
func HaveSametree(p1, p2 Pair) (same bool) {
	c1, c2 := tree(p1).walker(), tree(p2).walker()
	for {
		p1, ok1 := <-c1
		p2, ok2 := <-c2
		if !ok1 || !ok2 {
			same = ok1 == ok2
			break
		}
		if p1 != p2 {
			break
		}
	}
	for _ = range c1 {} // drain c1
	for _ = range c2 {} // drain c2
	return
}

package twos

// Iter permits to iterate through given pairs - Usage pattern:
//  for head, tail := x.Iter(); head != nil; head, tail = tail() {
//      // Beware: head is a function, an accessor!
//      _ = head() // do sth with Head's content ...
//      // or pass head to another function
//  }
func Iter(a ...Pair) (Head, Tail) {
	if len(a) < 1 {return NilTail()()}
	head := func() Pair {return a[0]}
	tail := tail(a[1:]...)
	return head, tail
}

func tail(a ...Pair) Tail {
	return func() (Head, Tail) {
		if len(a) < 1 {return NilTail()()}
		head := func() Pair {return a[0]}
		tail := tail(a[1:]...)
		return head, tail
	}
}

package twos

import (
	"github.com/GoLangsam/anda/twos"
)

type Pair = twos.Pair
type KindOf = twos.KindOf
type Iterable = twos.Iterable

type Head = twos.Head
type Tail = twos.Tail

func AsHead(a Pair) Head { return func() Pair { return a } }
func NilTail() Tail      { return func() (Head, Tail) { return nil, nil } }

type Name = twos.Name
type Kind = twos.Kind

package twos

import (
	"sync"

	"github.com/mauricelam/genny/generic"
)

type any generic.Type

type onesany struct {
	Anda *Kind
	Apep any
}

func (a onesany) Len() int                       { return 1 }
func (a onesany) Kind() (kind *Kind)             { return a.Anda }
func (a onesany) Both() (aten, apep interface{}) { return a.Anda, a.Anda }
func (a onesany) Tail() Tail                     { return func() (Head, Tail) { return AsHead(a), NilTail() } }

var _ Pair = onesany{}
var _ KindOf = onesany{}
var _ Iterable = onesany{}

type twosanyany struct {
	Aten any
	Apep any
}

func (a twosanyany) Len() int                       { return 1 }
func (a twosanyany) Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a twosanyany) Tail() Tail                     { return func() (Head, Tail) { return AsHead(a), NilTail() } }

var _ Pair = twosanyany{}
var _ Iterable = twosanyany{}

type pileOfany struct {
	Type Kind

	data []any
	look map[any]uint8

	maxIdx int
	sync.RWMutex
}

// pileany is implemented by *pileOfany
type pileany interface {
	// Pair
	// KindOf
	// Iterable
	Len() int
	At(int) any
	Idx(any) (int, bool)
	add(any) bool
	Reverse()
}

var _ Pair = &pileOfany{}
var _ Pair = new(pileOfany)
var _ KindOf = &pileOfany{}
var _ KindOf = new(pileOfany)
var _ pileany = &pileOfany{}
var _ pileany = new(pileOfany)

// var _ Iterable = &pileOfany{}
// var _ Iterable = new(pileOfany)

func newPileOfany(name Name, items ...any) *pileOfany {
	soMany := len(items)
	if soMany < 1 {
		panic("newPileOfany needs one item at least.")
	}

	p := pileOfany{
		Type:   Kind{name, typeOf(items[0])},
		maxIdx: (1 << 8) - 1,
		data:   make([]any, 0, soMany),
		look:   make(map[any]uint8, soMany),
	}
	p.Append(items...)
	return &p
}

func (a *pileOfany) Kind() (kind *Kind)             { kind = &a.Type; return }
func (a *pileOfany) Len() int                       { return len(a.data) }
func (a *pileOfany) At(idx int) any                 { return a.data[idx] }
func (a *pileOfany) Idx(item any) (int, bool)       { idx, ok := a.look[item]; return int(idx), ok }
func (a *pileOfany) Both() (aten, apep interface{}) { return a.Type.Both() }

func (a *pileOfany) Append(items ...any) (duplicates error) {
	for _, item := range items {
		if a.add(item) {
			// duplicate encountered TODO:Error
		}
	}
	return
}

func (a *pileOfany) add(item any) (duplicate bool) {

	if idx, duplicate := a.look[item]; duplicate {
		a.data[idx] = item
	} else {
		a.data = append(a.data, item)
		a.look[item] = uint8(len(a.data))
	}
	return
}

func (a *pileOfany) Reverse() {
	i := 0
	u := len(a.data) - 1
	for i < u {
		a.data[i], a.data[u] = a.data[u], a.data[i]
		a.look[a.data[i]], a.look[a.data[u]] = uint8(i), uint8(u)
		i, u = i+1, u-1
	}
}

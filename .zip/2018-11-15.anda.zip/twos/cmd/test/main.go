package main

import (
	"fmt"
	"testing"

	"github.com/GoLangsam/anda/twos"

)

func Example(T *testing.T) {
	a := &twos.StrStr{"This", "That"}
	fmt.Println(a)

	// Output:
}

func main() {
	fmt.Println("MaxInt ", uint8((1<<8)-1) )

	fmt.Println("Even 2 ", twos.IsEven(2) )
	fmt.Println("Even 3 ", twos.IsEven(3) )

	pair := func(a *twos.StrStr) twos.Pair { return a }

	a := &twos.StrStr{"This", "That"}
	x := &twos.StrStr{"foo", "bar"}
	y := &twos.StrStr{"tit", "tat"}
	z := twos.Join(x, y)
	b := twos.Join(a, a) // {This That}
	bx := twos.Join(b, pair(x)); var _ = bx
	yb := twos.Join(pair(y), b); var _ = yb
	b = twos.Join(b,z)

	fmt.Println("This a ", *a) // {This That} - not { This|That }
	fmt.Println("Atom a", twos.IsNested(a))
	fmt.Println("Aten a", twos.IsAtomAten(a))
	fmt.Println("Apep a", twos.IsAtomApep(a))

	fmt.Println("Join b", b)
	fmt.Println("Atom b", twos.IsNested(b))
	fmt.Println("Aten b", twos.IsAtomAten(b))
	fmt.Println("Apep b", twos.IsAtomApep(b))

	fmt.Println("Flat b", twos.Flat(b))

	/*
	fmt.Println("Root b", twos.tree(b))
	*/

	Int32 := twos.NewKind("Counter", int32(0))
	fmt.Println("Int32 ", Int32)

	/*
	aNode := twos.NewKind("Node   ", &twos.node{})
	fmt.Println("aNode ", aNode)
	*/

	f := func(a twos.Pair) twos.Pair {
		if n, ok := a.(*twos.StrStr); ok {
			n.Aten = " <-" + n.Aten
			n.Apep = n.Apep + "-> "
			return n
		} else {
			return a
		}
	}

	fmt.Println("F(a)  ", f(a))
	fmt.Println("F(b)  ", f(b)) // {{tit|tat}|{{{ <-This|That-> }|{ <-This|That-> }}|{foo|bar}}}
}

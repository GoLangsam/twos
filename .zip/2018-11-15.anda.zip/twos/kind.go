package twos

// newKind returns a Kind given a name and a sample of the type
func newKind(name Name, sample interface{}) Kind { return Kind{name, typeOf(sample)} }

// newType returns a Kind given a name and a Type
func newType(name Name, typ Type) Kind { return Kind{name, typ} }

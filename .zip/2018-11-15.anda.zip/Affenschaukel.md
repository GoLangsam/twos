# Affenschaukel

Hin und Her zwischen Best und Skip, Good und Ugly

## Solve(max(Best))
For students := Students, tokens := Tokens(Best)

PS.Best := Solve( tokens, students )

Let PS.Best be a partial solution for Student(appointment) = Best

Two such PS.Best are similar (with respect to iteration)
iff they contain the same students and the same appointments.

## Solve(RestOf(Solve(max(Best))))

For the remaining(!) appointments and students:
tokens   = tokens - PS.Tokens(PS.Best)
students = students - PS.Students(PS.Best)

Solve( tokens, students )

Note: This is a NEW subproblem - may be tackled concurrently!

## Trade Skip for Best->Good
For all remaining Skip: If there is a student with Best, remove this and add his .Good

Solve( tokens, students )


----

less(s1, s2 solution) bool {
	// Consider the tokens left			- less is better
	// Consider #-students with appointment = Skip	- less is better
	if s1.tokens.left > s2.tokens.left { return true }
	if s1.#(Skip) > s2.#(Skip) { return true } 
	return false
}


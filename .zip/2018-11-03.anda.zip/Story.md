# Story

An authority faces a problem, which involves groups of participants and some tokens.

This authority has to come up with a solution to the problem.

The authority aims for a very good solution, That's the goal.

The authority is ready to invest considerable effort in search for such goal.

The authority is concerned about quality and about quantity.

Quantity is based on cardinality.

Quality is based on some concept of preference which participants may express toward .
- any other participant, and to
- any token


## Participants
Participants

 mindful


## Mindful
While tokens are expliticitly permitted to be mindless, the request for participants to be mindful
may easily suggest to think about participants as being humans, or living beeings, at least - whatever 'living' may mean. 

Such subconcious association -even so practical in the pursue to envision feaonalble scenarios- is not intended.

Mindful in the context of this story neither implies a participant to be a human nor an animal nor anything like such.

Yes, humans are encouraged to practice mindfulness - day by day, moment by moment.
Just: that's another story alltogether



## Preference
Preference can be understood in many different ways such as
- affinity
- best-fit
- attachment
- likeness
- similarity
- hydrophobic versus hydrophil
- happiness
  and so on.

Scientific researchers are very busy to observe preferences systematically
and to guess some underlying preference method/function approximately.

And -in the never ending quest for deep understanding- scientific research aims to improve on such guesses,
Researchers observe more carefully and more thouroughly, and refine of replace underlying models and theories.

to diminish uncertainity by 



Regarding electrons busy orbiting their nucleus in some piece of matter are known to 'prefer' or inhabit
one of a discrete number of orbits only.
(And the energylevel of such orbit is integer multiple of some basic quantum.)

For many species of animals their preference toward different kinds of food 


which can be represent 
happiness (or best-fit).


## Preference method

The authority, concerned about it's precious memory, does not dare to remember any such assignment en detail,
The authority prefers to simply get (and use) a participants preference method, if any.

No participant is neither forced to reveal his preference method nor to express his preferences.
In such case the authority may
- substitute a constant neutral method, or
- guess a suitable method by observation and/or deductive reasoning.



TODO: reference to stable marry
TODO: strict order: not required
// ## Happiness
// Happiness is a means to assign a preference, thus giving rise to a new Happy Pair.
// Any Happy Pair Chest allows access to each partition (beyond a group-Chest)
// Happiness es
//  - * Best
//  - + Good
//  - . Fine // easy default - middle way in Buddhist view - free of attachments
//  - - Ugly // no like, no easy
//  - X Kill // No Way! You may never see such as the owner shall filter these away

// TODO:
/*
type Happiness char
type Lottery struct { // Permits to create some Boost-Formula, a Booster, going into int32
	weigth map[Happiness]int8
}

*/
type Happiness int8
type Boost int32
type Booster func(a, b Happiness) Boost

type happyPile struct{
	head *happyPair          // Name & Type TODO: change to category
	vals []Happiness         // sorted list of values
	look map[Happiness]int   // inverse lookup by index
	skip Happiness           // better func(a Preference (=Pair(Pair, Happyness)) bool
	less func(i, j int) bool // comparator - do we need it? NO
}

type happyPair struct { Aton string;	Apep string } // TODO change types!
func (a *happyPair) Atom() bool { return true }
func (a *happyPair) Both() (aton, apep interface{}) { return a.Aton, a.Apep }

func NewHappiness(head *happyPair, vals... Happiness) *happyPile {
	hp := &happyPile{}
	// ... TODO
	return hp
}

const (
	BEST Happiness = -(iota - 2)
	GOOD
	FINE
	UGLY
	SKIP // KILL ?
)

// ### Happinesses
type happinesses func(a, b Happy) Happiness
// Four such Happiness-Combinators are supplied:
// {Symmetric{Max,Min}, Biased{HappyAton, HappyApep}}
// Anda provides them all, aka a.Happinesses.Anda().Aton and other permutations
// For convenience specific accessors are providied.

func happyMin(a, b Happiness) {
	if a < b {
		return a
	}
	return b
}

func happyMax(a, b Happiness) {
	if a < b {
		return b
	}
	return a
}

// Idempotent
//   | * + . - X
// ==+==========
// * | *
// + |   +
// . |     .
// - |       -
// X |         X

// happyMax
//   | * + . - X
// ==+==========
// * | * * * * *
// + | * + + + +
// . | * + . . .
// - | * + . - -
// X | * + . - X

// happyMin
//   | * + . - X
// ==+==========
// * | * + . - X
// + | + + . - X
// . | . . . - X
// - | - - - - X
// X | X X X X X

// happyMaxMidMax - use the middle, and the better one if in doubt
//   | * + . - X
// ==+==========
// * | * * + + .
// + | * + + . .
// . | + + . . -
// - | + . . - -
// X | . . - - X

// happyMaxMidMin - use the middle, and the lesser one if in doubt
//   | * + . - X
// ==+==========
// * | * + + . .
// + | + + . . -
// . | + . . . .
// - | . . - - X
// X | . - - X X

// ### HappyView
type HappyView interface {
	Part(a Happiness) *View
	Live() func() *View // all but the Skip ones
}

type View []Pair // oder besser *Pile? oder besser 'ne Zugriffsfunktion?

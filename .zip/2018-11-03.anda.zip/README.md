# Anda (Sanskrit) <=> Cosmic Egg

[![Software License](https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](LICENSE.md)
[![Go Report Card](https://goreportcard.com/badge/github.com/GoLangsam/anda)](https://goreportcard.com/report/github.com/GoLangsam/anda)
[![Build Status](https://travis-ci.org/GoLangsam/anda.svg?branch=master)](https://travis-ci.org/GoLangsam/anda)
[![GoDoc](https://godoc.org/github.com/GoLangsam/anda?status.svg)](https://godoc.org/github.com/GoLangsam/anda)

## Welcome

An unconventional cosmos for unconventional usage by unconventional players.


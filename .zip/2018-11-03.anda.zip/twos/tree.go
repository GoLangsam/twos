package twos

var _ Pair = &Node{}

type Node struct {
	Pair Pair
	Prev *Node
	Next *Node
}

// Tree returns the root to a binary tree representing the structure of some (eventually nested) Pair
func Tree(a Pair) (root *Node) {
	root.Pair = a
	if a == nil {return }

	aton, apep := a.Both()

	if IsAtomAton(a) {
		root.Prev = &Node{aton.(Pair), nil, nil}
	} else {
		root.Prev = Tree(aton.(Pair))
	}

	if IsAtomApep(a) {
		root.Prev = &Node{aton.(Pair), nil, nil}
	} else {
		root.Prev = Tree(apep.(Pair))
	}

	return root
}

func (a *Node) Atom() bool { return a.Prev == nil && a.Next == nil }
func (a *Node) Both() (aton, apep interface{}) { return a.Prev.Pair, a.Next.Pair }

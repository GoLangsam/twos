// NOTE: Oxford: MyTopics: Anda

# Anda (Sanskrit) <=> Cosmic Egg

Aten/Aton (Sun-Disk/Sun-Globe) <=> Apep (darkness&chaos) => Duat (Underworld) / Luna (moon)

- Aton represents the good stuff
- Apep represents the dark stuff

- Maat
- Troy - a system for measuring  precious metals and precious stones 

// TODO: Have Pair also implement
type Tailor interface {
	Tail() Tail
}

Rename Tail => Stitching?
Stitch, Stitcher, Stitchen, Stittching = a row of Stiches
Has humorous meaning: in stitches: laughing a lot.
A stitch in time saves nine ... (saying)



So, if type Joke = Pair, and type Stitch = Tail,
apply a stitch, and You'll get a Joke and another Stitch

sewing knitting

sew v (noun sewing is not appropiate! Has another meaning!)
v sew: to use needle and thread to make stitches
	My mother tought me how to sew.
v sew: to make, repair or attach sth using a needle and thread.
	Surgeons were able to sew the finger back on.

weaving: two-dimensional: weave = join,
weaving: to build the problem matrix
weaver: a function who can do so; or better: an iterator

tailor: The user who sews and stitches and weaves the entire problem->solution scenario

loom v,n
v loom: to appear as a large shape that is not clear, especially in a frightening or threatening way
	A problem loomed up ahead of us.
v loom: to appear important or threatening and likely to happen soon.
	There was a problem looming
n loom: a machine for twisting threads between other threads which go in a different direction
v loom large: to be worrying or frightening and seem hard to avoid
	The prospect of failure looms large.

// type fmap = func(func(A)   B,  M<A>) M<  B >
// type fmap = func(func(B) M<C>, M<B>) M<M<C>>

// type fmap = func(func(P)   P,  M<P>) M<  P >
//
// If any Pair is also a Tail this becomes

// type fmap = func(func(T)   T,  T<T>) T<  T >

func Fmap (

package anda

import (
	"github.com/GoLangsam/anda/twos"
)

// Pair has two sides: Aton & Apep
type Pair = twos.Pair

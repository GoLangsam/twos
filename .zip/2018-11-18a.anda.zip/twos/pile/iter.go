package pile

// Iter permits to iterate through given pairs - Usage pattern:
//  for head, tail := x.Iter(); head != nil; head, tail = tail() {
//      // Beware: head is a function, an accessor!
//      _ = head() // do sth with Head's content ...
//      // or pass head to another function
//  }
func Iter(a ...Pair) (tail Tail) { // TODO: Rename e.g. TailPairs
	if len(a) < 1 {
		return NilTail()
	}
	return tailRecurse(a...)
}

func tailRecurse(a ...Pair) (tail Tail) {
	return func() (head Head, tail Tail) {
		if len(a) < 1 {
			return NilTail()()
		}
		head = func() Pair { return a[0] }
		tail = tailRecurse(a[1:]...)
		return head, tail
	}
}

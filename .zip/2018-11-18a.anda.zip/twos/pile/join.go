package pile

// join returns a pair of pairs - a nested pair.
func join(a, b Pair) Pair {
	return &twosOfPair{a, b}
}

package pile

import (
	"fmt"
	"testing"

	"github.com/mauricelam/genny/generic"
)

// let's fool genny
func dummytestany(t *testing.T) {
	t.Helper()
	type any generic.Type
}

func ExampleNewPileOfany() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())
	// Output:
	// 5
}

func ExamplePileOfany_Length() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	var i Cardinality
	for head, tail := pile.Tail()(); head != nil; head, tail = tail() {
		i++
		aten, apep := head().Both()
		_, _ = aten, apep
		// fmt.Println(aten) // TODO: not easy to print this generic
		// fmt.Println(IsAtomAten(head()), IsAtomApep(head()))
	}

	fmt.Println(pile.Length(), "==", i)

	// Output:
	// 5
	// 5 == 5
}

func ExamplePileOfany_Both() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	aten, apep := pile.Both()

	_, _ = aten, apep // TODO: not easy to print this generic
	// Output:
	// 5
}

func ExamplePileOfany_Kind() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	nam_, typ_ := pile.Kind()
	_, _ = nam_, typ_

	// fmt.Println(nam_, typ_)// TODO: not easy to print this generic
	// Output:
	// 5
}

func ExamplePileOfany_At() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	var i Index
	for i = 1; i < 4; i++ {
		item := data[int(i)-1]
		if pile.At(i) != item {
			fmt.Println("At failed", i, pile.At(i), item)
		}
	}
	// Output:
	// 5
}

func ExamplePileOfany_Idx() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	var i Index
	for i = 1; i < 4; i++ {
		item := data[int(i)-1]

		idx, ok := pile.Idx(item)
		if !ok {
			fmt.Println("Idx failed to find", item, "at index", i, )
		} else if idx != i {
			fmt.Println("Idx returned", idx, "instead of", i)
		}
	}
	// Output:
	// 5
}

func ExamplePileOfany_Range() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	i := 0
	for _ = range pile.Range() {
		i++
	}

	fmt.Println(pile.Length(), "==", i)
	// Output:
	// 5
	// 5 == 5
}

func ExamplePileOfany_Random() {
	name, data := testany()
	pile := NewPileOfany(name, data...)
	fmt.Println(pile.Length())

	i := 0
	for _ = range pile.Random() {
		i++
	}

	fmt.Println(pile.Length(), "==", i)
	// Output:
	// 5
	// 5 == 5
}


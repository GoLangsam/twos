package pile

// Head is a thunk
// which evaluates to
// a Pair.
type Head func() Pair

// Both implements Pair
// by returning Both() of the evalutaed Head
func (a Head) Both() (aten, apep interface{})      { return a().Both() }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Head) Kind() (Name, Type)                  { return Name(typeOf(a).Name()), typeOf(a)}

// Length implements Pile
// by returning zero for nil and 1 otherwise
func (a Head) Length() Cardinality                 { if a == nil { return 0 }; return 1 }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == a ) and
// as tail the unique NilTail().
func (a Head) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

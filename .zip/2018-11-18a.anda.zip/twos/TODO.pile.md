# TODO pile

- Make Tree correct: Node(interface{}

- DeKind - desugar removing all *kind-details

- PileOfany: provide access to duplicates

- Copyright trailer

## Future maybe

- allow for small and growing lookers

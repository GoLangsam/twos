/*
package twos is all about pairs. (Ordered pairs.)

And pairs of pairs. And pairs of pairs of pairs. And pairs of pairs of pairs of pairs...

Plenty of pairs. Piles of pairs. And piles of piles of pairs. And piles of piles of piles of pairs...

You know about that nice old lady, who -when asked what the universe rests upon- said:
"Turtles! Turtles all the way down", do You not? Well, relax: there are no turtles in here.

See `twos.md` for more.
*/
package twos

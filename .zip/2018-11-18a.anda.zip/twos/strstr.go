package twos

import (
	"fmt"

	"github.com/GoLangsam/anda/twos/pile"
)


type StrStr struct { Aten string; Apep string }

func assertStrStrInterfaces() {
	var (
		_ Pair = &StrStr{}
	)
}

func IsEven(i int) bool { return i&1 == 0 }

func (a *StrStr) Both() (aten, apep interface{})   { return a.Aten, a.Apep }
func (a *StrStr) Length() pile.Cardinality         { return 1 }

const pairFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

func (a *StrStr) String() string                   { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *StrStr) Tail() pile.Tail                  { return func() (pile.Head, pile.Tail) { return func() Pair { return a }, pile.NilTail() } }

package twos

import (
	"github.com/GoLangsam/anda/twos/pile"
)

func IsPairOfPairs(a Pair) (isPairOfPairs bool) {
	return pile.IsPairOfPairs(a)
}

func IsNested(a Pair) (isNested bool) {
	return pile.IsNested(a)
}

func IsAtom(a Pair) (isAtom bool) {
	return pile.IsAtom(a)
}

func IsAtomAten(a Pair) (isAtomAten bool) {
	return pile.IsAtomAten(a)
}

func IsAtomApep(a Pair) (isAtomApep bool) {
	return pile.IsAtomApep(a)
}

// ---

func BothSameType(a Pair) (bothSameType bool) {
	return pile.BothSameType(a)
}

func BothTypes(a Pair) (aten, apep pile.Type) {
	return pile.BothTypes(a)
}

func Iter(a ...Pair) (head pile.Head, tail pile.Tail) {
	return pile.Iter(a...)
}

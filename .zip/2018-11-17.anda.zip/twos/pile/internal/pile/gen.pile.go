package pile

import (
	"github.com/mauricelam/genny/generic"
)

type any generic.Type

type onesOfany struct {
	Aten *kind
	Apep any
}

type twosOfany struct {
	Aten any
	Apep any
}

// PileOfany holds different items of Type kind
// accessible in order of arrival and by index.
// Reverse look-up is also supported:
// For some item its index (if any) can be retrieved.
//
// PileOfany may be seen as a kind of small ordered immutable finite set.
//
// Intentionally PileOfany implements
//  - a small set with up to 256 items only, and
//  - an immutable set: removal is not supported
//    neither is add, append or similar.
type PileOfany struct {
	Type *kind

	data []any
	look map[any]uint8
}

// pileany is implemented by *PileOfany
type pileany interface {
	// Pair
	// Kind
	// Iterable
	// Pile
	At(int) any
	Idx(any) (int, bool)
	append(items ...any) (duplicates error)
	add(any) bool
	Reverse()
}

// dummy func avoids to see these upon use of go doc -u
func assertPileOfanyInterfaces() {
	var (
		_ Pair = onesOfany{}
		_ Kind = onesOfany{}
		_ Pile = onesOfany{}
		_ Iterable = onesOfany{}

		_ Pair = twosOfany{}
		_ Pile = twosOfany{}
		_ Iterable = twosOfany{}

		_ Pair = &PileOfany{}
		_ Pair = new(PileOfany)
		_ Kind = &PileOfany{}
		_ Kind = new(PileOfany)
		_ Pile = &PileOfany{}
		_ Pile = new(PileOfany)
		_ pileany = &PileOfany{}
		_ pileany = new(PileOfany)
	)
}

// var _ Iterable = &PileOfany{}
// var _ Iterable = new(PileOfany)

// NewPileOfany returns a named Pile of items.
// There must be at least one item.
func NewPileOfany(name Name, items ...any) *PileOfany {
	soMany := len(items)
	if soMany < 1 {
		panic("newPileOfany needs one item at least.")
	} else if !(soMany < (1 << 8)) {
		panic("newPileOfany: too many items " + string(soMany))
	}

	p := PileOfany{
		Type:   &kind{name, typeOf(items[0])},
		data:   make([]any, 0, soMany),
		look:   make(map[any]uint8, soMany),
	}
	p.append(items...)
	return &p
}

// Both implements Pair
// by returning a twice.
func (a onesOfany) Both() (aten, apep interface{}) { return a.Aten, a.Apep }
// Both implements Pair
// by returning both parts of a.
func (a twosOfany) Both() (aten, apep interface{}) { return a.Aten, a.Apep }
// Both implements Pair
// by returning both parts of the Type of a.
func (a PileOfany) Both() (aten, apep interface{}) { return a.Type.Both() }

// Kind implements Kind
// by returning the Name and the Type of a.
func (a onesOfany) Kind() (Name, Type)             { return a.Aten.Aten, a.Aten.Apep}

// Kind implements Kind
// by returning the Kind of the Type of a.
func (a PileOfany) Kind() (Name, Type)             { t := a.Type; return t.Kind() }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a onesOfany) Tail() Tail                     { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a twosOfany) Tail() Tail                     { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by sucessively returning
// the items
func (a PileOfany) Tail() Tail                     { var idx int; return a.tail(idx) }

func (a PileOfany) head(idx int) Head              { return func() Pair { return onesOfany{a.Type, a.data[idx]} } }

func (a PileOfany) tail(idx int) Tail {
	if idx < len(a.data) {
		return func() (Head, Tail) {
			head := a.head(idx)
			idx++
			tail := a.tail(idx)
			return head, tail
		}
	}
	return NilTail()
}

// Length is zero for nil and is 1 otherwise
func (a onesOfany) Length() Cardinality            { return 1 }

// Length is zero for nil and is 1 otherwise
func (a twosOfany) Length() Cardinality            { return 1 }

// Length is zero for nil and is the actual len() of data otherwise
func (a PileOfany) Length() Cardinality            { if a.data == nil { return 0 }; return Cardinality(len(a.data)) }

// At returns the data at idx
func (a PileOfany) At(idx int) any                 { return a.data[idx] }

// Idx returns the index of data iff applicable
func (a PileOfany) Idx(item any) (int, bool)       { idx, ok := a.look[item]; return int(idx), ok }

// append
func (a *PileOfany) append(items ...any) (duplicates error) {
	if a == nil {
		panic("cannot append to nil PileOfany")
	}

	for _, item := range items {
		if a.add(item) {
			// duplicate encountered TODO:Error
		}
	}
	return
}

func (a *PileOfany) add(item any) (duplicate bool) {

	if idx, duplicate := a.look[item]; duplicate {
		a.data[idx] = item
	} else {
		a.look[item] = uint8(len(a.data))
		a.data = append(a.data, item)
	}
	return
}

func (a *PileOfany) Reverse() {
	if a == nil {
		panic("cannot reverse nil PileOfany")
	}

	i := 0
	u := len(a.data) - 1
	for i < u {
		a.data[i], a.data[u] = a.data[u], a.data[i]
		a.look[a.data[i]], a.look[a.data[u]] = uint8(i), uint8(u)
		i, u = i+1, u-1
	}
}

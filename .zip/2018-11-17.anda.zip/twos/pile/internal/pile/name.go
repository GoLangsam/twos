package pile

// Name as a unique identifier - unique among its Kind
type Name string

var kindOfName = &kind{Name(typeOf(Name(0)).Name()), typeOf(Name(""))}

// Both implements Pair
// by returning a twice.
func (a Name) Both() (aten, apep interface{})      { return a, a }

// Kind implements Kind
// by returning the Name of the Type and the TypeOf(a).
func (a Name) Kind() (Name, Type)                  { return kindOfName.Kind()}

// Length implements Pile
// by constantly returning one.
func (a Name) Length() Cardinality                 { return 1 }

package pile

import (
	"fmt"
	"strings"
)


const onesFmt = "{%v}"
const twosFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

//nc (a Cardinality)		String() string { return fmt.Sprintf(onesFmt, a) }
func (a Name)			String() string { return fmt.Sprintf(onesFmt, string(a)) }
//nc (a Type)			String() string { return fmt.Sprintf(onesFmt, a) }
func (a *kind)			String() string { return fmt.Sprintf(twosFmt, a.Aten, a.Apep) }
func (a *node)                  String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

func (a Head)			String() string { aten, apep := a().Both(); return fmt.Sprintf(twosFmt, aten, apep) }
func (a Tail)			String() string {
	var b strings.Builder
	fmt.Fprint(&b, "[")
	for head, tail := a(); head != nil; head, tail = tail() {
		fmt.Fprintf(&b, onesFmt, Flat(head()))
	}
	fmt.Fprint(&b, "]")
	//return fmt.Sprintln(b.String())
	return b.String()
}

// String implements fmt.Stringer
func (a onesOfCardinality)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfInt)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfInterface)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfKind)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfName)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfPair)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfPile)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfString)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfTimeWeekday)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfType)		String() string { return fmt.Sprintf(onesFmt, a.Apep.Name()) }

func (a twosOfCardinality)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfInt)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfInterface)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfKind)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfName)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfPair)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfPile)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfString)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfTimeWeekday)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfType)		String() string { return fmt.Sprintf(onesFmt, a.Apep.Name()) }

// String implements fmt.Stringer

// String implements fmt.Stringer

// String implements fmt.Stringer


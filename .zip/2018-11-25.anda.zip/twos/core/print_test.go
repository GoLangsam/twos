// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
)

func ExampleNames() {
	for i := range Names("ID-", 4) {
		fmt.Println(i)
	}
	// Output:
	// ID-1
	// ID-2
	// ID-3
	// ID-4
}

// ===========================================================================

func Example_KindOfName() {

	k := kindOfName()

	fmt.Println(k)
	// Output:
	// { Name | core.Name }
}

func Example_KindOfIndex() {

	k := kindOfIndex()

	fmt.Println(k)
	// Output:
	// { ordinalNumber | core.ordinalNumber }
}

func Example_KindOfCardinality() {

	k := kindOfCardinality()

	fmt.Println(k)
	// Output:
	// { cardinalNumber | core.cardinalNumber }
}

// ===========================================================================

func ExampleNewType() {
	_, t := NewKind("Integer", int(0)).Kind()

	k := NewType("New Type", t)

	fmt.Println(k)
	// Output:
	// { New Type | int }
}

func ExampleNewName() {
	k := NewKind("Integer", int(0))

	k = NewName("New Name", k)

	fmt.Println(k)
	// Output:
	// { New Name | int }
}

func ExampleNewKind() {
	{
		k := NewKind("A kind of a Name", NewKind("inner Kind", Name("Example")))
		fmt.Println(k, k.Name, k.Type)
	}
	{
		k := NewKind("Integer", int(0))
		fmt.Println(k)
	}
	{
		k := NewKind("String", string(""))
		fmt.Println(k)
	}
	// Output:
	// { A kind of a Name | *core.kind } A kind of a Name *core.kind
	// { Integer | int }
	// { String | string }
}

// ===========================================================================

func ExampleStringOfPair() {
	p := kindOfName() // Note: Any kind implements Pair

	s := StringOfPair(p)

	fmt.Println(s)
	// Output:
	// { Name | core.Name }
}

func ExampleDeType() {
	p := kindOfIndex() // Note: Any kind implements Pair

	s := DeType(p)

	fmt.Println(s)
	// Output:
	// ordinalNumber
}

func ExampleDeKind() {
	p := kindOfCardinality() // Note: Any kind implements Pair

	s := DeKind(p) // Note: DeKind of a Kind returns the empty string

	fmt.Println(`"` + s + `"`)
	// Output:
	// ""
}

// ===========================================================================

func Example_Nil() {

	var head Head
	var tail Tail
	var kinD *kind
	var pair Pair

	fmt.Println(kinD, "\n   OfPair:", StringOfPair(kinD), "\n   DeType:", DeType(kinD), "\n   DeKind:", DeKind(kinD), ".")
	fmt.Println(pair, "\n   OfPair:", StringOfPair(pair), "\n   DeType:", DeType(pair), "\n   DeKind:", DeKind(pair))
	fmt.Println(head, "\n   OfPair:", StringOfPair(head), "\n   DeType:", DeType(head), "\n   DeKind:", DeKind(head))
	fmt.Println(tail, "\n   OfPair:", StringOfPair(tail), "\n   DeType:", DeType(tail), "\n   DeKind:", DeKind(tail))
	fmt.Println()

	// somehow Output: is tested as differing ???
	// Output:
	// <nilKind>
	//    OfPair: { <noName> | *core.kind }
	//    DeType: <noName>
	//    DeKind:  .
	// <nil>
	//    OfPair: { { <noName> | core.nilPair } | <nil> }
	//    DeType: { <noName> | <nil> }
	//    DeKind: <nil>
	// (<nilHead>)
	//    OfPair: { { <noName> | core.Head } | { { <noName> | core.nilPair } | <nil> } }
	//    DeType: { <noName> | { <noName> | <nil> } }
	//    DeKind: { <nil> | <nil> }
	// [<nilTail>]
	//
	//    OfPair: { { <noName> | core.Tail } | <nil> }
	//    DeType: { <noName> | <nil> }
	//    DeKind: <nil>
}

func Example_NilKind() {

	var name Name
	var index Index
	var cardinality Cardinality

	var head Head
	var tail Tail
	var kinD *kind
//	var pair Pair

	{
		nam, typ := name.Kind()
		fmt.Println("name.Kind():     ", nam, typ, "   .String():", name.String(), ".")
	}
	{
		nam, typ := index.Kind()
		fmt.Println("index.Kind():    ", nam, typ, "   .String():", index.String())
	}
	{
		nam, typ := cardinality.Kind()
		fmt.Println("card.Kind():     ", nam, typ, "   .String():", cardinality.String())
	}
	fmt.Println()
	{
		nam, typ := kinD.Kind()
		fmt.Println("kinD.Kind():     ", nam, typ, "   .String():", kinD.String())
	}
	{
		nam, typ := head.Kind()
		fmt.Println("head.Kind():     ", nam, typ, "   .String():", head.String())
	}
	{
		nam, typ := tail.Kind()
		fmt.Println("tail.Kind():     ", nam, typ, "   .String():", tail.String())
	}

	// Output:
	// name.Kind():      Name core.Name    .String():  .
	// index.Kind():     ordinalNumber core.ordinalNumber    .String(): 0
	// card.Kind():      cardinalNumber core.cardinalNumber    .String(): 0
	//
	// kinD.Kind():      <noName> *core.kind    .String(): <nilKind>
	// head.Kind():      <noName> core.Head    .String(): (<nilHead>)
	// tail.Kind():      <noName> core.Tail    .String(): [<nilTail>]
}

func ExampleNilTail() {

	tail := NilTail() // Note: Any tail implements Pair

	fmt.Print(tail.String())	// Note: Any tail is wrapped in square brackets and followed by a newline
	fmt.Println(tail)		// Note: Any tail is wrapped in square brackets and followed by a newline
	fmt.Println(StringOfPair(tail))
//	fmt.Println(DeType(tail))
//	fmt.Println(DeKind(tail))
	// Output:
	// []
	// []
	//
	// { { <noName> | <nil> } | { { <noName> | <nil> } | { <noName> | <nil> } } }
	// { { <noName> | <nil> } | { { <noName> | <nil> } | { <noName> | <nil> } } }
	// { { <noName> | <nil> } | { { <noName> | <nil> } | { <noName> | <nil> } } }
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// Length implements Pile
// by incrementing upon traversing a.
//  Note: Complexity is O(n) due to complete traversal.
func (a Tail) Length() Cardinality {
	var i Cardinality
	for head, tail := a(); head != nil; head, tail = tail() {
		i++
	}
	return i
}

// LengthRecursive is a recursive implementation to determine the Length
// by returning zero for nil and 1 plus the recursive length of the tail a evaluates to.
//  Note: Complexity is O(n) due to recursion.
func (a Tail) LengthRecursive() Cardinality {
	head, tail := a()
	if head == nil {
		return 0
	}
	println("head", head())
	return 1 + tail.LengthRecursive()
}

// ===========================================================================

// Tail implements Iterable
// by returning
// the tail a itself - idempotent, so to say.
func (a Tail) Tail() Tail { return a }

// ===========================================================================

// FmapTails establishes []Tail as a Functor.
func FmapTails(f func(Tail) Tail, Tails ...Tail) []Tail {
	TailS := make([]Tail, len(Tails))
	for _, i := range Tails {
		TailS = append(TailS, f(i))
	}
	return TailS
}

// JoinTailS helps []Tail to become a Monad.
// Here it's just a list comprehension - aka Concat.
func JoinTailS(ss [][]Tail) []Tail {
    s := []Tail{}
    for i := range ss {
        s = append(s, ss[i]...)
    }
    return s
}

// ===========================================================================

// Fmap establishes Tail as a Functor.
func (a Tail) Fmap(f func(Tail) Tail) Tail {
	return func() (head Head, tail Tail) {
		head, tail = f(a)()
		if head == nil { return NilTail()()}
		tail = tail.Fmap(f)
		return
	}
}

func (a Tail) FmapHead(f func(Head) Head) Tail {
	return func() (head Head, tail Tail) {
		aHead, tail := a()
		if aHead == nil { return NilTail()()}
		head = func() Pair { return f(aHead)() }
		tail = tail.FmapHead(f)
		return
	}
}

func (a Tail) FmapPair(f func(Pair) Pair) Tail {
	return func() (head Head, tail Tail) {
		aHead, tail := a()
		if aHead == nil { return NilTail()()}
		head = func() (pair Pair) {
			pair = aHead()
			if pair != nil { pair = f(pair) }
			return
		}
		tail = tail.FmapPair(f)
		return
	}
}

// ===========================================================================

// Join helps Tail to become a Monad.
func (a Tail) Join(tails ...Tail) Tail {
	return func() (head Head, tail Tail) {
		head, tail = a()
		if head == nil {
			if len(tails) > 0 {
				head, tail = tails[0]()
				tail = tail.Join(tails[1:]...)
				return
			}
			return NilTail()()
		}
		tail = tail.Join(tails...)
		return
	}
}

// ===========================================================================

// Range returns a channel to range over.
func (a Tail) Range() Pairs {
	pairs := make(chan Pair)

	go func(pairs chan<- Pair, tail Tail) {
		defer close(pairs)
		for head, tail := tail(); head != nil; head, tail = tail() {
			pairs <- head()
		}
	}(pairs, a)
	return pairs
}

// ===========================================================================

// Sew walks a Tail and applies f to every head().
// Think of a thread and a needle...
func (a Tail) Sew(needle func(Pair) ) {
	for head, tail := a(); head != nil; head, tail = tail() {
		needle(head())
	}
}

// Reduce returns the result of applying f along the Tail.
func (a Tail) Reduce(f func(Pair, interface{}) interface{}, init interface{}) interface{} {
	for head, tail := a(); head != nil; head, tail = tail() {
		init = f(head(), init)
	}
	return init
}

// ReduceInt returns the result of applying f along the Tail.
func (a Tail) ReduceInt(f func(Pair, int) int, init int) int {
	for head, tail := a(); head != nil; head, tail = tail() {
		init = f(head(), init)
	}
	return init
}

// ReduceString returns the result of applying f along the Tail.
func (a Tail) ReduceString(f func(Pair, string) string, init string) string {
	for head, tail := a(); head != nil; head, tail = tail() {
		init = f(head(), init)
	}
	return init
}

// ===========================================================================

func DeKind(a Pair) string
func DeType(a Pair) string
func IDs(prefix string, anz int) []string
func Idx(i Index) int
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfBoth(both func() (aten, apep interface{}), stringer func(a interface{}) string) string
func StringOfPair(a Pair) string
func deKind(a interface{}) string
func deType(a interface{}) string
func getFormatWidth(prefix string, anz int) string
func getFormatWidthPaddingSpaces(anz int) string
func getFormatWidthPaddingZeros(anz int) string
func stringOf(a interface{}) string
func stringOfOnes(a interface{}) string
func stringOfTwos(aten, apep interface{}, stringer func(a interface{}) string) string
func width(anz int) int
    func C(N int) Cardinalities
type Head func() Pair
    var nilHead Head = func() Pair { ... }
    func FmapHeads(f func(Head) Head, Heads ...Head) []Head
    func JoinHeadS(ss [][]Head) []Head
    func At(i int) Index
    func I(N int) Indices
type Tail func() (Head, Tail)
    var nilTail Tail = func() (Head, Tail) { ... }
    func FmapTails(f func(Tail) Tail, Tails ...Tail) []Tail
    func JoinTailS(ss [][]Tail) []Tail
    func NilTail() Tail
    func TypeOf(a interface{}) Type
    func NewKind(name Name, sample interface{}) *kind
    func NewName(name Name, k Kind) *kind
    func NewType(name Name, typ Type) *kind
    func kindOfCardinality() *kind
    func kindOfHead(a Head) *kind
    func kindOfIndex() *kind
    func kindOfName() *kind
    func kindOfPair(a Pair) *kind
    func kindOfTail(a Tail) *kind

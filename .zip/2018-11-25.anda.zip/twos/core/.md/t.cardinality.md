package core // import "github.com/GoLangsam/anda/twos/core"

type Cardinality = cardinalNumber
    Cardinality represents a cardinal number such as the #-of items in a Pile.


func (a Cardinality) Kind() (Name, Type)
func (a Cardinality) String() string

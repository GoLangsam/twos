package pile // import "github.com/GoLangsam/anda/twos/pile.gen"

Package pile provides a generic implementation for a PileOf...

Package pile is not imported anwhere. See genny.go elsewhere for it's usage.

any_test.go provides some test data - any client package must provide
similar data, appropiate for the target type, if gen_test.go is generated
into such package.

func Idx(i Index) int
func assertPileOfanyInterfaces()
type Cardinalities = core.Cardinalities
type Cardinality = core.Cardinality
type Head = core.Head
type Index = core.Index
    func At(i int) Index
type Indices = core.Indices
type Iterable = core.Iterable
type Kind = core.Kind
    func NewKind(name Name, sample interface{}) Kind
    func NewName(name Name, k Kind) Kind
    func NewType(name Name, typ Type) Kind
type Name = core.Name
type Pair = core.Pair
type Pairs core.Pairs
type Pile = core.Pile
type PileOfany struct{ ... }
    func NewPileOfany(name Name, items ...any) *PileOfany
type Tail = core.Tail
    func NilTail() Tail
type Type = core.Type
    func TypeOf(a interface{}) Type
type any generic.Type
    func Fmapanys(f func(any) any, anys ...any) []any
    func JoinanyS(ss [][]any) []any
type lookUpany struct{ ... }
type lookerany interface{ ... }
type onesOfany struct{ ... }
type pileany interface{ ... }
type twosOfany struct{ ... }

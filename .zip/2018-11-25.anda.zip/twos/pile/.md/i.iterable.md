package pile // import "github.com/GoLangsam/anda/twos/pile"

type Iterable interface {
	Tail() Tail
}
    Iterable represents a tailor-made collection, a thread for a tailor.


func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) []Iterable
func JoinIterableS(ss [][]Iterable) []Iterable

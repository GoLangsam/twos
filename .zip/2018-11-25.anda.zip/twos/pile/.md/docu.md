package pile // import "github.com/GoLangsam/anda/twos/pile"

const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = "{%v}"
const twosFmt = "{%+v|%+v}"
func Flat(a Pair) (values []interface{})
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) []interface{}
func HaveSametree(p1, p2 Pair) (same bool)
func Idx(i Index) int
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPair(a interface{}) (isPair bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinInterfaceS(ss [][]interface{}) []interface{}
func assertNodeInterfaces()
func assertPileOfCardinalityInterfaces()
func assertPileOfIndexInterfaces()
func assertPileOfInterfaceInterfaces()
func assertPileOfIterableInterfaces()
func assertPileOfKindInterfaces()
func assertPileOfNameInterfaces()
func assertPileOfPairInterfaces()
func assertPileOfPileInterfaces()
func assertPileOfTypeInterfaces()
func bothApply(a Pair, y, n func(a interface{}))
func flat(a interface{}) []interface{}
func isAnAtom(a interface{}) (isAnAtom bool)
func prod(aHead Head, aTail, bTail, reset Tail) (head Head, tail Tail)
func reduceAny(a Pair, f func(Pair) interface{}, init []interface{}) []interface{}
type Cardinalities = core.Cardinalities
type Cardinality = core.Cardinality
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) []Cardinality
    func JoinCardinalityS(ss [][]Cardinality) []Cardinality
type Head = core.Head
type Index = core.Index
    func At(i int) Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) []Index
    func JoinIndexS(ss [][]Index) []Index
type Indices = core.Indices
type Iterable = core.Iterable
    func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) []Iterable
    func JoinIterableS(ss [][]Iterable) []Iterable
type Kind = core.Kind
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) []Kind
    func JoinKindS(ss [][]Kind) []Kind
    func NewKind(name Name, sample interface{}) Kind
    func NewName(name Name, k Kind) Kind
    func NewType(name Name, typ Type) Kind
type Name = core.Name
    func FmapNames(f func(Name) Name, Names ...Name) []Name
    func JoinNameS(ss [][]Name) []Name
type Pair = core.Pair
    var _ Pair = &node{}
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) []Pair
    func JoinPairS(ss [][]Pair) []Pair
    func join(a, b Pair) Pair
type Pairs core.Pairs
type Pile = core.Pile
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) []Pile
    func JoinPileS(ss [][]Pile) []Pile
type PileOfCardinality struct{ ... }
    func NewPileOfCardinality(name Name, items ...Cardinality) *PileOfCardinality
type PileOfIndex struct{ ... }
    func NewPileOfIndex(name Name, items ...Index) *PileOfIndex
type PileOfInterface struct{ ... }
    func NewPileOfInterface(name Name, items ...interface{}) *PileOfInterface
type PileOfIterable struct{ ... }
    func NewPileOfIterable(name Name, items ...Iterable) *PileOfIterable
type PileOfKind struct{ ... }
    func NewPileOfKind(name Name, items ...Kind) *PileOfKind
type PileOfName struct{ ... }
    func NewPileOfName(name Name, items ...Name) *PileOfName
type PileOfPair struct{ ... }
    func NewPileOfPair(name Name, items ...Pair) *PileOfPair
type PileOfPile struct{ ... }
    func NewPileOfPile(name Name, items ...Pile) *PileOfPile
type PileOfType struct{ ... }
    func NewPileOfType(name Name, items ...Type) *PileOfType
type Tail = core.Tail
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(factors ...Iterable) (tail Tail)
    func NilTail() Tail
    func Prod(a, b Iterable) (tail Tail)
    func tailRecurse(a ...Pair) (tail Tail)
type Type = core.Type
    func FmapTypes(f func(Type) Type, Types ...Type) []Type
    func JoinTypeS(ss [][]Type) []Type
    func TypeOf(a interface{}) Type
type lookUpCardinality struct{ ... }
type lookUpIndex struct{ ... }
type lookUpInterface struct{ ... }
type lookUpIterable struct{ ... }
type lookUpKind struct{ ... }
type lookUpName struct{ ... }
type lookUpPair struct{ ... }
type lookUpPile struct{ ... }
type lookUpType struct{ ... }
type lookerCardinality interface{ ... }
type lookerIndex interface{ ... }
type lookerInterface interface{ ... }
type lookerIterable interface{ ... }
type lookerKind interface{ ... }
type lookerName interface{ ... }
type lookerPair interface{ ... }
type lookerPile interface{ ... }
type lookerType interface{ ... }
type node struct{ ... }
    func tree(a Pair) (root *node)
type onesOfCardinality struct{ ... }
type onesOfIndex struct{ ... }
type onesOfInterface struct{ ... }
type onesOfIterable struct{ ... }
type onesOfKind struct{ ... }
type onesOfName struct{ ... }
type onesOfPair struct{ ... }
type onesOfPile struct{ ... }
type onesOfType struct{ ... }
type pileCardinality interface{ ... }
type pileIndex interface{ ... }
type pileInterface interface{ ... }
type pileIterable interface{ ... }
type pileKind interface{ ... }
type pileName interface{ ... }
type pilePair interface{ ... }
type pilePile interface{ ... }
type pileType interface{ ... }
type twosOfCardinality struct{ ... }
type twosOfIndex struct{ ... }
type twosOfInterface struct{ ... }
type twosOfIterable struct{ ... }
type twosOfKind struct{ ... }
type twosOfName struct{ ... }
type twosOfPair struct{ ... }
type twosOfPile struct{ ... }
type twosOfType struct{ ... }

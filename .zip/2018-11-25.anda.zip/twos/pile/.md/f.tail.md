package pile // import "github.com/GoLangsam/anda/twos/pile"

type Tail func() (Head, Tail)
    Tail is a thunk which evaluates to a Head and to another Tail.


func Fmap(f func(Pair) Pair, tail Tail) Tail
func Iter(a ...Pair) (tail Tail)
func Mult(a, b Iterable) Tail
func NilTail() Tail
func Prod(a, b Iterable) Tail
func multMult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
func multTail(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) Tail
func tailRecurse(a ...Pair) (tail Tail)
func (a Tail) Both() (aten, apep interface{})
func (a Tail) Kind() (Name, Type)
func (a Tail) Length() Cardinality
func (a Tail) LengthRecursive() Cardinality
func (a Tail) Range() <-chan Pair
func (a Tail) String() string
func (a Tail) Tail() Tail

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

import (
	"fmt"
	"testing"

	"github.com/GoLangsam/anda/twos"
	"github.com/GoLangsam/anda/twos/core"
	"github.com/GoLangsam/anda/twos/pile"
)

func Example(T *testing.T) {
	a := &twos.StrStr{"This", "That"}
	fmt.Println(a)

	// Output:
}

func main() {
	fmt.Println("MaxInt ", uint8((1<<8)-1))

	fmt.Println("Even 2 ", twos.IsEven(2))
	fmt.Println("Even 3 ", twos.IsEven(3))


	putter := pile.NewPileOfName( "Professor", "Tom" )
	getter := pile.NewPileOfName( "Student", "Alice", "Ben", "Chris", "Dave", "Eric", "Fred", "Greg", "Helen", "Ian", "Jean", "Kathy" )

	weekDays := pile.NewPileOfName( "WeekDay", "Monday", "Tuesday", "Wendsday", "Thursday", "Friday")
	dayHour := pile.NewPileOfName( "Hour",
		"08:00", "09:00", "10:00", "11:00",
		"14:00", "15:00", "16:00", "17:00",
	)

	if true {
		pile := putter
		s, t := pile.Kind.Kind()
		x, y := pile.Both()
		fmt.Println("\n# putter\t", s, t, t.Name(), x, y, pile.Length(), pile.Tail().Length())
	}

	if true {
		pile := getter
		s, t := pile.Kind.Kind()
		x, y := pile.Both()
		fmt.Println("\n# getter\t", s, t, t.Name(), x, y, pile.Length(), pile.Tail().Length())
	}

	if true {
		pile := weekDays
		s, t := pile.Kind.Kind()
		x, y := pile.Both()
		fmt.Println("\n# weekDays\t", s, t, t.Name(), x, y, pile.Length(), pile.Tail().Length())
	}

	if true {
		pile := dayHour
		s, t := pile.Kind.Kind()
		x, y := pile.Both()
		fmt.Println("\n# dayHour\t", s, t, t.Name(), x, y, pile.Length(), pile.Tail().Length())
	}

	if true {
		pile := dayHour
		s := pile.S()
		fmt.Println("\n# dayHourS\t", s)
	}

	if true {
		pile := dayHour
		fmt.Print("\n# dayHour\t")
		for head, tail := pile.Tail()(); head != nil; head, tail = tail() {
			fmt.Print(head())
		}
	}

	if true {
		pile := dayHour
		fmt.Print("\n# StringOf\t")
		for head, tail := pile.Tail()(); head != nil; head, tail = tail() {
			fmt.Print(core.StringOfPair(head()))
		}
	}

	if true {
		pile := dayHour
		fmt.Print("\n# DeType\t")
		for head, tail := pile.Tail()(); head != nil; head, tail = tail() {
			fmt.Print(core.DeType(head()))
		}
	}

	if true {
		pile := dayHour
		fmt.Print("\n# DeKind\t")
		for head, tail := pile.Tail()(); head != nil; head, tail = tail() {
			fmt.Print(core.DeKind(head()))
		}
	}


	fmt.Println("\n\n\nTokens ============================================")
	tokens := pile.Prod(weekDays, dayHour)

	if true {
		tail := tokens
		head, tail := tail()
		fmt.Println("\nHead:\t", head)
		fmt.Println("\nPair:\t", core.StringOfPair(head))
		fmt.Println("\nDeType:\t", core.DeType(head))
		fmt.Println("\nDeKind:\t", core.DeKind(head))

		fmt.Println("\nHead():\t", head())
		fmt.Println("\nPair:\t", core.StringOfPair(head()))
		fmt.Println("\nDeType:\t", core.DeType(head()))
		fmt.Println("\nDeKind:\t", core.DeKind(head()))
		fmt.Println()

		head, _ = tail()
		fmt.Println("\nHead:\t", head)
		fmt.Println("\nPair:\t", core.StringOfPair(head))
		fmt.Println("\nDeType:\t", core.DeType(head))
		fmt.Println("\nDeKind:\t", core.DeKind(head))

		fmt.Println("\nHead():\t", head())
		fmt.Println("\nPair:\t", core.StringOfPair(head()))
		fmt.Println("\nDeType:\t", core.DeType(head()))
		fmt.Println("\nDeKind:\t", core.DeKind(head()))
		fmt.Println()
	}

	if true {
		tail := tokens
		tail = tail.Printer(core.DeKind)
		fmt.Print("\nPrinter: Head:\t")
		if head, tail := tail(); head != nil {
			_ = head() // Side Effect
			head, _ := tail()
			_ = head() // Side Effect
		}
		fmt.Println()
	}

	if false {
		tail := tokens
		tail = tail.Printer(core.DeKind)
		fmt.Print("\nPrinter:\t")
		for head, tail := tail(); head != nil; head, tail = tail() {
			_ = head() // Side Effect
		}
		fmt.Println()
	}

	if false {
		tail := putter.Tail().Join(getter.Tail(), dayHour.Tail()).Printer(core.DeType)
		fmt.Print("\nPut+Get+Hour:\t")
		for head, tail := tail(); head != nil; head, tail = tail() {
			_ = head() // Side Effect
		}
		fmt.Println()
	}

	if false {
		tail := tokens
		s, t := tail.Kind()
		fmt.Println("\n# tokens\t", s, t.Name(), tail, tail.Length(), tail.Tail().Length())
	}

	if false {
		tail := tokens
		tail = tail.Printer(core.DeKind)
		fmt.Print("\nHeads:\t")
		for head, tail := tail(); head != nil; head, tail = tail() {
			_ = head() // Side Effect
		}
		fmt.Println()
	}

	if false {
		tail := tokens
		fmt.Print("\nPairs:\t")
		for head, tail := tail(); head != nil; head, tail = tail() {
			fmt.Print(head()) // Side Effect
		}
		fmt.Println()
	}

	if false {
		tail := tokens
		fmt.Print("\nKinds:\t")
		for head, tail := tail(); head != nil; head, tail = tail() {
			fmt.Print(core.DeKind(head())) // Side Effect
		}
		fmt.Println()
	}

	matrix := pile.Mult(putter, tokens, getter)

	fmt.Println("# matrix  ", matrix.Length(), matrix.Tail().Length())

	f := func(a twos.Pair) twos.Pair {
		if n, ok := a.(*twos.StrStr); ok {
			n.Aten = " <-" + n.Aten
			n.Apep = n.Apep + "-> "
			return n
		} else {
			return a
		}
	}

	head, tail := matrix()
	fmt.Println("Head of matrix:", head)
	a := head()
	b, _ := tail()


	if false {
		fmt.Println("a  ", a)
		fmt.Println("b  ", b) // {{tit|tat}|{{{ <-This|That-> }|{ <-This|That-> }}|{foo|bar}}}

		fmt.Println("F(a)  ", f(a))
		fmt.Println("F(b)  ", f(b)) // {{tit|tat}|{{{ <-This|That-> }|{ <-This|That-> }}|{foo|bar}}}
	}
}

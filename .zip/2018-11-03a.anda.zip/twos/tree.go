package twos

var _ Pair = &Node{}

type Node struct {
	Pair Pair
	Prev *Node
	Next *Node
}

// Tree returns the root to a binary tree representing the structure of some (eventually nested) Pair
func Tree(a Pair) (root *Node) {
	root = &Node{a, nil, nil}

	if a == nil {return }

	aton, apep := a.Both()

	if !IsAtomAton(a) { root.Prev = Tree(aton.(Pair)) }
	if !IsAtomApep(a) { root.Next = Tree(apep.(Pair)) }

	return root
}

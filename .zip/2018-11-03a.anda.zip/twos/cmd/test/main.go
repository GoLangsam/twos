package main

import (
	"fmt"
	"testing"

	"github.com/GoLangsam/anda/twos"

)

func Example(T *testing.T) {
	a := &twos.StrStr{"This", "That"}
	fmt.Println(a)

	// Output:
}

func main() {
	a := &twos.StrStr{"This", "That"}
	x := &twos.StrStr{"foo", "bar"}
	y := &twos.StrStr{"tit", "tat"}
	b := twos.Join(a, a)
	b = twos.Join(b, x)
	b = twos.Join(y, b)

	fmt.Println("This a ", *a)
	fmt.Println("Atom a", twos.IsAtom(a))
	fmt.Println("Aton a", twos.IsAtomAton(a))
	fmt.Println("Apep a", twos.IsAtomApep(a))

	fmt.Println("Join b", b)
	fmt.Println("Atom b", twos.IsAtom(b))
	fmt.Println("Aton b", twos.IsAtomAton(b))
	fmt.Println("Apep b", twos.IsAtomApep(b))

	fmt.Println("Flat b", twos.Flat(b))
	fmt.Println("Root b", twos.Tree(b))

	Int32 := twos.NewKind("Counter", int32(0))
	fmt.Println("Int32 ", Int32)

	aNode := twos.NewKind("Node   ", &twos.Node{})
	fmt.Println("aNode ", aNode)

}

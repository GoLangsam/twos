package twos

import (
	"fmt"
)

// Pair has two sides: Aton & Apep and may be atomic, or composed
type Pair interface{
	Atom() (isAtom bool)            // determines iff neither side is composed
	Both() (aton, apep interface{}) // both sides - whatever each type is
	String() string                 // implement fmt.Stringer
}

var _ Pair = &StrStr{}
var _ Pair = &strTwo{}
var _ Pair = &twoStr{}
var _ Pair = &twoTwo{}

type StrStr struct { Aton string;	Apep string }
type strTwo struct { Aton string;	Apep Pair }
type twoStr struct { Aton Pair;		Apep string }
type twoTwo struct { Aton Pair;		Apep Pair }

func (a *StrStr) Atom() bool { return true }
func (a *strTwo) Atom() bool { return false }
func (a *twoStr) Atom() bool { return false }
func (a *twoTwo) Atom() bool { return false }
func (a *Kind)   Atom() bool { return true }
func (a *Node)	 Atom() bool { return a.Prev == nil && a.Next == nil }

func (a *StrStr) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *strTwo) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *twoStr) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *twoTwo) Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *Kind)   Both() (aton, apep interface{}) { return a.Aton, a.Apep }
func (a *Node)   Both() (aton, apep interface{}) { return a.Prev.Pair, a.Next.Pair }

const pairFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

func (a *StrStr) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *strTwo) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *twoStr) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *twoTwo) String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *Kind)   String() string { return fmt.Sprintf(pairFmt, a.Aton, a.Apep) }
func (a *Node)   String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

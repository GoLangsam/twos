    - bool.go for boolean operations (And, Or, Not) on attribute functions
    - pile_test.go for basic tests of PileOf... functionalities
var isanyTypeFalse = func(a anyType) bool { ... }
var isanyTypeTrue = func(a anyType) bool { ... }
func FmapanyTypeRoC(f func(anyType) anyType, RoCs ...<-chan anyType) <-chan anyType
func assertPileOfanyTypeInterfaces()
func boolanyType()
func fmapanyType()
func pileanyType()
    func NewKind(name Name, sample interface{}) Kind
    func NewType(name Name, typ Type) Kind
    func NewPileOfanyType(name Name, items ...anyType) *PileOfanyType
    func NilTail() Tail
    func FmapanyTypes(f func(anyType) anyType, anyTypes ...anyType) (anyTypeS []anyType)
    func JoinanyTypeS(anyTypeSS [][]anyType) (anyTypeS []anyType)
type anyTypeIs func(anyType) bool

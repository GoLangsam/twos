// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This file uses geanny to pull the type specific generic code

//go:generate genny	-in ..\twos\internal\bool.go		-out gen.bool.go	-pkg plus gen "anyType=int,string,time.Weekday"
//go:generate genny	-in ..\twos\internal\pile.go		-out gen.pile.go	-pkg plus gen "anyType=int,string,time.Weekday"
//go:generate genny	-in ..\twos\internal\pile_test.go	-out pile_int_test.go	-pkg plus gen "anyType=int,string,time.Weekday"

package plus

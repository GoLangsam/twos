package pile // import "github.com/GoLangsam/anda/twos/pile"

func Flat(a Pair) (values []interface{})
func FmapCardinalityRoC(f func(Cardinality) Cardinality, RoCs ...<-chan Cardinality) <-chan Cardinality
func FmapIndexRoC(f func(Index) Index, RoCs ...<-chan Index) <-chan Index
func FmapInterfaceRoC(f func(interface{}) interface{}, RoCs ...<-chan interface{}) <-chan interface{}
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) (interfaceS []interface{})
func FmapIterableRoC(f func(Iterable) Iterable, RoCs ...<-chan Iterable) <-chan Iterable
func FmapKindRoC(f func(Kind) Kind, RoCs ...<-chan Kind) <-chan Kind
func FmapNameRoC(f func(Name) Name, RoCs ...<-chan Name) <-chan Name
func FmapPairRoC(f func(Pair) Pair, RoCs ...<-chan Pair) <-chan Pair
func FmapPileRoC(f func(Pile) Pile, RoCs ...<-chan Pile) <-chan Pile
func FmapTypeRoC(f func(Type) Type, RoCs ...<-chan Type) <-chan Type
func HaveSametree(p1, p2 Pair) (same bool)
func IsAtom(a Pair) (IsAtom bool)
func IsAtomApep(a Pair) (isAtomApep bool)
func IsAtomAten(a Pair) (IsAtomAten bool)
func IsNested(a Pair) (IsNested bool)
func IsPair(a interface{}) (isPair bool)
func IsPairOfPairs(a Pair) (IsPairOfPairs bool)
func JoinInterfaceS(interfaceSS [][]interface{}) (interfaceS []interface{})
type Cardinalities = core.Cardinalities
type Cardinality = core.Cardinality
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) (CardinalityS []Cardinality)
    func JoinCardinalityS(CardinalitySS [][]Cardinality) (CardinalityS []Cardinality)
type CardinalityIs func(Cardinality) bool
type Container interface{ ... }
type Head = core.Head
type Index = core.Index
    func At(i int) Index
    func FmapIndexs(f func(Index) Index, Indexs ...Index) (IndexS []Index)
    func JoinIndexS(IndexSS [][]Index) (IndexS []Index)
type IndexIs func(Index) bool
type Indices = core.Indices
type Iterable = core.Iterable
    func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) (IterableS []Iterable)
    func JoinIterableS(IterableSS [][]Iterable) (IterableS []Iterable)
type IterableIs func(Iterable) bool
type Kind = core.Kind
    func FmapKinds(f func(Kind) Kind, Kinds ...Kind) (KindS []Kind)
    func JoinKindS(KindSS [][]Kind) (KindS []Kind)
    func NewKind(name Name, sample interface{}) Kind
    func NewName(name Name, k Kind) Kind
    func NewType(name Name, typ Type) Kind
type KindIs func(Kind) bool
type Name = core.Name
    func FmapNames(f func(Name) Name, Names ...Name) (NameS []Name)
    func JoinNameS(NameSS [][]Name) (NameS []Name)
type NameIs func(Name) bool
type Pair = core.Pair
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) (PairS []Pair)
    func JoinPairS(PairSS [][]Pair) (PairS []Pair)
type PairIs func(Pair) bool
type Pairs core.Pairs
type Pile = core.Pile
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) (PileS []Pile)
    func JoinPileS(PileSS [][]Pile) (PileS []Pile)
type PileIs func(Pile) bool
type PileOfCardinality struct{ ... }
    func NewPileOfCardinality(name Name, items ...Cardinality) *PileOfCardinality
type PileOfIndex struct{ ... }
    func NewPileOfIndex(name Name, items ...Index) *PileOfIndex
type PileOfInterface struct{ ... }
    func NewPileOfInterface(name Name, items ...interface{}) *PileOfInterface
type PileOfIterable struct{ ... }
    func NewPileOfIterable(name Name, items ...Iterable) *PileOfIterable
type PileOfKind struct{ ... }
    func NewPileOfKind(name Name, items ...Kind) *PileOfKind
type PileOfName struct{ ... }
    func NewPileOfName(name Name, items ...Name) *PileOfName
type PileOfPair struct{ ... }
    func NewPileOfPair(name Name, items ...Pair) *PileOfPair
type PileOfPile struct{ ... }
    func NewPileOfPile(name Name, items ...Pile) *PileOfPile
type PileOfType struct{ ... }
    func NewPileOfType(name Name, items ...Type) *PileOfType
type Tail = core.Tail
    func NilTail() Tail
type Type = core.Type
    func FmapTypes(f func(Type) Type, Types ...Type) (TypeS []Type)
    func JoinTypeS(TypeSS [][]Type) (TypeS []Type)
    func TypeOf(a interface{}) Type
type TypeIs func(Type) bool

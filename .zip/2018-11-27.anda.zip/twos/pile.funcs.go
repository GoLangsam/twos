// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/core"
	"github.com/GoLangsam/anda/twos/pile"
)

func IsPairOfPairs(a Pair) (isPairOfPairs bool) {
	return pile.IsPairOfPairs(a)
}

func IsNested(a Pair) (isNested bool) {
	return pile.IsNested(a)
}

func IsAtom(a Pair) (isAtom bool) {
	return pile.IsAtom(a)
}

func IsAtomAten(a Pair) (isAtomAten bool) {
	return pile.IsAtomAten(a)
}

func IsAtomApep(a Pair) (isAtomApep bool) {
	return pile.IsAtomApep(a)
}

// ---

/*
func BothSameType(a Pair) (bothSameType bool) {
	return core.BothSameType(a)
}

func BothTypes(a Pair) (aten, apep Type) {
	return core.BothTypes(a)
}

// TypePair returns both types as a Pair
func TypePair(a Pair) Pair {
	return core.TypePair(a)
}
*/

// ---

func Iter(a ...Pair) (tail pile.Tail) {
	return core.Iter(a...)
}

// ---

func N(n int) []struct{} {
	return core.N(n)
}

// TODO: C I

// ---


package core // import "github.com/GoLangsam/anda/twos/core"

type Tail func() (Head, Tail)
    Tail is a thunk which evaluates to a Head and to another Tail.


var nilTail Tail = func() (Head, Tail) { ... }
func FmapTails(f func(Tail) Tail, Tails ...Tail) []Tail
func JoinTailS(ss [][]Tail) []Tail
func NilTail() Tail
func Only(iter Iterable, pairIs func(Pair) bool) Tail
func Skip(iter Iterable, pairIs func(Pair) bool) Tail
func (a Tail) Both() (aten, apep interface{})
func (a Tail) Fmap(f func(Tail) Tail) Tail
func (a Tail) FmapHead(f func(Head) Head) Tail
func (a Tail) FmapPair(f func(Pair) Pair) Tail
func (a Tail) Join(tails ...Tail) Tail
func (a Tail) Kind() (Name, Type)
func (a Tail) Length() Cardinality
func (a Tail) LengthRecursive() Cardinality
func (a Tail) Only(pairIs func(Pair) bool) Tail
func (a Tail) Printer(stringer func(a Pair) string) Tail
func (a Tail) Range() Pairs
func (a Tail) Reduce(f func(Pair, interface{}) interface{}, init interface{}) interface{}
func (a Tail) ReduceInt(f func(Pair, int) int, init int) int
func (a Tail) ReduceString(f func(Pair, string) string, init string) string
func (a Tail) Sew(needle func(Pair))
func (a Tail) Skip(pairIs func(Pair) bool) Tail
func (a Tail) String() string
func (a Tail) Tail() Tail

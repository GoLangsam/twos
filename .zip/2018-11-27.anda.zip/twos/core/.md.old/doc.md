package core // import "github.com/GoLangsam/anda/twos/core"

func DeKind(a Pair) string
func DeType(a Pair) string
func IDs(prefix string, anz int) []string
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfBoth(both func() (aten, apep interface{}), stringer func(a interface{}) string) string
func StringOfPair(a Pair) string
func NewKind(name Name, sample interface{}) *kind
func NewName(name Name, k Kind) *kind
func NewType(name Name, typ Type) *kind
type Cardinalities <-chan Cardinality
    func C(N int) Cardinalities
type Cardinality = cardinalNumber
type Head func() Pair
    func FmapHeads(f func(Head) Head, Heads ...Head) []Head
    func JoinHeadS(ss [][]Head) []Head
type Index = ordinalNumber
    func At(i int) Index
type Indices <-chan Index
    func I(N int) Indices
type Iterable interface{ ... }
type IterableIs func(Iterable) bool
type Kind interface{ ... }
type Name string
type Pair interface{ ... }
type PairIs func(Pair) bool
type Pairs <-chan Pair
type Pile interface{ ... }
type Tail func() (Head, Tail)
    func FmapTails(f func(Tail) Tail, Tails ...Tail) []Tail
    func JoinTailS(ss [][]Tail) []Tail
    func NilTail() Tail
    func Only(iter Iterable, pairIs func(Pair) bool) Tail
    func Skip(iter Iterable, pairIs func(Pair) bool) Tail
type TailIs func(Tail) bool
type Type = reflect.Type
    func TypeOf(a interface{}) Type

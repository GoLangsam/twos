// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// Length implements Pile
// by returning zero for nil and 1 otherwise
func (a Head) Length() Cardinality {
	if a == nil { return 0 }
	if a() == nil { return 0 }
	return 1
}

// ===========================================================================

// Fmap establishes Head as a Functor.
// If f == nil the identity functions is applied.
func (a Head) Fmap(f func(Head) Head) Head {
	if f == nil { f = func(a Head) Head{return a} }
	return func() Pair {
		if a == nil { return nil }
		return f(a)
	}
}

// FmapPair establishes Head as a Functor.
// If f == nil the identity functions is applied.
func (a Head) FmapPair(f func(Pair) Pair) Head {
	if f == nil { f = func(a Pair) Pair{return a} }
	return func() Pair {
		if a == nil { return nil }
		return f(a())
	}
}

package core // import "github.com/GoLangsam/anda/twos/core"

const itemFmt = "%v"
const nilName = Name("<noName>")
const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = " {%v} "
const tailBeg = "["
const tailEnd = "]\n"
const twosFmt = "{ %+v | %+v }"
var nilKind = kind{ ... }
var theKindOfCardinality = kind{ ... }
var theKindOfIndex = kind{ ... }
var theKindOfKind = kind{ ... }
var theKindOfName = kind{ ... }
func DeKind(a Pair) string
func DeType(a Pair) string
func IDs(prefix string, anz int) []string
func IsInNone(containers ...Container) func(Pair) bool
func IsInSome(containers ...Container) func(Pair) bool
func IsKind() func(Pair) bool
func IsNested() func(Pair) bool
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfPair(a Pair) string
func deKind(a interface{}) string
func deType(a interface{}) string
func getFormatWidth(prefix string, anz int) string
func getFormatWidthPaddingSpaces(anz int) string
func getFormatWidthPaddingZeros(anz int) string
func prod(aHead Head, aTail, bTail, reset Tail) (head Head, tail Tail)
func stringOf(a interface{}) string
func stringOfBoth(both func() (aten, apep interface{}), stringer func(a interface{}) string) string
func stringOfItem(a interface{}) string
func stringOfKind(a Kind, printStyle printStyle) string
func stringOfOnes(a interface{}) string
func stringOfTwoStringer(aten, apep interface{}, stringer func(a interface{}) string) string
func stringOfTwos(a, b interface{}) string
func width(anz int) int
type Cardinalities <-chan Cardinality
    func C(N int) Cardinalities
type Cardinality = cardinalNumber
type Container interface{ ... }
type Head func() Pair
    var nilHead Head = func() Pair { ... }
type Index = ordinalNumber
    func At(i int) Index
type Indices <-chan Index
    func I(N int) Indices
type Iterable interface{ ... }
type Kind interface{ ... }
type Name string
type Pair interface{ ... }
type Pairs <-chan Pair
type Pile interface{ ... }
type Tail func() (Head, Tail)
    var nilTail Tail = func() (Head, Tail) { ... }
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(factors ...Iterable) (tail Tail)
    func NilTail() Tail
    func Only(iter Iterable, pairIs func(Pair) bool) Tail
    func Prod(a, b Iterable) (tail Tail)
    func Skip(iter Iterable, pairIs func(Pair) bool) Tail
    func tailRecurse(a ...Pair) (tail Tail)
type Type = reflect.Type
    func TypeOf(a interface{}) Type
type cardinalNumber int64
type kind struct{ ... }
    func NewKind(name Name, sample interface{}) *kind
    func NewName(name Name, k Kind) *kind
    func NewType(name Name, typ Type) *kind
    func kindOfCardinality() kind
    func kindOfHead(a Head) kind
    func kindOfIndex() kind
    func kindOfKind(a kind) kind
    func kindOfName() kind
    func kindOfPair(a Pair) kind
    func kindOfTail(a Tail) kind
type nest struct{ ... }
    func join(a, b Pair) *nest
type nilPair struct{}
type ordinalNumber int64
type printStyle uint8
    const FullDetails printStyle = iota ...
type stringer interface{ ... }

package core // import "github.com/GoLangsam/anda/twos/core"

type Kind interface {
	Kind() (Name, Type)
}
    Kind represents a named type

type kind struct {
	Name
	Type
}
    kind implements a named type


func NewKind(name Name, sample interface{}) *kind
func NewName(name Name, k Kind) *kind
func NewType(name Name, typ Type) *kind
func kindOfCardinality() kind
func kindOfHead(a Head) kind
func kindOfIndex() kind
func kindOfKind(a kind) kind
func kindOfName() kind
func kindOfPair(a Pair) kind
func kindOfTail(a Tail) kind
func (a kind) Both() (name, typ interface{})
func (a kind) Kind() (Name, Type)
func (a kind) String() string
func (a kind) Tail() Tail

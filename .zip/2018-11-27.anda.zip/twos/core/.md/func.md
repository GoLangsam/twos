func DeKind(a Pair) string
func DeType(a Pair) string
func IDs(prefix string, anz int) []string
func IsInNone(containers ...Container) func(Pair) bool
func IsInSome(containers ...Container) func(Pair) bool
func IsKind() func(Pair) bool
func IsNested() func(Pair) bool
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfPair(a Pair) string
func deKind(a interface{}) string
func deType(a interface{}) string
func getFormatWidth(prefix string, anz int) string
func getFormatWidthPaddingSpaces(anz int) string
func getFormatWidthPaddingZeros(anz int) string
func prod(aHead Head, aTail, bTail, reset Tail) (head Head, tail Tail)
func stringOf(a interface{}) string
func stringOfBoth(both func() (aten, apep interface{}), stringer func(a interface{}) string) string
func stringOfItem(a interface{}) string
func stringOfKind(a Kind, printStyle printStyle) string
func stringOfOnes(a interface{}) string
func stringOfTwoStringer(aten, apep interface{}, stringer func(a interface{}) string) string
func stringOfTwos(a, b interface{}) string
func width(anz int) int
    func C(N int) Cardinalities
type Head func() Pair
    var nilHead Head = func() Pair { ... }
    func At(i int) Index
    func I(N int) Indices
type Tail func() (Head, Tail)
    var nilTail Tail = func() (Head, Tail) { ... }
    func Fmap(f func(Pair) Pair, tail Tail) Tail
    func Iter(a ...Pair) (tail Tail)
    func Mult(factors ...Iterable) (tail Tail)
    func NilTail() Tail
    func Only(iter Iterable, pairIs func(Pair) bool) Tail
    func Prod(a, b Iterable) (tail Tail)
    func Skip(iter Iterable, pairIs func(Pair) bool) Tail
    func tailRecurse(a ...Pair) (tail Tail)
    func TypeOf(a interface{}) Type
    func NewKind(name Name, sample interface{}) *kind
    func NewName(name Name, k Kind) *kind
    func NewType(name Name, typ Type) *kind
    func kindOfCardinality() kind
    func kindOfHead(a Head) kind
    func kindOfIndex() kind
    func kindOfKind(a kind) kind
    func kindOfName() kind
    func kindOfPair(a Pair) kind
    func kindOfTail(a Tail) kind
    func join(a, b Pair) *nest

const itemFmt = "%v"
const nilName = Name("<noName>")
const nodeFmt = "{%+v<%+v>%+v}"
const onesFmt = " {%v} "
const tailBeg = "["
const tailEnd = "]\n"
const twosFmt = "{ %+v | %+v }"
    const FullDetails printStyle = iota ...

package core // import "github.com/GoLangsam/anda/twos/core"

type Name string
    Name as a unique identifier - unique among its Kind


func (a Name) Both() (aten, apep interface{})
func (a Name) Kind() (Name, Type)
func (a Name) String() string
func (a Name) Tail() Tail

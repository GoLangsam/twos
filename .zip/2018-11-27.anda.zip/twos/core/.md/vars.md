var nilKind = kind{ ... }
var theKindOfCardinality = kind{ ... }
var theKindOfIndex = kind{ ... }
var theKindOfKind = kind{ ... }
var theKindOfName = kind{ ... }
    var nilHead Head = func() Pair { ... }
    var nilTail Tail = func() (Head, Tail) { ... }

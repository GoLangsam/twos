// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
	"strings"
)

const itemFmt = "%v"
const onesFmt = " {%v} "
const twosFmt = "{ %+v | %+v }"
const nodeFmt = "{%+v<%+v>%+v}"
const tailBeg = "["
const tailEnd = "]\n"

// ===========================================================================

type stringer interface {
	String() string
}

/* String implements fmt.Stringer */ func (a Name) String() string        { if a == "" {return string(nilName)}; return stringOfItem(string(a)) }
/* String implements fmt.Stringer */ func (a Index) String() string       { return stringOfItem(int(a)) }
/* String implements fmt.Stringer */ func (a Cardinality) String() string { return stringOfItem(int(a)) }
/* String implements fmt.Stringer */ func (a kind) String() string        { return stringOfTwos( a.Name, a.Type) }
/* String implements fmt.Stringer */ func (a Head) String() string        { if a == nil {return "(<nilHead>)"}; return StringOfPair(a()) }
/* String implements fmt.Stringer */ func (a Tail) String() string        {
	var b strings.Builder
	fmt.Fprint(&b, tailBeg)
	if a == nil {
		fmt.Fprintf(&b, "<nilTail>")
	} else {
		for head, tail := a(); head != nil; head, tail = tail() {
			fmt.Fprintf(&b, StringOfPair(head()))
		}
	}
	fmt.Fprint(&b, tailEnd)
	return b.String()
}

// ===========================================================================

// Printer returns a new Tail which, upon traversal,
// will print the Pair of each Head using stringer.
// Example:
//  tail := tail.Printer(DeKind)
func (a Tail) Printer(stringer func(a Pair) string) Tail {
	f := func(a Pair) Pair {
		fmt.Print(stringer(a))
		return a
	}
	return a.FmapPair(f)
}

// ===========================================================================

type printStyle uint8

const (
	FullDetails printStyle = iota
	NoType
	NoKind
)

// DeKind returns the kind-less string of a Pair
func DeKind(a Pair) string {
	if a == nil { a = nilPair{} }
	if _, ok := a.(kind); ok { return "" }
 	if k, ok := a.(Kind); ok { return stringOfKind(k, NoKind) }
	return stringOfBoth(a.Both, deKind)
}

// DeType returns the type-less string of a Pair
func DeType(a Pair) string {
	if a == nil { a = nilPair{} }
	if k, ok := a.(kind); ok { return stringOfOnes(k.Name) }
 	if k, ok := a.(Kind); ok { return stringOfKind(k, NoType) }
	return stringOfBoth(a.Both, deType)
}

// StringOfPair returns the string of a Pair
func StringOfPair(a Pair) string {
	if a == nil { a = nilPair{} }
	if k, ok := a.(Kind); ok { return stringOfKind(k, FullDetails) }
	return stringOfBoth(a.Both, stringOf)
}

func deKind(a interface{}) string {
	if _, ok := a.(kind); ok { return "" }
	if _, ok := a.(Type); ok { return "" }
	if p, ok := a.(Pair); ok { return DeKind(p) }
	return stringOfOnes(a) // = return stringOf(a) - as a is not a Pair
}

func deType(a interface{}) string {
	if k, ok := a.(kind); ok { return stringOfOnes(k.Name) }
	if _, ok := a.(Type); ok { return "" }
	if p, ok := a.(Pair); ok { return DeType(p) }
	return stringOfOnes(a) // = return stringOf(a) - as a is not a Pair
}

func stringOf(a interface{}) string {
	if p, ok := a.(Pair); ok { return StringOfPair(p) }
	return stringOfOnes(a)
}

// ===========================================================================

// stringOfKind returns the string of a Kind, optionally without type
func stringOfKind(a Kind, printStyle printStyle) string {
	p := a.(Pair)
	aten, apep := p.Both()

	switch{
	case printStyle == NoType:
		if k, ok := aten.(kind); ok { aten = k.Name }
	case printStyle == NoKind:
		if _, ok := aten.(kind); ok { aten = "" }
		if _, ok := aten.(Type); ok { aten = "" }
		if _, ok := apep.(Type); ok { apep = "" }
	}

	sten, spep := stringOfItem(aten), stringOfItem(apep)

	if sten == "" { return stringOfOnes(spep) }
	if spep == "" { return stringOfOnes(sten) }
	return stringOfTwos(sten, spep)
}

// ===========================================================================

// stringOfBoth returns a string given a both-function and a stringer-function.
func stringOfBoth(
	both func() (aten, apep interface{}),
	stringer func(a interface{}) string ) string {

	aten, apep := both()
	return stringOfTwoStringer(aten, apep, stringer)
}

func stringOfTwoStringer(aten, apep interface{}, stringer func(a interface{}) string) string {
	sten, spep := stringer(aten), stringer(apep)
	if sten == "" { return stringOfItem(spep) }
	if spep == "" { return stringOfItem(sten) }
	return stringOfTwos(sten, spep)
}

// ===========================================================================

func stringOfTwos(a, b interface{}) string { return fmt.Sprintf(twosFmt, a, b) }
func stringOfOnes(a    interface{}) string { return fmt.Sprintf(onesFmt, a   ) }
func stringOfItem(a    interface{}) string { return fmt.Sprintf(itemFmt, a   ) }

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core


// nest represents a nested pair, a pair of pairs.
type nest struct {
	Aten Pair
	Apep Pair
}

// Length is zero for nil and is 1 otherwise.
func (a nest) Length() Cardinality { return 1 }

// join returns a pair of pairs - a nested pair.
func join(a, b Pair) *nest {
	return &nest{a, b}
}

// Contains discriminates iff item == a
// or is identical to one of the two pairs of a.
func (a nest) Contains(item interface{}) (contains bool) {
	if n, contains := item.(nest); contains {
		if contains = a == n; !contains {
			if p, contains := item.(Pair); contains {
				if contains = a.Aten == p; !contains {
					return a.Apep == p
				}
			}
		}
	}
	return
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// kind implements a named type
type kind struct {
	Name
	Type
}

const nilName = Name("<noName>")

type nilPair struct{}
func (a nilPair) Kind() kind { return kind{nilName, TypeOf(nilPair{})} }
func (a nilPair) Both() (aten, apep interface{}) { return nilPair{}.Kind(), nil }

// I wish this could be constant
var nilKind = kind{nilName, TypeOf(kind{})}
var nilHead Head = func() Pair { return nilPair{} }
var nilTail Tail = func() (Head, Tail) { return nil, func() (Head, Tail) {return nil, nil} }

var theKindOfName = kind{Name(TypeOf(Name(0)).Name()), TypeOf(Name(""))}
var theKindOfIndex = kind{Name(TypeOf(Index(1)).Name()), TypeOf(Index(1))}
var theKindOfCardinality = kind{Name(TypeOf(Cardinality(0)).Name()), TypeOf(Cardinality(0))}
var theKindOfKind = kind{Name(TypeOf(kind{}).Name()), TypeOf(kind{})}

/* kindOfHead returns the kind of a kind.				*/ func kindOfKind(a kind)	kind { return kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfName returns the kind of a Name.				*/ func kindOfName()		kind { return theKindOfName }
/* kindOfIndex returns the kind of an Index.				*/ func kindOfIndex()		kind { return theKindOfIndex }
/* kindOfCardinality returns the kind of a Cardinality.			*/ func kindOfCardinality()	kind { return theKindOfCardinality }
/* kindOfHead returns the kind of a Head.				*/ func kindOfHead(a Head)	kind {if a == nil {return kind{nilName, TypeOf(nilHead)}   }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfTail returns the kind of a Tail.				*/ func kindOfTail(a Tail)	kind {if a == nil {return kind{nilName, TypeOf(nilTail)}   }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }
/* kindOfPair returns the kind of a Pair.				*/ func kindOfPair(a Pair)	kind {if a == nil {return kind{nilName, TypeOf(nilPair{})} }; return kind{Name(TypeOf(a).Name()), TypeOf(a)} }

/* Kind implements Kind by returning the Name and the Type of a.		*/ func (a kind)        Kind() (Name, Type) { return a.Name, a.Type }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Name)        Kind() (Name, Type) { return kindOfName().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Index)       Kind() (Name, Type) { return kindOfIndex().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Cardinality) Kind() (Name, Type) { return kindOfCardinality().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Head)        Kind() (Name, Type) { return kindOfHead(a).Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Tail)        Kind() (Name, Type) { return kindOfTail(a).Kind() }

// ===========================================================================

/* Both implements Pair by returning both parts of a.                   */ func (a nest)        Both() (aten, apep interface{}) { return a.Aten, a.Apep }
/* Both implements Pair by returning the Name and the Type.		*/ func (a kind)        Both() (name, typ  interface{}) { return a.Name, a.Type }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Name)        Both() (aten, apep interface{}) { return kindOfName(),        a }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Index)       Both() (aten, apep interface{}) { return kindOfIndex(),       a }
/* Both implements Pair by returning the Kind and the value.		*/ func (a Cardinality) Both() (aten, apep interface{}) { return kindOfCardinality(), a }
/* Both implements Pair by returning Both() of the evalutaed Head.	*/ func (a Head)        Both() (aten, apep interface{}) {
	if a == nil {return kindOfHead(a), nilHead}
	if a() == nil {return nilPair{}.Kind(), nilPair{}};	return a().Both() }
/* Both implements Pair by returning the Head and Tail a evaluates to.	*/ func (a Tail) Both() (aten, apep interface{}) {
	if a == nil {return kindOfTail(a), nil};		return a() }

// ===========================================================================

// Tail implements Iterable
// by returning
// a head for the first Pair and
// a tail for the second Pair.
func (a nest) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a.Aten }, func() (Head, Tail) { return func() Pair { return a.Apep }, NilTail() } } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a kind) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Cardinality) Tail() Tail                   { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Index) Tail() Tail                         { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Name) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == Pair(a) ) and
// as tail the unique NilTail().
func (a Head) Tail() Tail                          { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

// Tail implements Iterable
// by returning
// itself - idempotent, so to say.
func (a Tail) Tail() Tail                          { return a }

// ===========================================================================

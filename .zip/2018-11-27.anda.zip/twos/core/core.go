// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"reflect"
)

// ===========================================================================

// Name as a unique identifier - unique among its Kind
type Name string

// ===========================================================================

// Index represents an ordinal number and may be used
// to enumerate a collention or access some item.
// Intentionally, the first item has Index = 1.
// This is more intuitive for users.
// (Well, programmers prefer offsets over ordinals).
type Index = ordinalNumber
type ordinalNumber int64

// Indices represents a stream of ordinal numbers
// implemented as a (read-only) channel of Index
// which can be ranged over.
type Indices <-chan Index

// At returns the Index corresponding to slice-offset i: i+1
func At(i int) Index {
	return Index(i + 1)
}

// ===========================================================================

// Cardinality represents a cardinal number such as the #-of items in a Pile.
type Cardinality = cardinalNumber
type cardinalNumber int64

// Cardinalities represents a stream of cardinal numbers
// implemented as a (read-only) channel of Cardinality
// which can be ranged over.
type Cardinalities <-chan Cardinality

// ===========================================================================

// Type is the reflect.Type
type Type = reflect.Type

// TypeOf returns the Type of a
func TypeOf(a interface{}) Type {
	return reflect.TypeOf(a)
}
// ===========================================================================

// Kind represents a named type
type Kind interface {
	Kind() (Name, Type)
}

/* NewKind returns a fresh Kind given a Name and a sample of the Type	*/
func NewKind(name Name, sample interface{}) *kind {
	return &kind{name, TypeOf(sample)}
}

/* NewType returns a fresh Kind given a Name and a Type			*/
func NewType(name Name, typ Type) *kind {
	return &kind{name, typ}
}

/* NewName returns a fresh Kind given a Name and a Kind of same Type	*/
func NewName(name Name, k Kind) *kind {
	_, typ := k.Kind()
	return &kind{name, typ}
}

// ===========================================================================

// Pair has two sides: Aten & Apep. It may be atomic, or composed, nested.
type Pair interface {
	Both() (aten, apep interface{}) // both sides - whatever each type is
}

// Pairs represents a stream of pairs
// implemented as a (read-only) channel of Pair
// which can be ranged over.
type Pairs <-chan Pair

// ===========================================================================

// Iterable represents a tailor-made collection, a thread for a tailor.
type Iterable interface {
	Tail() Tail
}

// Pile holds Length items.
type Pile interface {
	Length() Cardinality
}

// ===========================================================================

// Container can tell for any item whether it contains this item or not.
type Container interface {
	Contains(item interface{}) bool
}

// ===========================================================================

// Head is a thunk
// which evaluates to
// a Pair.
type Head func() Pair

// Tail is a thunk
// which evaluates to
// a Head and to another Tail.
type Tail func() (Head, Tail)

// NilTail is a helper, it returns the Tail which evaluates to nil, nil.
//  Note: this Tail is unique. So its the tail, not a tail.
func NilTail() Tail { return nilTail }

// ===========================================================================

## Less

	Irreflexive:	Less(a, a) == false
	A-Symmetric:	Less(a, b) => !Less(b, a)
	Transitive:	Less(a, b) && Less(b, c) => Less(a, c)

## Semiorder



## Partial Order

	LE(a, b) <==> Less(a, b) || a == b


## Preference

Human Perference: indifference is not transitive!

Wikipedia:
- Preference-based Planning (language)
- Stable marriage problem (Gale-Shapley) - rounds / iterations


## PSS Partial Solutions Set

How to deal with Tokens which occur in many preferences?

ZigZag: Max Happiness / Min Sadness / Max Happines / ...

pref := BEST
mess := BEST

- HEAD: Find some solutions SOL(pref).
  - The less #-UGLY the better.

- If there are solutions:
  - Extend each Solution SOL = SOL + (++pref); goto NEXT
  - else: pref += GOOD; goto HEAD

- NEXT: Iterate PSS (concurrent?!):
  - For all UGLY: restore all Tokens he considers(mess);
  - ++mess
  - goto HEAD





  - The larger the better
  - The Lesser the better

- Merge:

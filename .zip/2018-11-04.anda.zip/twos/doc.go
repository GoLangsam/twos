/*
package twos is all about pairs. And pairs of pairs. And pairs of pairs of pairs. And pairs of pairs of pairs of pairs...

Plenty of pairs. Piles of pairs. And piles of piles of pairs. And piles of piles of piles of pairs...

You know about that nice old lady, who -when asked what the universe rests upon- said:
"Turtles! Turtles all the way down", do You not? Well - there are no turtles in here.

## Pair
Any Pair has two sides, called `Aton` & `Apep`.

Different implementations of Pair contain and return different types.
Use Pair-method `Both()` to see them (untyped - as two interface{}).

( Technically, such two underlying types may be understood as a signature of the pair. )

Certain combinations are predefined - be it for ease of use, be it for useful discriminations.

An important combination is the pair of pairs, which allows to nest pairs to arbitrary depth.
Pair-method `Atom()` returns true iff the Pair is not nested.

Note: boolean convenience functions IsAtom, IsAtomAton, IsAtomApep facilitate further discriminations.



*/
package twos

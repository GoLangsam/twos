package twos

// Functions - unary

func IsAtom(a Pair) bool {
	v, w := a.Both()
	var ok bool
	if _, ok = v.(Pair); ok {
		return false
	} else if _, ok = w.(Pair); ok {
		return false
	}
	return true
}

func IsAtomAton(a Pair) bool {
	v, _ := a.Both()
	if _, ok := v.(Pair); ok {
		return false
	}
	return true
}

func IsAtomApep(a Pair) bool {
	_, v := a.Both()
	if _, ok := v.(Pair); ok {
		return false
	}
	return true
}

func bothApply(a Pair, y, n func(a interface{})) {
	if a == nil {return}
	aton, apep := a.Both()

	if IsAtomAton(a) {y(aton)} else {n(aton)}
	if IsAtomApep(a) {y(apep)} else {n(apep)}
}

func Flat(a Pair) (values []interface{}) {
	if a == nil {return}

	y := func(a interface{}) {values = append(values, flat(a)...)}
	n := func(a interface{}) {values = append(values, a)}
	bothApply(a, y, n)
	return values
}

func flat(a interface{}) []interface{} {
	if v, ok := a.(Pair); ok {
		return flat(v)
	}
	return []interface{}{a}
}

func reduceAny (a Pair, f func(Pair) interface{}, init []interface{}) []interface{} {
	return append(init, f(a))
}

// Functions - binary

// TODO: Exported for testing only
func Join(a, b Pair) Pair {
	return &twoTwo{a, b}
}


type Head func() Pair
type Tail func() (Head, Tail) //

var nilHead = func() Pair {return nil}
var nilTail = func() (Head, Tail) {return nil, nil}

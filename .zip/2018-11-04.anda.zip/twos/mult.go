package twos

func Mult(a, b Iterable) Tail {
	if a == nil || b == nil {return nilTail}

	aHead, aTail := a.Iter()()
	bHead, bTail := b.Iter()()

	return func () (Head, Tail) {
		return	func () Pair		{return Join(aHead(), bHead())},
			func () (Head, Tail)	{return mult(a, b, aHead, bHead, aTail, bTail) }
	}
}

func mult(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail) {
	head := func () Pair {return Join(aHead(), bHead())}
	tail := func () (Head, Tail) {
		bHead, bTail = bTail()
		if bHead == nil {
			aHead, aTail = aTail()
			if aHead == nil {return nilTail()}
			bHead, bTail = b.Iter()() // reset b
		}

		return	func () Pair		{return Join(aHead(), bHead())},
			func () (Head, Tail)	{return mult(a, b, aHead, bHead, aTail, bTail) }
		}
	return head, tail
}

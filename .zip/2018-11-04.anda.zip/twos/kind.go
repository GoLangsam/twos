package twos

import (
	"reflect"
)

type Name string

var _ Pair = new(Kind)

// Kind represents a named type and implements Pair
type Kind struct{
	Aton Name
	Apep reflect.Type
}

// NewKind returns a Kind given a name and a sample of the type
func NewKind(name Name, sample interface{}) *Kind {
	return &Kind{name, reflect.TypeOf(sample)}
}

// NewType returns a Kind given a name and a reflect.Type
func NewType(name Name, typ reflect.Type) *Kind {
	return &Kind{name, typ}
}

/* Quote:
    Type is the representation of a Go type.

    Not all methods apply to all kinds of types. Restrictions, if any, are noted
    in the documentation for each method. Use the Kind method to find out the
    kind of type before calling kind-specific methods. Calling a method
    inappropriate to the kind of type causes a run-time panic.

    Type values are comparable, such as with the == operator, so they can be
    used as map keys. Two Type values are equal if they represent identical
    types.
*/

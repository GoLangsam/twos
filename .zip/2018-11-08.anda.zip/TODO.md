# Anda (Sanskrit) <=> Cosmic Egg

An unconventional cosmos for unconventional usage by unconventional players.

This is all about pairs. And pairs of pairs. And pairs of pairs of pairs. And pairs of pairs of pairs of pairs...

Plenty of pairs, Piles of pairs. And piles of piles of pairs. And piles of piles of piles of pairs...

Did You know that nice old lady, who -when asked what the universe rests upon- said: "Turtles! Turtles all the way down".

Well - in our cosmos there are no turtles.

Our cosmos -even so unbounded, unlimited- is finite. As finite as the time to design, build and compute it.

By default, our cosmos is not self-referential.

And: our cosmos is discrete. 
We aim to model finite (and discrete) structures - sooner of later Stop() will be true.

Happiness is build in. (And helps to partition certain collections of pairs.)

TODO:

--- FOSSA

GoLangsam/template:	https://app.fossa.io/api/projects/git%2Bgithub.com%2FGoLangsam%2Ftemplate.svg?type=shield

GoLangsam/pipe:		https://app.fossa.io/reports/6c367031-e07b-46de-916f-0d5fd3cc3c9a

--- go lang
// github.com/skratchdot/open-golang/open.Run
/*
	Open a file, directory, or URI using the OS's default
	application for that object type. Wait for the open
	command to complete.
*/

// go install github.com/gammons/todolist

// go install gbbr.io/ev/cmd/... makes good use of pkg/browser etc.

// go install github.com/pkg/browser/examples/Open - Open file / URL / stdin

// inspired by github.com/floyernick/Data-Structures-and-Algorithms
// see also TernarySearch or CircularBuffer

---

Concrete simple flow:

import (
	"anda"
	"happy"
)

happiness := happy.New()
a := anda.New(happiness) // a cosmic egg

// define Model
sponsors := a.NewKind("Sponsor", Name)
weekdays := a.NewKind("Weekdays", time.Weekday{})
dayhours := a.NewKind("DayHours", time.Time{})
weekhour := a.NewJoin("Hours per week", dayhours) // an iterator!
students := a.NewKind("Student", Name) 


triangle := a.Symbols(sponsors, weekhour, students) // symbols are unique,
// and we shall requests preference relations as follows: 
// - A B
// - A C
// - C A
// - C B(A)

// B(A) means: what's left of B according to A

// We know the structure of B, we may use this for related Preference Relations.
// e.g. query each student for weekdays\A, then dayhours\A 

// populate Model
sponsors.Fill( => {"Thomas Hedeler"}
weekdays.Fill( => {"So", "Mo", "Di", "Mi", "Do", "Fr", "Sa" )
dayhours.Fill( => see time.Duration time.Hour 0...23 (oder gleich nur 08:00 - 17:00)
students.Read( => CSVReader? json.?

// refine Model
offers slots tokens
choices := a.Skipper(sponsors, weekdays) // returns (iter(All-less(SKIP); consider a filter!


, iter(iter(Happiness))


calendar := sponsor.Preferences(weekhour) // This may be interactive; internally: no need to duplicate weekhour-Pile
available := calendar.Live().SkipAten // 

---
## Tommer
Well, if it sounds like hammer to You, fine. Think of a hammer drill and You are not too far off.
( Hilti would be a great name as well - but that's a swiss trademark. )
So it became Tommer - in respect to the man named Tom who originally came up with the basic idea.

The idea? Starting with the best-of-best, iterate forward hammering out a great solution.

There is a timeout (e.g. 3 minutes). It controls the rhythm. It's the pulse, so to say, the heartbeat, sorry, Tommerbeat.

### Hammering

The Tommer will stop, offer insight into the history of its progress and into its current status, and will seek for guidance.

As there is no suitable AI machinery in sight anywhere, a human user -let's say: You- will be prompted.

- `DoMore?` Try another round.
- `Extend?` Double the timeout, and proceed.
- `Expand?` Iterate the problem space for more (but less preferable) possible combinations, and proceed.
- `Enough?` Save what's there, and terminate.

In case the look ahead into the problem space returns nothing (more), `Expand?` does not make sense any more, of course,
and will be disabled.

In case the search has exhausted the current problem space, neither `DoMore?` nor `Extend?` make sense, of course,
and will be disabled.

So we continue with "Expand!" (if enabled/available) and proceed, or terminate with "Enough!".

### History of progress
Per round is -among others- recorded:
- # of newly found entries
- Min & Max Cardinality
- Min & Max Score
- time used

### Current status
Per round is -among others- available for inspection:
- # of round
- total time used
- current size of problem
- current timeout

---

## New
func New(opts... option) *Anda


## Kind
// Kind is a small store for Pairs
type Kind interface {
	Chest
	Len() int8
}

## Pile
// Pile is a store for Pairs 
type Pile interface {
	Chest

	Size() int16
}

## Chest
// 
type Chest interface {
	Pair

	Aten() Name
	Apep() Categories

	Put(aten Pair, apep Pair) (new bool, oldPair)
	Remove(a Pair) (wasfound bool)
	All() []Pair
	Len() int
	...
}

func NewKind(name Name, aten, apep Category, chestOption ...ChestOption) *Kind

Anda provides several *Pile funtions to combine Chests.
func NewPile(name Name, aten, apep Category, chestOption ...ChestOption) *Pile

### Chest Factory

- Bag / Set
- Aten unique (implies Set)
- indexed: At(int), IsAt(a *Pair) int
- order:
  - byArrival
  - byAten (keep a list.List?!)
  - random
- grouped / partitioned
  - byAten
  - byApep

---
## Category
a.NewKind( n Name, type interface{} ) *Category
a.NewType( n Name, typ reflect.Type ) *Category

Anda keeps a Kind-Chest.


### Category
type Category interface {
	Pair
	Aten() Name
	Apep() reflect.Type
}

### Categories
type Strings interface {
	Pair
	Aten() Category
	Apep() Category
}

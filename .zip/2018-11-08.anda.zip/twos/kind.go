package twos

// NewKind returns a Kind given a name and a sample of the type
func NewKind(name Name, sample interface{}) *Kind { return &Kind{name, typeOf(sample)} }

// NewType returns a Kind given a name and a Type
func NewType(name Name, typ Type) *Kind { return &Kind{name, typ} }

package twos

import (
	"fmt"
)

type (
	// Name as a unique identifier - unique among its Kind
	Name string

	// Pair has two sides: Aten & Apep and may be atomic, or composed
	Pair interface{
	//	Atom() (isAtom bool)            // determines iff neither side is composed
		Both() (aten, apep interface{}) // both sides - whatever each type is
	//	String() string                 // implement fmt.Stringer
	}

	StrStr	struct { Aten string;	Apep string }
	strTwo	struct { Aten string;	Apep Pair }
	twoStr	struct { Aten Pair;	Apep string }
	twoTwo	struct { Aten Pair;	Apep Pair }
	typTyp	struct { Aten Type;	Apep Type } // typTyp represents the types of a Pair, and implements Pair

	// Kind represents a named type and implements Pair
	Kind	struct { Aten Name;	Apep Type }

	Head func() Pair
	Tail func() (Head, Tail) //

)

var (
	_ Pair = &StrStr{}
	_ Pair = &strTwo{}
	_ Pair = &twoStr{}
	_ Pair = &twoTwo{}
	_ Pair = &typTyp{}
	_ Pair = &Kind{};	_ Pair = new(Kind)
	_ Pair = &node{}
	_ Pair = Head(func() Pair {return nil})
	_ Pair = NilTail()
)

func IsEven(i int) bool {return i&1 == 0}

func (a *StrStr)	Len() int { return 1 }
func (a *strTwo)	Len() int { return 1 }
func (a *twoStr)	Len() int { return 1 }
func (a *twoTwo)	Len() int { return 1 }
func (a *typTyp)	Len() int { return 1 }
func (a *Kind)		Len() int { return 1 }
//nc (a *node)		Len() int { return 1 }
func (a Head)		Len() int { return 1 }
//nc (a Tail)		Len() int { return 1 }

/*
func (a *StrStr)	Atom() bool { return true }
func (a *strTwo)	Atom() bool { return false }
func (a *twoStr)	Atom() bool { return false }
func (a *twoTwo)	Atom() bool { return false }
func (a *typTyp)	Atom() bool { return false }
func (a *Kind)		Atom() bool { return true }
func (a *node)		Atom() bool { return a.Prev == nil && a.Next == nil }
func (a Head)		Atom() bool { return false }
func (a Tail)		Atom() bool { return true }
*/

func (a *StrStr)	Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *strTwo)	Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *twoStr)	Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *twoTwo)	Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *typTyp)	Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *Kind)		Both() (aten, apep interface{}) { return a.Aten, a.Apep }
func (a *node)		Both() (aten, apep interface{}) { return a.Prev.Pair, a.Next.Pair }
func (a Head)		Both() (aten, apep interface{}) { return a().Both() }
func (a Tail)		Both() (aten, apep interface{}) { return a() }

const pairFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

func (a *StrStr)	String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *strTwo)	String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *twoStr)	String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *twoTwo)	String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *typTyp)	String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *Kind)		String() string { return fmt.Sprintf(pairFmt, a.Aten, a.Apep) }
func (a *node)		String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }
func (a Head)		String() string { aten, apep := a.Both(); return fmt.Sprintf(pairFmt, aten, apep) }
func (a Tail)		String() string { aten, apep := a.Both(); return fmt.Sprintf(pairFmt, aten, apep) }

func (a *StrStr)	Iter() (Tail) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *strTwo)	Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *twoStr)	Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *twoTwo)	Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *typTyp)	Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *Kind)		Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a *node)		Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } } // TODO: must walk the tree
func (a Head)		Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }
func (a Tail)		Iter() (func() (Head, Tail)) { return func() (Head, Tail) { return AsHead(a), NilTail() } }

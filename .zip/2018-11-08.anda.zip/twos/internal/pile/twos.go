package pile

import (
	"github.com/GoLangsam/anda/twos"
)

type Name = twos.Name
type Kind = twos.Kind

func NewKind(name Name, sample interface{}) *Kind {
	return twos.NewKind(name, sample)
}

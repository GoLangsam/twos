package pile

import (
	"sync"

	"github.com/mauricelam/genny/generic"

)

type any generic.Type

type pileOfany struct {
	Name Name
	Kind *Kind

	data []any
	look map[any]uint8

	maxIdx int
	sync.RWMutex
}

type ofany interface {
	Both() (aten, apep interface{})
	Len() int
	At(int) any
	Idx(any) (int, bool)
	add(any) bool
	Reverse()
}

var _ ofany = &pileOfany{}
var _ ofany = new(pileOfany)
var _ ofany = newPileOfany( "Hours", NewKind( "Int16", int16(0) ) )

func newPileOfany(name Name, kind *Kind) *pileOfany {
	p := pileOfany{
		Name: name,
		Kind: kind,
		maxIdx: (1<<8)-1,
	}
	p.data = []any{}
	p.look = make(map[any]uint8)
	return &p
}

func (a *pileOfany)Len() int { return len(a.data) }
func (a *pileOfany)At(idx int) any { return a.data[idx] }
func (a *pileOfany)Idx(item any) (int, bool) { idx, ok := a.look[item]; return int(idx), ok }
func (a *pileOfany)Both() (aten, apep interface{}) { return a.Kind.Both() }

func (a *pileOfany)add(item any) (duplicate bool) {

	if idx, duplicate := a.look[item]; duplicate {
		a.data[idx] = item
	} else {
		a.data = append(a.data, item)
		a.look[item] = uint8(len(a.data))
	}
	return
}

// github.com/skratchdot/open-golang/open.Run
/*
	Open a file, directory, or URI using the OS's default
	application for that object type. Wait for the open
	command to complete.
*/

// go install github.com/gammons/todolist

// go install gbbr.io/ev/cmd/... makes good use of pkg/browser etc.

// go install github.com/pkg/browser/examples/Open - Open file / URL / stdin

// inspired by github.com/floyernick/Data-Structures-and-Algorithms
// see also TernarySearch or CircularBuffer

func (a *pileOfany)Reverse() {
	i := 0
	u := len(a.data) - 1
	for i < u {
		a.data[i], a.data[u] = a.data[u], a.data[i]
		a.look[a.data[i]], a.look[a.data[u]] = uint8(i), uint8(u)
		i, u = i+1, u-1
	}
}

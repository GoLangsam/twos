package twos

import (
	"time"
)

type PairPile	= pileOfPair
type Naturals	= pileOfInt
type Symbols	= pileOfString
type WeekDays	= pileOfTimeWeekday
type TypedPile	= pileOfInterface

func NewPairPile(name Name)	*PairPile {	return newPileOfPair(name,		NewKind(name, &twoTwo{})) }
func NewInts(name Name)		*Naturals {	return newPileOfInt(name,		NewKind(name, int(0))) }
func NewSymbols(name Name)	*Symbols {	return newPileOfString(name,		NewKind(name, string(""))) }
func NewWeekDays(name Name)	*WeekDays {	return newPileOfTimeWeekday(name,	NewKind(name, time.Sunday)) }
func NewTypedPile(name Name, sample interface{}) *TypedPile { return newPileOfInterface(name, NewKind(name, sample)) }

func (a *PairPile)	Add(item Pair)		error { a.add(item);	return nil }
func (a *Naturals)	Add(item int)		error { a.add(item);	return nil }
func (a *Symbols)	Add(item string)	error { a.add(item);	return nil }
func (a *WeekDays)	Add(item time.Weekday)	error { a.add(item);	return nil }
func (a *TypedPile)	Add(item interface{})	error { a.add(item);	return nil }

func (a *PairPile)	Head(item Pair)		func() Pair { return func() Pair {return item} }

func (a *Symbols)	Head(item string)	func() Pair { return func() Pair {return &StrStr{string(a.Kind.Aten),	item }} }
func (a *WeekDays)	Head(item time.Weekday)	func() Pair { return func() Pair {return &StrStr{string(a.Kind.Aten),	item.String()}} }

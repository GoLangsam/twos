package twos

func AsHead(a Pair) Head {	return func() Pair {		return a} }
func NilTail() Tail { 		return func() (Head, Tail) {	return nil, nil } }

func (a Tail)    Range() <-chan Pair {
	pairs := make(chan Pair)

	go func(pairs chan<- Pair, tail Tail) {
		defer close(pairs)
		for head, tail := tail(); head != nil; head, tail = tail() {
			pairs <- head()
		}
	}(pairs, a)
	return pairs
}

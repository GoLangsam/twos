var isCardinalityFalse = func(a Cardinality) bool { ... }
var isCardinalityTrue = func(a Cardinality) bool { ... }
var isIDFalse = func(a ID) bool { ... }
var isIDTrue = func(a ID) bool { ... }
var isIndexFalse = func(a Index) bool { ... }
var isIndexTrue = func(a Index) bool { ... }
var isInterfaceFalse = func(a interface{}) bool { ... }
var isInterfaceTrue = func(a interface{}) bool { ... }
var isIterableFalse = func(a Iterable) bool { ... }
var isIterableTrue = func(a Iterable) bool { ... }
var isPairFalse = func(a Pair) bool { ... }
var isPairTrue = func(a Pair) bool { ... }
var isPileFalse = func(a Pile) bool { ... }
var isPileTrue = func(a Pile) bool { ... }
var isTypeFalse = func(a Type) bool { ... }
var isTypeTrue = func(a Type) bool { ... }
func FmapCardinalityRoC(f func(Cardinality) Cardinality, RoCs ...<-chan Cardinality) <-chan Cardinality
func FmapIDRoC(f func(ID) ID, RoCs ...<-chan ID) <-chan ID
func FmapIndexRoC(f func(Index) Index, RoCs ...<-chan Index) <-chan Index
func FmapInterfaceRoC(f func(interface{}) interface{}, RoCs ...<-chan interface{}) <-chan interface{}
func FmapInterfaces(f func(interface{}) interface{}, interfaces ...interface{}) (interfaceS []interface{})
func FmapIterableRoC(f func(Iterable) Iterable, RoCs ...<-chan Iterable) <-chan Iterable
func FmapPairRoC(f func(Pair) Pair, RoCs ...<-chan Pair) <-chan Pair
func FmapPileRoC(f func(Pile) Pile, RoCs ...<-chan Pile) <-chan Pile
func FmapTypeRoC(f func(Type) Type, RoCs ...<-chan Type) <-chan Type
func JoinInterfaceS(interfaceSS [][]interface{}) (interfaceS []interface{})
func StringOfOnes(a interface{}) string
func StringOfPair(a Pair) string
func StringOfTwos(a, b interface{}) string
func assertPileOfCardinalityInterfaces()
func assertPileOfIDInterfaces()
func assertPileOfIndexInterfaces()
func assertPileOfInterfaceInterfaces()
func assertPileOfIterableInterfaces()
func assertPileOfPairInterfaces()
func assertPileOfPileInterfaces()
func assertPileOfTypeInterfaces()
func boolCardinality()
func boolID()
func boolIndex()
func boolInterface()
func boolIterable()
func boolPair()
func boolPile()
func boolType()
func fmapCardinality()
func fmapID()
func fmapIndex()
func fmapInterface()
func fmapIterable()
func fmapPair()
func fmapPile()
func fmapType()
func pileCardinality()
func pileID()
func pileIndex()
func pileInterface()
func pileIterable()
func pilePair()
func pilePile()
func pileType()
    func FmapCardinalitys(f func(Cardinality) Cardinality, Cardinalitys ...Cardinality) (CardinalityS []Cardinality)
    func JoinCardinalityS(CardinalitySS [][]Cardinality) (CardinalityS []Cardinality)
type CardinalityIs func(Cardinality) bool
    func FmapIDs(f func(ID) ID, IDs ...ID) (IDS []ID)
    func JoinIDS(IDSS [][]ID) (IDS []ID)
type IDIs func(ID) bool
    func FmapIndexs(f func(Index) Index, Indexs ...Index) (IndexS []Index)
    func JoinIndexS(IndexSS [][]Index) (IndexS []Index)
type IndexIs func(Index) bool
    func FmapIterables(f func(Iterable) Iterable, Iterables ...Iterable) (IterableS []Iterable)
    func JoinIterableS(IterableSS [][]Iterable) (IterableS []Iterable)
type IterableIs func(Iterable) bool
    func FmapPairs(f func(Pair) Pair, Pairs ...Pair) (PairS []Pair)
    func JoinPairS(PairSS [][]Pair) (PairS []Pair)
type PairIs func(Pair) bool
    func FmapPiles(f func(Pile) Pile, Piles ...Pile) (PileS []Pile)
    func JoinPileS(PileSS [][]Pile) (PileS []Pile)
type PileIs func(Pile) bool
    func NewPileOfCardinality(name ID, items ...Cardinality) *PileOfCardinality
    func NewPileOfID(name ID, items ...ID) *PileOfID
    func NewPileOfIndex(name ID, items ...Index) *PileOfIndex
    func NewPileOfInterface(name ID, items ...interface{}) *PileOfInterface
    func NewPileOfIterable(name ID, items ...Iterable) *PileOfIterable
    func NewPileOfPair(name ID, items ...Pair) *PileOfPair
    func NewPileOfPile(name ID, items ...Pile) *PileOfPile
    func NewPileOfType(name ID, items ...Type) *PileOfType
    func NilTail() Tail
    func FmapTypes(f func(Type) Type, Types ...Type) (TypeS []Type)
    func JoinTypeS(TypeSS [][]Type) (TypeS []Type)
    func TypeOf(a interface{}) Type
type TypeIs func(Type) bool
type interfaceIs func(interface{}) bool

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package math

import (
	. "github.com/GoLangsam/anda/twos/core"
)

// Functions - unary

func IsPairOfPairs(a Pair) (IsPairOfPairs bool) {
	v, w := a.Both()
	var ok bool
	if _, ok = v.(Pair); ok {
		if _, ok = w.(Pair); ok {
			return true
		}
	}
	return false
}

func IsNestedA(a Pair) (IsNested bool) {
	v, w := a.Both()
	return !isAnAtom(v) || !isAnAtom(w)
}

func IsAtom(a Pair) (IsAtom bool) {
	v, w := a.Both()
	return isAnAtom(v) && isAnAtom(w)
}

func IsAtomAten(a Pair) (IsAtomAten bool) {
	v, _ := a.Both()
	return isAnAtom(v)
}

func IsAtomApep(a Pair) (isAtomApep bool) {
	_, v := a.Both()
	return isAnAtom(v)
}

func isAnAtom(a interface{}) (isAnAtom bool) {
	return !IsPair(a)
}

func IsPair(a interface{}) (isPair bool) {
	_, isPair = a.(Pair)
	return
}

// Functions - binary

// Functions - variadic

// Functions - functional

func bothApply(a Pair, y, n func(a interface{})) {
	if a == nil { return }

	aten, apep := a.Both()

	if IsAtomAten(a) { y(aten) } else { n(aten) }
	if IsAtomApep(a) { y(apep) } else { n(apep) }
}

func Flat(a Pair) (values []interface{}) {
	if a == nil { return }

	y := func(a interface{}) { values = append(values, flat(a)...) }
	n := func(a interface{}) { values = append(values, a) }
	bothApply(a, y, n)
	return values
}

func flat(a interface{}) []interface{} {
	if v, ok := a.(Pair); ok { return flat(v) }
	return []interface{}{a}
}

/*
// flatTypes reports all Type a Pair is composed of.
func flatTypes(a Pair) []Type {
	flatS := Flat(a)
	types := make([]Type, 0, len(flatS))
	for _, flat := range flatS {
		types = append(types, typeOf(flat))
	}
	return types
}
*/

func reduceAny(a Pair, f func(Pair) interface{}, init []interface{}) []interface{} {
	return append(init, f(a))
}

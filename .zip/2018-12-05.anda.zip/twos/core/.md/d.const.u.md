const itemFmt = "%+v"
const nilName = name("<noName>")
const nodeFmt = "{%+v<%+v>%+v}"
const tailBeg = "["
const tailEnd = "]"
const twosFmt = "{ %+v | %+v }"

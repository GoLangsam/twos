package core // import "github.com/GoLangsam/anda/twos/core"

type Type = reflect.Type
    Type is the reflect.Type


func TypeOf(a interface{}) Type

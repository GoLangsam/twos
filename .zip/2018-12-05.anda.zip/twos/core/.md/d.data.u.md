type kind struct{ ... }
type nest struct{ ... }
type nilPair struct{}

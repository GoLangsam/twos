package core // import "github.com/GoLangsam/anda/twos/core"

type ID = name
    ID as a unique identifier - unique among its Kind. Implements Named.


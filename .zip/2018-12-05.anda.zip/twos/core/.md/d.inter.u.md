type Iterable interface{ ... }
type Pair interface{ ... }
type stringer interface{ ... }

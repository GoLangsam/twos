var isanyTypeFalse = func(a anyType) bool { ... }
var isanyTypeTrue = func(a anyType) bool { ... }

package core // import "github.com/GoLangsam/anda/twos/internal"

type anyTypeS []anyType

func (a anyTypeS) Both() (aten, apep interface{})
func (a anyTypeS) String() string

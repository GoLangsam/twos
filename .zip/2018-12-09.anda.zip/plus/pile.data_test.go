// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package plus

import (
	"time"
)

// let's see if we can fool genny
func testInt() (string, []int) {
	name := TypeOf(int(0)).Name()
	data := []int{ 4, 7, 1, 1, 5, 6} // Note: One duplicate!
	return name, data
}

func testString() (string, []string) {
	name := TypeOf(string("test")).Name()
	data := []string{ "4", "7", "1", "1", "5", "6"} // Note: One duplicate!
	return name, data
}

func testTimeWeekday() (string, []time.Weekday) {
	name := TypeOf(time.Sunday).Name()
	data := []time.Weekday{
		time.Wednesday,
		time.Saturday,
		time.Monday,
		time.Monday,
		time.Thursday,
		time.Friday,
	} // Note: One duplicate!
	return name, data
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package twos

import (
	"github.com/GoLangsam/anda/twos/core"
	"github.com/GoLangsam/anda/twos/data"
	"github.com/GoLangsam/anda/twos/math"
)

var (
	// core
	IsNested = core.IsNested
	Join = core.Join
	Iter = core.Iter

	// data
	N = data.N

	// math
	IsPairOfPairs = math.IsPairOfPairs
	IsAtom = math.IsAtom
	IsAtomAten = math.IsAtomAten
	IsAtomApep = math.IsAtomApep
)

var theKindOfCardinality = kind{ ... }
var theKindOfIndex = kind{ ... }
var theKindOfKind = kind{ ... }
var theKindOfName = kind{ ... }
var theKindOfNest = kind{ ... }
    var nilHead Head = func() Pair { ... }
    var nilTail Tail = func() (Head, Tail) { ... }

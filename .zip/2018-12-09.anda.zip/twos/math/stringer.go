// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package math

import (
	"fmt"
)

const onesFmt = " {%v} "
const twosFmt = "{ %+v | %+v }"
const nodeFmt = "{%+v<%+v>%+v}"

/* String implements fmt.Stringer */ func (a *node)             String() string { return fmt.Sprintf(nodeFmt, a.Prev, a.Pair, a.Next) }

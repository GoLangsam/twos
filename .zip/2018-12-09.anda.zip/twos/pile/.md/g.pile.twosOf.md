package pile // import "github.com/GoLangsam/anda/twos/pile"

type twosOfPile struct {
	Aten Pile
	Apep Pile
}

func (a twosOfPile) Both() (aten, apep interface{})
func (a twosOfPile) Length() Cardinality
func (a twosOfPile) Of(index Index) Head
func (a twosOfPile) String() string
func (a twosOfPile) Tail() Tail

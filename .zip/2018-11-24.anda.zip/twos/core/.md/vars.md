var kindOfCardinality = &kind{ ... }
var kindOfIndex = &kind{ ... }
var kindOfName = &kind{ ... }
var nilTail = func() (Head, Tail) { ... }

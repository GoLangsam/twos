package core // import "github.com/GoLangsam/anda/twos/core"

type Head func() Pair
    Head is a thunk which evaluates to a Pair.


func (a Head) Both() (aten, apep interface{})
func (a Head) Kind() (Name, Type)
func (a Head) Length() Cardinality
func (a Head) String() string
func (a Head) Tail() Tail

package core // import "github.com/GoLangsam/anda/twos/core"

type Tail func() (Head, Tail)
    Tail is a thunk which evaluates to a Head and to another Tail.


func NilTail() Tail
func (a Tail) Both() (aten, apep interface{})
func (a Tail) Kind() (Name, Type)
func (a Tail) Length() Cardinality
func (a Tail) LengthRecursive() Cardinality
func (a Tail) Range() <-chan Pair
func (a Tail) String() string
func (a Tail) Tail() Tail

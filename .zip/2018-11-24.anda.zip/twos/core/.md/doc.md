package core // import "github.com/GoLangsam/anda/twos/core"

func C(N int) <-chan Cardinality
func I(N int) <-chan Index
func IDs(prefix string, anz int) []string
func Idx(i Index) int
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfPair(a Pair) string
func NewKind(name Name, sample interface{}) *kind
func NewName(name Name, k Kind) *kind
func NewType(name Name, typ Type) *kind
type Cardinality = cardinalNumber
type Head func() Pair
type Index = ordinalNumber
    func At(i int) Index
type Iterable interface{ ... }
type Kind interface{ ... }
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Name string
type Pair interface{ ... }
type Pile interface{ ... }
type Tail func() (Head, Tail)
    func NilTail() Tail
type Type = reflect.Type
    func TypeOf(a interface{}) Type

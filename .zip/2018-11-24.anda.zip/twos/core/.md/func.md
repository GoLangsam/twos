var nilTail = func() (Head, Tail) { ... }
func C(N int) <-chan Cardinality
func I(N int) <-chan Index
func IDs(prefix string, anz int) []string
func Idx(i Index) int
func N(n int) []struct{}
func Names(prefix string, N int) <-chan Name
func StringOfPair(a Pair) string
func getFormatWidth(prefix string, anz int) string
func getFormatWidthPaddingSpaces(anz int) string
func getFormatWidthPaddingZeros(anz int) string
func stringOf(a interface{}) string
func width(anz int) int
type Head func() Pair
    func At(i int) Index
    func KindOfCardinality() Kind
    func KindOfIndex() Kind
    func KindOfName() Kind
type Tail func() (Head, Tail)
    func NilTail() Tail
    func TypeOf(a interface{}) Type
    func NewKind(name Name, sample interface{}) *kind
    func NewName(name Name, k Kind) *kind
    func NewType(name Name, typ Type) *kind

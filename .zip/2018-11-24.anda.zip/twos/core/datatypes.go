// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// C allows to range over the first N cardinal numbers:
//    for c := range C(10) {
//        fmt.Println(i)
//    }
// ... will print 0 to 9, inclusive.
func C(N int) Cardinalities {
	Cs := make(chan Cardinality)
	go func(Cs chan<- Cardinality, N int) {
		defer close(Cs)
		for c := 0; c < N; c++ {
			Cs <- Cardinality(c)
		}
	}(Cs, N)
	return Cs
}

// ===========================================================================

// I allows to range over the first N ordinal numbers:
//    for i := range iter.I(10) {
//        fmt.Println(i)
//    }
// ... will print 1 to 10, inclusive.
func I(N int) Indices {
	Is := make(chan Index)
	go func(Is chan<- Index, N int) {
		defer close(Is)
		for i := 1; i < N+1; i++ {
			Is <- Index(i)
		}
	}(Is, N)
	return Is
}

// ===========================================================================
// stolen from "github.com/bradfitz/iter"

// N returns a slice of n 0-sized elements, suitable for ranging over:
//    for i := range iter.N(10) {
//        fmt.Println(i)
//    }
// ... will print 0 to 9, inclusive.
//
// It does not cause any allocations.
func N(n int) []struct{} {
	return make([]struct{}, n)
}

// ===========================================================================

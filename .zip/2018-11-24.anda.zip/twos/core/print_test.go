// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
)

func ExampleNames() {
	for i := range Names("ID-", 4) {
		fmt.Println(i)
	}
	// Output:
	// ID-1
	// ID-2
	// ID-3
	// ID-4
}

// ===========================================================================

func ExampleKindOfName() {

	k := KindOfName()

	fmt.Println(k)
	// Output:
	// {Name|core.Name}
}

func ExampleKindOfIndex() {

	k := KindOfIndex()

	fmt.Println(k)
	// Output:
	// {ordinalNumber|core.ordinalNumber}
}

func ExampleKindOfCardinality() {

	k := KindOfCardinality()

	fmt.Println(k)
	// Output:
	// {cardinalNumber|core.cardinalNumber}
}

// ===========================================================================

func ExampleNewType() {
	_, t := NewKind("Integer", int(0)).Kind()

	k := NewType("New Type", t)

	fmt.Println(k)
	// Output:
	// {New Type|int}
}

func ExampleNewName() {
	k := NewKind("Integer", int(0))

	k = NewName("New Name", k)

	fmt.Println(k)
	// Output:
	// {New Name|int}
}

func ExampleNewKind() {
	{
		k := NewKind("A kind of a Name", NewKind("inner Kind", Name("Example")))
		fmt.Println(k, k.Name, k.Type)
	}
	{
		k := NewKind("Integer", int(0))
		fmt.Println(k)
	}
	{
		k := NewKind("String", string(""))
		fmt.Println(k)
	}
	// Output:
	// {A kind of a Name|*core.kind} A kind of a Name *core.kind
	// {Integer|int}
	// {String|string}
}

// ===========================================================================

func ExampleStringOfPair() {
	p := KindOfName() // Note: Any kind implements Pair

	s := StringOfPair(p)

	fmt.Println(s)
	// Output:
	// {Name|core.Name}
}

func ExampleDeType() {
	p := KindOfCardinality() // Note: Any kind implements Pair

	s := DeType(p)

	fmt.Println(s)
	// Output:
	// cardinalNumber
}

func ExampleDeKind() {
	p := KindOfIndex() // Note: Any kind implements Pair

	s := DeKind(p) // Note: DeKind of a Kind returns the empty string

	fmt.Println(`"` + s + `"`)
	// Output:
	// ""
}

// ===========================================================================

func ExampleNilTail() {

	tail := NilTail() // Note: Any tail implements Pair

	fmt.Print(tail.String())	// Note: Any tail is wrapped in square brackets and followed by a newline
	fmt.Println(tail)		// Note: Any tail is wrapped in square brackets and followed by a newline
	fmt.Println(StringOfPair(tail))
	fmt.Println(DeType(tail))
	fmt.Println(DeKind(tail))
	// Output:
	// []
	// []
	//
	// { {<nil>|<nil>} | {<nil>|<nil>} }
	// {{<nil>|<nil>}|{<nil>|<nil>}}
	// {<nil>|<nil>}
}


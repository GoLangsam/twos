// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// kind implements a named type
type kind struct {
	Name
	Type
}

const nilName = Name("<nil>")

var kindOfName = &kind{Name(TypeOf(Name(0)).Name()), TypeOf(Name(""))}
var kindOfIndex = &kind{Name(TypeOf(Index(1)).Name()), TypeOf(Index(1))}
var kindOfCardinality = &kind{Name(TypeOf(Cardinality(0)).Name()), TypeOf(Cardinality(0))}

/* KindOfName returns the kind of a Name.				*/ func KindOfName() *kind { return kindOfName }
/* KindOfIndex returns the kind of an Index.				*/ func KindOfIndex() *kind { return kindOfIndex }
/* KindOfCardinality returns the kind of a Cardinality.			*/ func KindOfCardinality() *kind { return kindOfCardinality }

// ===========================================================================

/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Cardinality) Kind() (Name, Type) { return KindOfCardinality().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Index) Kind() (Name, Type) { return KindOfIndex().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Name)  Kind() (Name, Type) { return KindOfName().Kind() }
/* Kind implements Kind which is easy here as a is a kind.			*/ func (a *kind) Kind() (Name, Type) { if a == nil {return nilName, nil}; return a.Name, a.Type }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Head)  Kind() (Name, Type) { return Name(TypeOf(a).Name()), TypeOf(a) }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Tail)  Kind() (Name, Type) { return Name(TypeOf(a).Name()), TypeOf(a) }

// ===========================================================================

/* Both implements Pair by returning Name and Type.			*/ func (a *kind) Both() (name, typ interface{}) {
	if a == nil {return nilName, nil};	return a.Name, a.Type }
/* Both implements Pair by returning Both() of the evalutaed Head	*/ func (a Head) Both() (aten, apep interface{}) {
	if a == nil {return nilName, nil};	if a() == nil {return nilName, nil};	return a().Both() }
/* Both implements Pair by returning the head and tail a evaluates to.	*/ func (a Tail) Both() (aten, apep interface{}) {
	if a == nil {return nilName, nil};	return a() }

// ===========================================================================

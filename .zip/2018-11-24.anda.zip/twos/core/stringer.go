// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
	"strings"
)

const onesFmt = "%v"
const twosFmt = "{ %+v | %+v }"
const nodeFmt = "{%+v<%+v>%+v}"
const tailBeg = "["
const tailEnd = "]\n"

// ===========================================================================

// String implements fmt.Stringer
func (a Name) String() string { return stringOfOnes(string(a)) }

// String implements fmt.Stringer
func (a Index) String() string { return stringOfOnes(int(a)) }

// String implements fmt.Stringer
func (a Cardinality) String() string { return stringOfOnes(int(a)) }

// String implements fmt.Stringer
func (a *kind) String() string { return StringOfPair(a) }

// String implements fmt.Stringer
func (a Head) String() string { return StringOfPair(a()) }

// String implements fmt.Stringer
func (a Tail) String() string {
	var b strings.Builder
	fmt.Fprint(&b, tailBeg)
	for head, tail := a(); head != nil; head, tail = tail() {
		fmt.Fprintf(&b, StringOfPair(head()))
	}
	fmt.Fprint(&b, tailEnd)
	return b.String()
}

// ===========================================================================

// DeKind returns the kind-less string of a Pair
func DeKind(a Pair) string {
	return StringOfBoth(a.Both, deKind)
}

// DeType returns the type-less string of a Pair
func DeType(a Pair) string {
	return StringOfBoth(a.Both, deType)
}

// StringOfPair returns the string of a Pair
func StringOfPair(a Pair) string {
	return StringOfBoth(a.Both, stringOf)
}

func deKind(a interface{}) string {
	if _, ok := a.(*kind); ok {
		return ""
	}
	if p, ok := a.(Pair); ok {
		return DeKind(p)
	}
	return stringOfOnes(a) // = return stringOf(a) - as a is not a Pair
}

func deType(a interface{}) string {
	if _, ok := a.(Type); ok {
		return ""
	}
	if p, ok := a.(Pair); ok {
		return DeType(p)
	}
	return stringOfOnes(a) // = return stringOf(a) - as a is not a Pair
}

func stringOf(a interface{}) string {
	if p, ok := a.(Pair); ok {
		return StringOfPair(p)
	}
	return stringOfOnes(a)
}

// ===========================================================================

// StringOfBoth returns a string give a both function and a stringer function
func StringOfBoth(
	both func() (aten, apep interface{}),
	stringer func(a interface{}) string ) string {

	aten, apep := both()
	return stringOfTwos(stringer(aten), stringer(apep))
}

func stringOfTwos(aten, apep string) string {
	if aten == "" || apep == "" {
		return stringOfOnes(aten+apep)
	}
	return fmt.Sprintf(twosFmt, aten, apep)
}

func stringOfOnes(a interface{}) string {
	return fmt.Sprintf(onesFmt, a)
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package plus

import (
	"fmt"
)


const onesFmt = "{%v}"
const twosFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

// String implements fmt.Stringer

func (a onesOfInt)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfString)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a onesOfTimeWeekday)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }

func (a twosOfInt)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfString)		String() string { return fmt.Sprintf(onesFmt, a.Apep) }
func (a twosOfTimeWeekday)	String() string { return fmt.Sprintf(onesFmt, a.Apep) }

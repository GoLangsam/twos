// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

// Prod is a straightforward implementation of the Cartesian product
func Prod(a, b Iterable) Tail {
	if a == nil || b == nil { return NilTail() }

	aHead, aTail := a.Tail()()
	bHead, bTail := b.Tail()()

	if aHead == nil || bHead == nil { return NilTail() }

	return func() (Head, Tail) {
		return func() Pair { return join(aHead(), bHead()) },
		       func() (Head, Tail) { return prod(a, b, aHead, bHead, aTail, bTail) }
	}
}

func prod(a, b Iterable, aHead, bHead Head, aTail, bTail Tail) (Head, Tail) {
	if aHead == nil || bHead == nil { return NilTail()() }

	head := func() Pair { return join(aHead(), bHead()) }
	tail := func() (Head, Tail) {
		aHead, aTail := aHead, aTail
		bHead, bTail := bTail()
		if bHead == nil {
			aHead, aTail = aTail()
			if aHead == nil { return NilTail()() }
			bHead, bTail = b.Tail()() // reset b
			if bHead == nil { return NilTail()() }
		}
		return func() Pair { return join(aHead(), bHead()) },
		       func() (Head, Tail) { return prod(a, b, aHead, bHead, aTail, bTail) }
	}
	return head, tail
}

# FAQ - Frequently asked questions

## How to make a `Pair`

- How to make a `Pair`

> You better don't.

- Please excuse me???

> You better don't. There's not much fun having a single, lonely pair only.
>
> You'd better make a pile - a pile of similar pairs.

- Like `NewPile().Add(1, "a")`?

> No. Not like this.

- Please excuse me???

> There is no meaning in neither this digit `1` nor in this character `a`.
>
> You'd better be meaningful - express Your semantics up front.

- Please excuse me???

> Try `NewKind("Professor", "Tom")`

- And so???

> You get a _Kind_ - a named type.

- Ahh! So _now_ I have a `Pair` _{Professor|Tom}_, do I not?

> No. No, You don't. Sorry.
>
> You have a kind named "Professor" of type `string`, as that is the type of Your example argument "Tom".

- But I still do not have my `Pair` - do I?

> Yes. You do not have Your `Pair` yet.
>
> Just: You have another `Pair`, a pair which represents Your string-type named "Professor".

- How awfull! How awkward! How ugly!!!

> Well - there's a shortcut! A sweet and simple shortcut.

- Please show me!!! I love shortcuts!

> Try `profs := NewPile("Professor", "Tom", "Andreas", "Dr. Knuth", "Albert Einstein" )`

- And ... ???

> Now You have a pile of four pairs - each of the same type, and with a common semantic meaning.

- And ... ???

> You may extend it. Just be sure to use the same type.
>
> Try `profs = profs.Append( "Stephen Hawking" )`

- And ... ???

> Now You have a pile of five ...

- What is this thing with the type all about?

> Well, `profs.Append( 2011 )` will panic - 2011 is not a `string`. It's some integer constant.

- Ahh! I see.

> You like type safety, do You not? Avoids a plethora of stupid, unintended errors.

- Yes, I do! Sure.

> Fine `:-)`

## How do I nest pairs?

> You may combine piles.

- And how do I combine piles?

> Well, use a construction which is named after Renè Descartes (a French Professor) whose formulation of analytic geometry gave rise to the concept.

- So, what's the construction?

> It's called a _Cartesian product_ (or _cross product_) - constructs a product set.
>
> All, that is - each and every `Pair` which has one side from here and one from there.

- Ahh! I see.

> And -as it's used very often in here- we shortnamed it `X()`

- I love short names!

> Try `pp := profs.X(profs)`

- Ahh! _pp_ is short for _Pairs of Professors_, is it not?

> If You say so... And: You do love short names, do You not?

- Yes, I do. I love short names!

> That's it. So, how many will be there?

- Hm. We started with 4, added another one, so we have 5.
  
  And 5 * 5 is twentyfive. There's 25 pairs in `pp`, is it not?

> Well, Yes - and No.
>
> Yes, if You go thru the `pp`s You'll see all 25.
>  
> And No - they do not exist, at least not all at the same time in Your computers memory.

- Ugh? How comes? And were are they hiding?

> Well - such products and products of products and products of products of products...
>
> They tend to grow - very quickly, very fast- and become very large.
>
> Thus: No point to waste precious memory.

- Okay ... so `pp` is not another pile?

  But then: what is it?

> Happy You ask! It's called a `Tail`. A facility to go thru the construction and get each member on demand - on the fly, so to say.

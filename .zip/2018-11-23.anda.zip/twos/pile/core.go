// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package pile

import (
	"github.com/GoLangsam/anda/twos/core"
)

// ===========================================================================

// Name as a unique identifier - unique among its Kind
type Name = core.Name

// ===========================================================================

// Cardinality represents a cardinal number such as the #-of items in a Pile.
type Cardinality = core.Cardinality

// ===========================================================================

// Index represents an ordinal number and may be used
// to enumerate a collention or access some item.
// Intentionally, the first item has Index = 1.
// This is more intuitive for users.
// (Only programmers prefer offsets over ordinals).
type Index = core.Index

// ===========================================================================

// Type is the reflect.Type
type Type = core.Type

// Kind represents a named type
type Kind = core.Kind

// Pair has two sides: Aten & Apep. It may be atomic, or composed, nested.
type Pair = core.Pair

// Iterable represents a tailor-made collection, a thread for a tailor.
type Iterable = core.Iterable

// Pile holds Length items.
type Pile = core.Pile

// ===========================================================================

// Head is a thunk
// which evaluates to
// a Pair.
type Head = core.Head

// Tail is a thunk
// which evaluates to
// a Head and to another Tail.
type Tail = core.Tail

// NilTail is a helper, it returns the Tail which evaluates to nil, nil.
//  Note: this Tail is unique. So its the tail, not a tail.
func NilTail() Tail { return core.NilTail() }

// ===========================================================================

// TypeOf returns the Type of a
func TypeOf(a interface{}) Type {
	return core.TypeOf(a)
}

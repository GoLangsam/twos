// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

// ===========================================================================

// kind implements a named type
type kind struct {
	Name
	Type
}

var kindOfName = &kind{Name(TypeOf(Name(0)).Name()), TypeOf(Name(""))}
var kindOfIndex = &kind{Name(TypeOf(Index(1)).Name()), TypeOf(Index(1))}
var kindOfCardinality = &kind{Name(TypeOf(Cardinality(0)).Name()), TypeOf(Cardinality(0))}

/* KindOfName returns the kind of a Name.				*/ func KindOfName() Kind { return kindOfName }
/* KindOfIndex returns the kind of an Index.				*/ func KindOfIndex() Kind { return kindOfIndex }
/* KindOfCardinality returns the kind of a Cardinality.			*/ func KindOfCardinality() Kind { return kindOfCardinality }

/* NewKind returns a fresh Kind given a Name and a sample of the Type	*/ func NewKind(name Name, sample interface{}) *kind { return &kind{name, TypeOf(sample)} }
/* NewType returns a fresh Kind given a Name and a Type			*/ func NewType(name Name, typ Type) *kind { return &kind{name, typ} }
/* NewName returns a fresh Kind given a Name and a Kind of same Type	*/ func NewName(name Name, k Kind) *kind { _, typ := k.Kind(); return &kind{name, typ} }

// ===========================================================================

/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Cardinality) Kind() (Name, Type) { return KindOfCardinality().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Index) Kind() (Name, Type) { return KindOfIndex().Kind() }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Name)  Kind() (Name, Type) { return KindOfName().Kind() }
/* Kind implements Kind which is easy here as a is a kind.			*/ func (a *kind) Kind() (Name, Type) { return a.Name, a.Type }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Head)  Kind() (Name, Type) { return Name(TypeOf(a).Name()), TypeOf(a) }
/* Kind implements Kind by returning the Name of the Type and the TypeOf(a).	*/ func (a Tail)  Kind() (Name, Type) { return Name(TypeOf(a).Name()), TypeOf(a) }

// ===========================================================================

/* Both implements Pair by returning Name and Type.			*/ func (a *kind) Both() (name, typ interface{}) { return a.Name, a.Type }
/* Both implements Pair by returning Both() of the evalutaed Head	*/ func (a Head) Both() (aten, apep interface{}) { return a().Both() }
/* Both implements Pair by returning the head and tail a evaluates to.	*/ func (a Tail) Both() (aten, apep interface{}) { return a() }

// ===========================================================================

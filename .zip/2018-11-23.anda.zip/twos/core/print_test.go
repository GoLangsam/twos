// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
)

func ExampleNames() {
	for i := range Names("ID-", 4) {
		fmt.Println(i)
	}
	// Output:
	// ID-1
	// ID-2
	// ID-3
	// ID-4
}

func ExampleKindOfName() {
	{
		i := KindOfName()
		fmt.Println(i)
	}
	// Output:
	// {Name|core.Name}
}

func ExampleKindOfIndex() {
	{
		i := KindOfIndex()
		fmt.Println(i)
	}
	// Output:
	// {ordinalNumber|core.ordinalNumber}
}

func ExampleKindOfCardinality() {
	{
		i := KindOfCardinality()
		fmt.Println(i)
	}
	// Output:
	// {cardinalNumber|core.cardinalNumber}
}

func ExampleNewType() {
	_, t := NewKind("Integer", int(0)).Kind()

	k := NewType("New Type", t)

	fmt.Println(k)
	// Output:
	// {New Type|int}
}

func ExampleNewName() {
	k := NewKind("Integer", int(0))

	k = NewName("New Name", k)

	fmt.Println(k)
	// Output:
	// {New Name|int}
}

func ExampleNewKind() {
	{
		k := NewKind("String", string(""))
		k = NewKind("A kind of a string", k)
		fmt.Println(k, k.Name, k.Type)
	}
	{
		k := NewKind("Integer", int(0))
		fmt.Println(k)
	}
	{
		k := NewKind("String", string(""))
		fmt.Println(k)
	}
	// Output:
	// {A kind of a string|*core.kind} A kind of a string *core.kind
	// {Integer|int}
	// {String|string}
}

// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

/* Length implements Pile by returning zero for nil and 1 otherwise	*/ func (a Head) Length() Cardinality { if a == nil { return 0 }; return 1 }

// Tail implements Iterable
// by returning
// a head which evaluates to a ( head() == a ) and
// as tail the unique NilTail().
func (a Head) Tail() Tail { return func() (Head, Tail) { return func() Pair { return a }, NilTail() } }

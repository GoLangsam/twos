// Copyright 2018 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package core

import (
	"fmt"
	"strings"
)

const onesFmt = "%v"
const twosFmt = "{%+v|%+v}"
const nodeFmt = "{%+v<%+v>%+v}"

// String implements fmt.Stringer
func (a Name) String() string { return fmt.Sprintf(onesFmt, string(a)) }

// String implements fmt.Stringer
func (a Index) String() string { return fmt.Sprintf(onesFmt, int(a)) }

// String implements fmt.Stringer
func (a Cardinality) String() string { return fmt.Sprintf(onesFmt, int(a)) }

// String implements fmt.Stringer
func (a *kind) String() string { return StringOfPair(a) }

// String implements fmt.Stringer
func (a Head) String() string { return StringOfPair(a) }

// String implements fmt.Stringer
func (a Tail) String() string {
	var b strings.Builder
	fmt.Fprint(&b, "[")
	for head, tail := a(); head != nil; head, tail = tail() {
		fmt.Fprintf(&b, StringOfPair(head()))
	}
	fmt.Fprintln(&b, "]")
	return b.String()
}

// StringOfPair returns the string of a Pair
func StringOfPair(a Pair) string {
	aten, apep := a.Both()
	return fmt.Sprintf(twosFmt, stringOf(aten), stringOf(apep))
}

func stringOf(a interface{}) string {
	if t, ok := a.(Pair); ok {
		return StringOfPair(t)
	}
	return fmt.Sprintf(onesFmt, a)
}

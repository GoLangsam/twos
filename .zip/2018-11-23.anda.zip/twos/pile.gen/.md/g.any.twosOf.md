package pile // import "github.com/GoLangsam/anda/twos/pile.gen"

type twosOfany struct {
	Aten any
	Apep any
}

func (a twosOfany) Both() (aten, apep interface{})
func (a twosOfany) Length() Cardinality
func (a twosOfany) Tail() Tail

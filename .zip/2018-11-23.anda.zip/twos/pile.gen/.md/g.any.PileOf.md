package pile // import "github.com/GoLangsam/anda/twos/pile.gen"

type PileOfany struct {
	Kind
	Apep []any

	lookUpany
	duplicates lookUpany
}
    PileOfany holds different items of some kind, accessible in order of arrival
    and by index as well as via reverse look-up: Idx(item) returns the index (if
    any). It may be seen as a finite ordered indexed immutable set.

    Intentionally there is no removal, neither are add nor append exported.


func NewPileOfany(name Name, items ...any) *PileOfany
func (a PileOfany) At(idx Index) any
func (a PileOfany) Both() (aten, apep interface{})
func (a PileOfany) Fmap(f func(any) any) *PileOfany
func (a PileOfany) Idx(item any) (idx Index, found bool)
func (a PileOfany) Len() int
func (a PileOfany) Length() Cardinality
func (a PileOfany) Random() <-chan any
func (a PileOfany) Range() <-chan any
func (a PileOfany) Tail() Tail
func (a *PileOfany) add(item any) *PileOfany
func (a *PileOfany) append(items ...any) *PileOfany
func (a PileOfany) head(idx int) Head
func (a *PileOfany) put(item any, idx Index)
func (a PileOfany) tail(idx int) Tail

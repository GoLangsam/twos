func assertPileOfanyInterfaces()
    func NewPileOfany(name Name, items ...any) *PileOfany
    func NilTail() Tail
    func TypeOf(a interface{}) Type
    func Fmapanys(f func(any) any, anys ...any) []any
    func JoinanyS(ss [][]any) []any

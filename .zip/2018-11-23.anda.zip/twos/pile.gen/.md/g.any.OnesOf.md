package pile // import "github.com/GoLangsam/anda/twos/pile.gen"

type onesOfany struct {
	Kind
	Apep any
}

func (a onesOfany) Both() (aten, apep interface{})
func (a onesOfany) Length() Cardinality
func (a onesOfany) Tail() Tail
